<?php
/**
 * Plugin Name: LifeTrust Planning
 * Plugin URI: https://lifetrustplanning.ca
 * Description: LifeTrust Planning MVP plugin with membership tiers, Henson Trust workflow, AI assistance, and PDF generation.
 * Version: 0.5.2
 * Requires at least: 5.9
 * Requires PHP: 8.1
 * Author: LifeTrust Planning
 * Text Domain: lifetrust-planning
 */

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

if (!defined('ABSPATH')) {
    exit;
}

define('LTP_VERSION', '0.5.2');
define('LTP_PLUGIN_FILE', __FILE__);
define('LTP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LTP_PLUGIN_URL', plugin_dir_url(__FILE__));

$autoload = LTP_PLUGIN_DIR . 'vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

if (!class_exists(\LifeTrustPlanning\Plugin::class)) {
    add_action('admin_notices', static function () {
        echo '<div class="notice notice-error"><p>LifeTrust Planning: Required bundled dependencies are missing from this plugin package. Please reinstall using the official release ZIP.</p></div>';
    });
    return;
}

$pluginUpdateChecker = LTP_PLUGIN_DIR . 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';
if (file_exists($pluginUpdateChecker)) {
    require_once $pluginUpdateChecker;

    // IMPORTANT: The update metadata URL must be publicly accessible and return HTTP 200 JSON.
    // Override this in wp-config.php if needed:
    // define('LTP_UPDATE_METADATA_URL', 'https://raw.githubusercontent.com/DarrylErentzen/plugin_releases/main/ltu/info.json');
    $defaultUpdateMetadataUrl = 'https://raw.githubusercontent.com/DarrylErentzen/plugin_releases/main/ltu/info.json';
    $configuredUpdateMetadataUrl = defined('LTP_UPDATE_METADATA_URL') ? LTP_UPDATE_METADATA_URL : $defaultUpdateMetadataUrl;
    $configuredUpdateMetadataUrl = apply_filters('ltp_update_metadata_url', $configuredUpdateMetadataUrl);

    // Fallback to bundled metadata to avoid hard failures if remote hosting is misconfigured.
    $bundledUpdateMetadataUrl = LTP_PLUGIN_URL . 'updates/info.json';
    $candidateUpdateUrls = array_values(array_unique(array_filter([
        $configuredUpdateMetadataUrl,
        $bundledUpdateMetadataUrl,
    ])));

    $resolutionTransientKey = 'ltp_puc_resolved_metadata_url_' . md5($configuredUpdateMetadataUrl);
    $resolvedUpdateMetadataUrl = get_transient($resolutionTransientKey);

    if (!is_string($resolvedUpdateMetadataUrl) || $resolvedUpdateMetadataUrl === '') {
        $resolvedUpdateMetadataUrl = $configuredUpdateMetadataUrl;
        foreach ($candidateUpdateUrls as $candidateUrl) {
            $response = wp_remote_head($candidateUrl, ['timeout' => 5]);
            $statusCode = is_wp_error($response) ? 0 : (int) wp_remote_retrieve_response_code($response);
            if ($statusCode === 200) {
                $resolvedUpdateMetadataUrl = $candidateUrl;
                break;
            }
        }

        set_transient($resolutionTransientKey, $resolvedUpdateMetadataUrl, 15 * MINUTE_IN_SECONDS);
    }

    if (is_admin() && $resolvedUpdateMetadataUrl !== $configuredUpdateMetadataUrl) {
        add_action('admin_notices', static function () use ($configuredUpdateMetadataUrl, $bundledUpdateMetadataUrl) {
            if (!current_user_can('manage_options')) {
                return;
            }
            echo '<div class="notice notice-warning"><p><strong>LifeTrust Planning updates:</strong> Remote update metadata URL is unreachable: <code>' . esc_html($configuredUpdateMetadataUrl) . '</code>. Falling back to bundled metadata <code>' . esc_html($bundledUpdateMetadataUrl) . '</code>. Upload <code>info.json</code> and plugin ZIP to your public update host to re-enable centralized auto-updates.</p></div>';
        });
    }

    $updateChecker = PucFactory::buildUpdateChecker(
        $resolvedUpdateMetadataUrl,
        __FILE__,
        'lifetrust-planning'
    );
}

register_activation_hook(__FILE__, [\LifeTrustPlanning\Activator::class, 'activate']);
register_deactivation_hook(__FILE__, [\LifeTrustPlanning\Deactivator::class, 'deactivate']);

add_action('plugins_loaded', static function () {
    (new \LifeTrustPlanning\Plugin())->run();
});
