(function () {
  const updateIntervals = (scope, interval) => {
    scope.querySelectorAll('.ltp-price, .ltp-savings, .ltp-cta-button').forEach((node) => {
      const nodeInterval = node.getAttribute('data-interval');
      if (!nodeInterval) return;
      node.style.display = nodeInterval === interval ? '' : 'none';
    });
  };

  document.addEventListener('click', (event) => {
    const btn = event.target.closest('.ltp-interval-btn');
    if (!btn) return;

    const wrap = btn.closest('.ltp-pricing-table-wrap');
    if (!wrap) return;

    const interval = btn.getAttribute('data-interval') || 'monthly';
    wrap.querySelectorAll('.ltp-interval-btn').forEach((b) => {
      b.classList.toggle('is-active', b === btn);
      b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
    });

    updateIntervals(wrap, interval);
  });

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.ltp-pricing-table-wrap').forEach((wrap) => {
      const initial = wrap.getAttribute('data-default-interval') || 'monthly';
      updateIntervals(wrap, initial);
    });
  });
})();
