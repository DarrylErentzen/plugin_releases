<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;
$tables = [
    'ltp_documents',
    'ltp_contacts',
    'ltp_assets',
    'ltp_asset_valuations',
    'ltp_ai_interactions',
    'ltp_firms',
    'ltp_firm_seats',
    'ltp_client_profiles',
    'ltp_billing_subscriptions', // legacy v0.0.1
    'ltp_subscriptions',
    'ltp_payment_methods',
    'ltp_billing_history',
    'ltp_automation_rules',
    'ltp_pdf_templates',
];

foreach ($tables as $table) {
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}{$table}");
}

$options = [
    'ltp_ai_primary_provider',
    'ltp_ai_fallback_providers',
    'ltp_ai_free_daily_limit',
    'ltp_pdf_watermark_text',
    'ltp_membership_provider',
    'ltp_billing_provider',
    'ltp_wc_product_map',
    'ltp_base_monthly_prices',
    'ltp_quarterly_discount_percentage',
    'ltp_yearly_discount_percentage',
    'ltp_dashboard_cta_content',
    'ltp_marketing_content',
    'ltp_tier_capability_map',
    'ltp_custom_capabilities',
    'ltp_tier_role_map',
    'ltp_manual_grace_days',
    'ltp_custom_recurring_retry_limit',
    'ltp_custom_recurring_grace_days',
    'ltp_schema_version',
    'ltp_last_migration_snapshot',
    'ltp_migration_wc_subscriptions_payload',
    'ltp_migration_memberpress_payload',
];

foreach ($options as $option) {
    delete_option($option);
}
