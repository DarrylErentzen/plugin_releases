<?php
/**
 * LifeTrust Member Portal Template
 */
if (!defined('ABSPATH')) { exit; }

echo do_shortcode('[ltp_member_portal]');
