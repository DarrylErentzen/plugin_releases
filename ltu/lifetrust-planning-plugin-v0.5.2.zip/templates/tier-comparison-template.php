<?php
/**
 * LifeTrust Tier Comparison Template
 */
if (!defined('ABSPATH')) { exit; }

echo do_shortcode('[ltp_pricing_table interval="yearly"]');
