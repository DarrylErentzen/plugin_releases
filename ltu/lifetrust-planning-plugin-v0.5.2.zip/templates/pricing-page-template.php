<?php
/**
 * LifeTrust Pricing Page Template (shortcode-ready)
 */
if (!defined('ABSPATH')) { exit; }

echo do_shortcode('[ltp_pricing_table]');
echo do_shortcode('[ltp_upgrade_prompt]');
