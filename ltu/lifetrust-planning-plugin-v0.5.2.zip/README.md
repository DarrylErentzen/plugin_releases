# LifeTrust Planning WordPress Plugin

## Version
- **Release:** `v0.5.2`
- **Distribution package:** `lifetrust-planning-plugin-v0.5.2.zip`
- **Runtime model:** Fully self-contained (no npm/composer/build required)

## Install (Production)
1. In WordPress Admin, go to **Plugins → Add New → Upload Plugin**.
2. Upload `lifetrust-planning-plugin-v0.5.2.zip`.
3. Click **Install Now**, then **Activate**.
4. Go to **LifeTrust Planning → Settings** and configure your options.

That’s it. No command-line setup is required.

## What’s Included in the ZIP
- All plugin PHP files
- All pre-built frontend assets (plain CSS + ready-to-run JS)
- Full `vendor/` dependencies bundled for runtime
- Templates and plugin documentation

## v0.5.2 Functional Highlights
### MemberPress Growth Integration
- MemberPress is the default membership provider.
- Tier mapping is configurable from plugin settings.
- Supported tiers: **Free, Essential, Premium, Ultimate, Graduate**.

### CDA Program Foundation
- CDA student, course progress, exam, certificate, experience log, graduate, and scenario data tables.
- Curriculum/domain catalog and course-to-tool mappings.
- Student dashboard and graduate registry workflows.

### WooCommerce + Access Controls
- CDA products can be generated from admin settings.
- Tier-based discount support for CDA products.
- Tier/state-aware watermarking across free/student/member/graduate/sandbox states.

## Configuration Summary
Use **LifeTrust Planning → Settings** to configure:
- MemberPress tier mapping
- CDA student membership detection
- CDA discounts and watermarks
- Exam passing score
- Experience hour requirements
- Graduate registry visibility

## Notes
- This release is packaged for standard WordPress hosting environments.
- Installation flow is **Upload → Activate → Configure → Done**.
