<?php

namespace LifeTrustPlanning\AI;

class AI_Manager {
    /** @var array<string, AI_Provider_Interface> */
    private array $providers = [];
    private AI_Usage_Tracker $tracker;

    public function __construct() {
        $this->tracker = new AI_Usage_Tracker();
        $this->providers = [
            'gemini' => new AI_Gemini(),
            'openai' => new AI_OpenAI(),
            'anthropic' => new AI_Anthropic(),
        ];

        $this->providers = apply_filters('ltp_ai_registered_providers', $this->providers);
    }

    public function query(string $prompt, string $system_prompt, array $options = []): array {
        $user_id = (int) ($options['user_id'] ?? get_current_user_id());
        if (!$this->tracker->is_within_limits($user_id)) {
            return [
                'content' => 'You have reached your daily free AI limit. Upgrade for unlimited AI access.',
                'provider' => 'system',
                'model' => 'limit',
                'tokens_used' => 0,
            ];
        }

        $chain = $this->provider_chain();
        foreach ($chain as $provider_id) {
            $provider = $this->providers[$provider_id] ?? null;
            if (!$provider || !$provider->is_available()) {
                continue;
            }

            try {
                $result = $provider->query($prompt, $system_prompt, $options);
                $this->tracker->track($user_id, $prompt, $result, $options);
                return $result;
            } catch (\Throwable $e) {
                error_log('LTP AI provider failed: ' . $provider_id . ' - ' . $e->getMessage());
            }
        }

        $fallback = Knowledge_Base::get_relevant_context($prompt);
        $result = [
            'content' => $fallback ?: 'I could not reach AI providers right now. Please try again shortly.',
            'provider' => 'local',
            'model' => 'knowledge_base',
            'tokens_used' => 0,
        ];
        $this->tracker->track($user_id, $prompt, $result, $options);
        return $result;
    }

    private function provider_chain(): array {
        $primary = (string) get_option('ltp_ai_primary_provider', 'gemini');
        $fallback = (array) get_option('ltp_ai_fallback_providers', ['openai', 'anthropic']);
        return array_values(array_unique(array_merge([$primary], $fallback)));
    }
}
