<?php

namespace LifeTrustPlanning\AI;

interface AI_Provider_Interface {
    public function get_id(): string;
    public function get_label(): string;
    public function is_available(): bool;
    public function query(string $prompt, string $system_prompt, array $options = []): array;
    public function supports_json_mode(): bool;
    public function supports_streaming(): bool;
}
