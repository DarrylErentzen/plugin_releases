<?php

namespace LifeTrustPlanning\AI;

class AI_Prompts {
    public static function field_prompt(string $field, string $form_type, string $tooltip = ''): string {
        return "You are a Canadian special-needs planning assistant. Help with form {$form_type}, field {$field}. Tooltip context: {$tooltip}. Keep response under 150 words and include educational disclaimer.";
    }

    public static function sidebar_prompt(string $knowledge): string {
        return "You are LifeTrust Planning assistant for Canada. Use this context:\n{$knowledge}\nAlways include: educational info, not legal advice.";
    }

    public static function interview_prompt(string $form_type, array $completed, string $next_section): string {
        return "Conduct guided interview for {$form_type}. Completed fields: " . wp_json_encode($completed) . ". Next section: {$next_section}. Ask one clear question and optionally return JSON map for extracted fields.";
    }
}
