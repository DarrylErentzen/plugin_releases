<?php

namespace LifeTrustPlanning\AI;

class AI_Usage_Tracker {
    public function is_within_limits(int $user_id): bool {
        $tier = \LifeTrustPlanning\Core\Tier_Access::get_user_tier($user_id);
        $is_student = \LifeTrustPlanning\Core\Tier_Access::is_student($user_id);

        if ($tier !== 'free' && !$is_student) {
            return true;
        }

        $limit = (int) get_option('ltp_ai_free_daily_limit', 5);
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_ai_interactions';
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND DATE(created_at)=%s",
            $user_id,
            current_time('Y-m-d')
        ));

        return $count < $limit;
    }

    public function track(int $user_id, string $prompt, array $result, array $context = []): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_ai_interactions';

        $wpdb->insert($table, [
            'user_id' => $user_id,
            'session_id' => sanitize_text_field((string) ($context['session_id'] ?? '')),
            'query' => wp_strip_all_tags($prompt),
            'response' => (string) ($result['content'] ?? ''),
            'provider' => sanitize_text_field((string) ($result['provider'] ?? 'local')),
            'model' => sanitize_text_field((string) ($result['model'] ?? 'fallback')),
            'tokens_used' => (int) ($result['tokens_used'] ?? 0),
            'category' => sanitize_text_field((string) ($context['category'] ?? 'general')),
            'context_document_id' => (int) ($context['document_id'] ?? 0),
            'context_field' => sanitize_text_field((string) ($context['field_name'] ?? '')),
        ]);
    }
}
