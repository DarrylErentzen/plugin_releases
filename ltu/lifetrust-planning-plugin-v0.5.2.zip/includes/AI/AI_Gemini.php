<?php

namespace LifeTrustPlanning\AI;

class AI_Gemini implements AI_Provider_Interface {
    public function get_id(): string { return 'gemini'; }
    public function get_label(): string { return 'Gemini'; }
    public function is_available(): bool { return !empty(get_option('ltp_ai_gemini_api_key')); }
    public function supports_json_mode(): bool { return false; }
    public function supports_streaming(): bool { return false; }

    public function query(string $prompt, string $system_prompt, array $options = []): array {
        $key = (string) get_option('ltp_ai_gemini_api_key');
        $model = (string) get_option('ltp_ai_gemini_model', 'gemini-1.5-flash');
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";

        $response = wp_remote_post($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode([
                'system_instruction' => ['parts' => [['text' => $system_prompt]]],
                'contents' => [['parts' => [['text' => $prompt]]]],
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            throw new \RuntimeException($response->get_error_message());
        }

        $json = json_decode((string) wp_remote_retrieve_body($response), true);
        return [
            'content' => (string) ($json['candidates'][0]['content']['parts'][0]['text'] ?? ''),
            'tokens_used' => (int) ($json['usageMetadata']['totalTokenCount'] ?? 0),
            'provider' => 'gemini',
            'model' => $model,
        ];
    }
}
