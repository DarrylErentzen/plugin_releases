<?php

namespace LifeTrustPlanning\AI;

class AI_Anthropic implements AI_Provider_Interface {
    public function get_id(): string { return 'anthropic'; }
    public function get_label(): string { return 'Anthropic'; }
    public function is_available(): bool { return !empty(get_option('ltp_ai_anthropic_api_key')); }
    public function supports_json_mode(): bool { return false; }
    public function supports_streaming(): bool { return true; }

    public function query(string $prompt, string $system_prompt, array $options = []): array {
        $key = (string) get_option('ltp_ai_anthropic_api_key');
        $model = (string) get_option('ltp_ai_anthropic_model', 'claude-3-5-sonnet-20241022');

        $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'headers' => [
                'x-api-key' => $key,
                'anthropic-version' => '2023-06-01',
                'content-type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'model' => $model,
                'max_tokens' => $options['max_tokens'] ?? 800,
                'system' => $system_prompt,
                'messages' => [['role' => 'user', 'content' => $prompt]],
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            throw new \RuntimeException($response->get_error_message());
        }

        $json = json_decode((string) wp_remote_retrieve_body($response), true);
        return [
            'content' => (string) ($json['content'][0]['text'] ?? ''),
            'tokens_used' => (int) (($json['usage']['input_tokens'] ?? 0) + ($json['usage']['output_tokens'] ?? 0)),
            'provider' => 'anthropic',
            'model' => $model,
        ];
    }
}
