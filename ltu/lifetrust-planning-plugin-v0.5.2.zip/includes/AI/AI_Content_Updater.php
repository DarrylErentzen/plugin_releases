<?php

namespace LifeTrustPlanning\AI;

class AI_Content_Updater {
    public static function run_auto_update(): void {
        if (!(bool) get_option('ltp_content_auto_update_enabled', true)) {
            return;
        }

        $articles = get_posts([
            'post_type' => 'ltp_knowledge_base',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'meta_key' => '_ltp_kb_auto_update',
            'meta_value' => '1',
        ]);

        if (empty($articles)) {
            return;
        }

        $manager = new AI_Manager();

        foreach ($articles as $article) {
            $prompt = "Refresh this article with updated Canadian info while preserving structure: {$article->post_title}\n\n{$article->post_content}";
            $res = $manager->query($prompt, 'You are updating legal-education content for review only.', ['category' => 'content_update']);

            $draft_id = wp_insert_post([
                'post_type' => 'ltp_knowledge_base',
                'post_status' => 'draft',
                'post_parent' => $article->ID,
                'post_title' => $article->post_title . ' [AI Update - Pending Review]',
                'post_content' => $res['content'],
            ]);

            update_post_meta($draft_id, '_ltp_content_update_status', 'pending_review');
            do_action('ltp_content_update_generated', $draft_id, $article->ID);
        }
    }
}
