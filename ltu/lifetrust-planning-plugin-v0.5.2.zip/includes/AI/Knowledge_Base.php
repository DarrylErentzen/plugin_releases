<?php

namespace LifeTrustPlanning\AI;

class Knowledge_Base {
    public static function get_relevant_context(string $query): string {
        $snippets = [];

        $articles = get_posts([
            'post_type' => 'ltp_knowledge_base',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            's' => $query,
        ]);

        foreach ($articles as $article) {
            $snippets[] = wp_strip_all_tags($article->post_title . ': ' . wp_trim_words($article->post_content, 80));
        }

        $programs = get_posts([
            'post_type' => 'ltp_gov_program',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            's' => $query,
        ]);

        foreach ($programs as $program) {
            $snippets[] = wp_strip_all_tags($program->post_title . ': ' . wp_trim_words($program->post_content, 80));
        }

        $snippets = apply_filters('ltp_ai_knowledge_base', $snippets, $query);

        return implode("\n\n---\n\n", $snippets);
    }
}
