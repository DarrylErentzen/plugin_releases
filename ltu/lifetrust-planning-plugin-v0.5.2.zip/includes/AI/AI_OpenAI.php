<?php

namespace LifeTrustPlanning\AI;

class AI_OpenAI implements AI_Provider_Interface {
    public function get_id(): string { return 'openai'; }
    public function get_label(): string { return 'OpenAI'; }
    public function is_available(): bool { return !empty(get_option('ltp_ai_openai_api_key')); }
    public function supports_json_mode(): bool { return true; }
    public function supports_streaming(): bool { return true; }

    public function query(string $prompt, string $system_prompt, array $options = []): array {
        $key = (string) get_option('ltp_ai_openai_api_key');
        $model = (string) get_option('ltp_ai_openai_model', 'gpt-4o-mini');

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $system_prompt],
                    ['role' => 'user', 'content' => $prompt],
                ],
                'max_tokens' => $options['max_tokens'] ?? 800,
                'temperature' => $options['temperature'] ?? 0.4,
            ]),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            throw new \RuntimeException($response->get_error_message());
        }

        $json = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!empty($json['error'])) {
            throw new \RuntimeException((string) ($json['error']['message'] ?? 'OpenAI failed'));
        }

        return [
            'content' => (string) ($json['choices'][0]['message']['content'] ?? ''),
            'tokens_used' => (int) ($json['usage']['total_tokens'] ?? 0),
            'provider' => 'openai',
            'model' => $model,
        ];
    }
}
