<?php

namespace LifeTrustPlanning\REST;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Documents\Document_Manager;
use WP_Error;
use WP_REST_Request;

class REST_Documents_Controller {
    public static function register_routes(): void {
        register_rest_route('ltp/v1', '/documents', [
            [
                'methods' => 'GET',
                'callback' => [self::class, 'list_documents'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
            [
                'methods' => 'POST',
                'callback' => [self::class, 'create_document'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
        ]);

        register_rest_route('ltp/v1', '/documents/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [self::class, 'get_document'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
            [
                'methods' => 'PATCH',
                'callback' => [self::class, 'update_document'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [self::class, 'delete_document'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
        ]);

        register_rest_route('ltp/v1', '/user/form-preferences', [
            [
                'methods' => 'PATCH',
                'callback' => [self::class, 'save_form_preferences'],
                'permission_callback' => [self::class, 'is_logged_in'],
            ],
        ]);
    }

    public static function is_logged_in(): bool {
        return is_user_logged_in();
    }

    public static function list_documents(): array {
        $user_id = get_current_user_id();
        $docs = Document_Manager::list($user_id);
        return array_map([self::class, 'format_doc_for_tier'], $docs);
    }

    public static function create_document(WP_REST_Request $request) {
        $payload = $request->get_json_params();
        $res = Document_Manager::create($payload, get_current_user_id());
        if (is_wp_error($res)) {
            return $res;
        }

        return self::format_doc_for_tier($res);
    }

    public static function get_document(WP_REST_Request $request) {
        $doc = Document_Manager::get((int) $request['id'], get_current_user_id());
        if (!$doc) {
            return new WP_Error('not_found', 'Document not found', ['status' => 404]);
        }

        if ($doc->status === 'draft' && !Tier_Access::can('access_draft')) {
            return new WP_Error('upgrade_required', 'Upgrade to access your saved drafts.', [
                'status' => 403,
                'drafts_locked' => Tier_Access::count_active_drafts(get_current_user_id()),
            ]);
        }

        return self::format_doc_for_tier($doc);
    }

    public static function update_document(WP_REST_Request $request) {
        $payload = $request->get_json_params();

        $ok = Document_Manager::update((int) $request['id'], $payload, get_current_user_id());
        if (is_wp_error($ok)) {
            return $ok;
        }

        $doc = Document_Manager::get((int) $request['id'], get_current_user_id());
        return self::format_doc_for_tier($doc);
    }

    public static function delete_document(WP_REST_Request $request) {
        $doc = Document_Manager::get((int) $request['id'], get_current_user_id());
        if (!$doc) {
            return new WP_Error('not_found', 'Document not found', ['status' => 404]);
        }

        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'ltp_documents', ['id' => (int) $doc->id]);
        return ['deleted' => true];
    }

    public static function save_form_preferences(WP_REST_Request $request): array {
        $modes = (array) ($request->get_json_params()['navigation_modes'] ?? []);
        $user_id = get_current_user_id();

        foreach ($modes as $type => $mode) {
            if (!in_array($mode, ['tab', 'step'], true)) {
                continue;
            }
            update_user_meta($user_id, '_ltp_form_nav_mode_' . sanitize_key($type), $mode);
        }

        return ['saved' => true];
    }

    private static function format_doc_for_tier(object $doc): array {
        $arr = (array) $doc;
        if ($doc->status === 'draft' && !Tier_Access::can('access_draft')) {
            $arr['content'] = null;
            $arr['locked'] = true;
            $arr['locked_message'] = sprintf('Upgrade to access this draft. You currently have %d drafts waiting.', Tier_Access::count_active_drafts((int) $doc->user_id));
        } else {
            $arr['locked'] = false;
            $arr['content'] = json_decode((string) $doc->content, true);
        }

        return $arr;
    }
}
