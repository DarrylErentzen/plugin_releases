<?php

namespace LifeTrustPlanning\REST;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Documents\Document_Manager;
use LifeTrustPlanning\PDF\PDF_Engine;
use WP_Error;
use WP_REST_Request;

class REST_PDF_Controller {
    public static function register_routes(): void {
        register_rest_route('ltp/v1', '/documents/(?P<id>\d+)/pdf', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_pdf'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);
    }

    public static function get_pdf(WP_REST_Request $request) {
        $user_id = get_current_user_id();
        $doc_id = (int) $request['id'];
        $document = Document_Manager::get($doc_id, $user_id);

        if (!$document) {
            return new WP_Error('not_found', 'Document not found', ['status' => 404]);
        }

        if (!in_array($document->status, ['completed', 'draft', 'preview'], true)) {
            return new WP_Error('not_ready', 'Document status not eligible for PDF generation.', ['status' => 422]);
        }

        $engine = new PDF_Engine();
        $path = $engine->generate($doc_id, $user_id);

        $filename = sanitize_file_name($document->title . '.pdf');
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));

        // Free tier receives redacted + watermarked locked output already, no editable rights.
        if (!Tier_Access::can('download_pdf', $user_id)) {
            header('X-LTP-Preview: 1');
        }

        readfile($path);
        exit;
    }
}
