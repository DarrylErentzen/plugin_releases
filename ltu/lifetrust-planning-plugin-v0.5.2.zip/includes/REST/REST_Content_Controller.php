<?php

namespace LifeTrustPlanning\REST;

class REST_Content_Controller {
    public static function register_routes(): void {
        register_rest_route('ltp/v1', '/knowledge', [
            'methods' => 'GET',
            'callback' => [self::class, 'knowledge'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ltp/v1', '/knowledge/search', [
            'methods' => 'GET',
            'callback' => [self::class, 'knowledge_search'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('ltp/v1', '/programs', [
            'methods' => 'GET',
            'callback' => [self::class, 'programs'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function knowledge(): array {
        $posts = get_posts([
            'post_type' => 'ltp_knowledge_base',
            'post_status' => 'publish',
            'posts_per_page' => 100,
        ]);

        return array_map([self::class, 'normalize_post'], $posts);
    }

    public static function knowledge_search(\WP_REST_Request $request): array {
        $q = sanitize_text_field((string) $request->get_param('q'));
        $posts = get_posts([
            'post_type' => 'ltp_knowledge_base',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            's' => $q,
        ]);

        return array_map([self::class, 'normalize_post'], $posts);
    }

    public static function programs(): array {
        $posts = get_posts([
            'post_type' => 'ltp_gov_program',
            'post_status' => 'publish',
            'posts_per_page' => 100,
        ]);

        return array_map([self::class, 'normalize_post'], $posts);
    }

    private static function normalize_post(\WP_Post $post): array {
        return [
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
        ];
    }
}
