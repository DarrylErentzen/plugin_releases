<?php

namespace LifeTrustPlanning\REST;

use LifeTrustPlanning\Billing\Billing_Data_Store;
use LifeTrustPlanning\Core\Tier_Access;
use WP_Error;
use WP_REST_Request;

class REST_Billing_Controller {
    public static function register_routes(): void {
        register_rest_route('ltp/v1', '/billing/subscription', [
            'methods' => 'GET',
            'callback' => [self::class, 'subscription'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);

        register_rest_route('ltp/v1', '/billing/seats/add', [
            'methods' => 'POST',
            'callback' => [self::class, 'add_seats'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);

        register_rest_route('ltp/v1', '/billing/invoices', [
            'methods' => 'GET',
            'callback' => [self::class, 'invoices'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);
    }

    public static function subscription(): array {
        $store = new Billing_Data_Store();

        return [
            'tier' => Tier_Access::get_user_tier(),
            'limits' => Tier_Access::get_limits_info(),
            'subscription' => $store->get_user_latest_subscription(get_current_user_id()),
            'billing_provider' => get_option('ltp_billing_provider', 'custom_recurring'),
        ];
    }

    public static function add_seats(WP_REST_Request $request) {
        $tier = Tier_Access::get_user_tier();
        if (!in_array($tier, ['premium', 'ultimate'], true)) {
            return new WP_Error('forbidden', 'Seat add-ons available for Premium/Ultimate only.', ['status' => 403]);
        }

        $count = max(1, absint((int) $request->get_param('count')));

        // Hook for WooCommerce order creation integration.
        do_action('ltp_billing_add_seats', get_current_user_id(), $count);

        return ['queued' => true, 'count' => $count];
    }

    public static function invoices(): array {
        if (!function_exists('wc_get_orders')) {
            return [];
        }

        $orders = wc_get_orders([
            'customer_id' => get_current_user_id(),
            'limit' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $out = [];
        foreach ($orders as $order) {
            $out[] = [
                'id' => $order->get_id(),
                'date' => $order->get_date_created()?->date('Y-m-d H:i:s'),
                'total' => $order->get_total(),
                'status' => $order->get_status(),
                'tier' => $order->get_meta('_ltp_tier'),
                'interval' => $order->get_meta('_ltp_interval'),
            ];
        }

        return $out;
    }
}
