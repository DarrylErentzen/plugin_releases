<?php

namespace LifeTrustPlanning\REST;

use LifeTrustPlanning\AI\AI_Manager;
use LifeTrustPlanning\AI\AI_Prompts;
use LifeTrustPlanning\Core\Tier_Access;
use WP_Error;
use WP_REST_Request;

class REST_AI_Controller {
    public static function register_routes(): void {
        register_rest_route('ltp/v1', '/ai/field-assist', [
            'methods' => 'POST',
            'callback' => [self::class, 'field_assist'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);

        register_rest_route('ltp/v1', '/ai/query', [
            'methods' => 'POST',
            'callback' => [self::class, 'query'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);

        register_rest_route('ltp/v1', '/ai/interview-step', [
            'methods' => 'POST',
            'callback' => [self::class, 'interview_step'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);

        register_rest_route('ltp/v1', '/ai/history', [
            'methods' => 'GET',
            'callback' => [self::class, 'history'],
            'permission_callback' => [REST_Documents_Controller::class, 'is_logged_in'],
        ]);
    }

    public static function field_assist(WP_REST_Request $request) {
        if (!Tier_Access::can('ai_field_advisor')) {
            return new WP_Error('limit', 'Daily AI limit reached for Free tier.', ['status' => 429]);
        }

        $field = sanitize_text_field((string) $request->get_param('field_name'));
        $form_type = sanitize_key((string) $request->get_param('form_type'));
        $tooltip = sanitize_text_field((string) $request->get_param('tooltip'));
        $current = sanitize_text_field((string) $request->get_param('current_value'));

        $manager = new AI_Manager();
        $result = $manager->query(
            "Help me with field {$field}. Current value: {$current}",
            AI_Prompts::field_prompt($field, $form_type, $tooltip),
            [
                'category' => 'form_assistance',
                'field_name' => $field,
                'user_id' => get_current_user_id(),
                'max_tokens' => 250,
            ]
        );

        return $result;
    }

    public static function query(WP_REST_Request $request) {
        if (!Tier_Access::can('ai_sidebar')) {
            return new WP_Error('forbidden', 'Sidebar AI is available on Essential and above.', ['status' => 403]);
        }

        $q = sanitize_text_field((string) $request->get_param('query'));
        $manager = new AI_Manager();
        return $manager->query($q, AI_Prompts::sidebar_prompt(\LifeTrustPlanning\AI\Knowledge_Base::get_relevant_context($q)), [
            'category' => 'sidebar_chat',
            'session_id' => sanitize_text_field((string) $request->get_param('session_id')),
            'user_id' => get_current_user_id(),
        ]);
    }

    public static function interview_step(WP_REST_Request $request) {
        if (!Tier_Access::can('ai_interview')) {
            return [
                'content' => 'Preview mode: In paid plans, AI asks personalized questions and fills your form automatically. Upgrade to unlock.',
                'preview' => true,
                'extracted_fields' => [],
            ];
        }

        $completed = (array) $request->get_param('completed_fields');
        $next = sanitize_text_field((string) $request->get_param('next_section'));
        $response = sanitize_text_field((string) $request->get_param('user_response'));

        $manager = new AI_Manager();
        $result = $manager->query(
            "User response: {$response}",
            AI_Prompts::interview_prompt('henson_trust', $completed, $next),
            [
                'category' => 'guided_interview',
                'user_id' => get_current_user_id(),
                'max_tokens' => 600,
            ]
        );

        return array_merge($result, ['extracted_fields' => []]);
    }

    public static function history(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_ai_interactions';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT id, query, provider, model, category, created_at FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT 50",
            get_current_user_id()
        ), ARRAY_A) ?: [];
    }
}
