<?php

namespace LifeTrustPlanning\PDF;

class Redactor {
    public static function redact_sensitive(array $data): array {
        $sensitive_keys = [
            'name', 'firstName', 'lastName', 'beneficiaryName', 'trustName',
            'address', 'addressLine1', 'addressLine2', 'postalCode',
            'sin', 'socialInsuranceNumber', 'phone', 'email'
        ];

        array_walk_recursive($data, static function (&$value, $key) use ($sensitive_keys): void {
            $keyLower = strtolower((string) $key);
            foreach ($sensitive_keys as $needle) {
                if (str_contains($keyLower, strtolower($needle)) && is_string($value) && $value !== '') {
                    $value = '████████████';
                    return;
                }
            }
        });

        return $data;
    }
}
