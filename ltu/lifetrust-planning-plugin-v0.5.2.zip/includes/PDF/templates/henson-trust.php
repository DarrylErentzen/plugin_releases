<?php
/** @var array $data */
/** @var object $document */
/** @var string $province_name */
?>
<style>
body { font-family: dejavuserif, serif; font-size: 12pt; color: #222; line-height: 1.5; }
.title { text-align:center; font-size:18pt; font-weight:700; margin-bottom:20px; letter-spacing:1px; }
.section { margin-top: 16px; }
.section h3 { font-size: 12pt; border-bottom: 1px solid #444; margin-bottom:8px; text-transform: uppercase; }
.box { background:#f7f7f7; border-left:3px solid #444; padding:8px; margin-bottom:8px; }
.small { font-size:9pt; color:#666; margin-top:30px; }
</style>

<div class="title">HENSON TRUST AGREEMENT</div>
<p><strong>Province:</strong> <?php echo esc_html($province_name); ?><br>
<strong>Effective Date:</strong> <?php echo esc_html((string) ($data['effectiveDate'] ?? '')); ?></p>

<div class="section">
  <h3>1. Trust Information</h3>
  <p><strong>Trust Name:</strong> <?php echo esc_html((string) ($data['trustName'] ?? '')); ?></p>
</div>

<div class="section">
  <h3>2. Settlor(s)</h3>
  <?php foreach (($data['settlors'] ?? []) as $settlor): ?>
    <div class="box">
      <div><strong><?php echo esc_html((string) ($settlor['settlorName'] ?? '')); ?></strong></div>
      <div><?php echo nl2br(esc_html((string) ($settlor['settlorAddress'] ?? ''))); ?></div>
      <div><?php echo nl2br(esc_html((string) ($settlor['settlorNotes'] ?? ''))); ?></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="section">
  <h3>3. Beneficiary</h3>
  <p><strong>Name:</strong> <?php echo esc_html((string) ($data['beneficiaryName'] ?? '')); ?></p>
  <p><strong>Disability Context:</strong><br><?php echo nl2br(esc_html((string) ($data['beneficiaryDisability'] ?? ''))); ?></p>
</div>

<div class="section">
  <h3>4. Trustees</h3>
  <p><strong>Primary Trustee:</strong> <?php echo esc_html((string) ($data['primaryTrusteeName'] ?? '')); ?></p>
  <p><strong>Address:</strong> <?php echo esc_html((string) ($data['primaryTrusteeAddress'] ?? '')); ?></p>
  <?php foreach (($data['successorTrustees'] ?? []) as $i => $trustee): ?>
    <p>Successor <?php echo (int) ($i + 1); ?>: <?php echo esc_html((string) ($trustee['trusteeName'] ?? '')); ?> - <?php echo esc_html((string) ($trustee['trusteeAddress'] ?? '')); ?></p>
  <?php endforeach; ?>
</div>

<div class="section">
  <h3>5. Remainder Beneficiaries</h3>
  <table width="100%" border="1" cellspacing="0" cellpadding="6">
    <tr><th align="left">Name</th><th align="right">Percentage</th></tr>
    <?php foreach (($data['remainderBeneficiaries'] ?? []) as $ben): ?>
      <tr>
        <td><?php echo esc_html((string) ($ben['name'] ?? '')); ?></td>
        <td align="right"><?php echo esc_html((string) ($ben['percentage'] ?? '0')); ?>%</td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<div class="section">
  <h3>6. Signature & Witnesses</h3>
  <?php foreach (($data['witnesses'] ?? []) as $w): ?>
    <p>Witness: <?php echo esc_html((string) ($w['name'] ?? '')); ?>, <?php echo esc_html((string) ($w['address'] ?? '')); ?></p>
  <?php endforeach; ?>
</div>

<p class="small">This document is educational and planning support content, not legal advice. Have a qualified lawyer review before execution.</p>
