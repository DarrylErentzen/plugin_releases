<?php

namespace LifeTrustPlanning\PDF;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Documents\Document_Manager;
use LifeTrustPlanning\Documents\Document_Types;

class PDF_Engine {
    public function generate(int $document_id, int $user_id): string {
        $document = Document_Manager::get($document_id, $user_id);
        if (!$document) {
            throw new \RuntimeException('Document not found');
        }

        $type = Document_Types::get((string) $document->type);
        if (!$type) {
            throw new \RuntimeException('Document type not registered');
        }

        $data = json_decode((string) $document->content, true) ?: [];
        $can_download = Tier_Access::can('download_pdf', $user_id);
        if (!$can_download) {
            $data = Redactor::redact_sensitive($data);
        }

        $html = $this->render_template((string) $type['pdf_template'], $data, $document);
        $html = apply_filters('ltp_pdf_html', $html, $document->type, $data);

        $upload = wp_upload_dir();
        $tempDir = $upload['basedir'] . '/ltp-temp';
        wp_mkdir_p($tempDir);

        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4',
            'tempDir' => $tempDir,
            'default_font' => 'dejavuserif',
        ]);

        $watermark_state = Tier_Access::get_pdf_access_state($user_id);
        $watermark_text = Tier_Access::watermark_text_for_state($watermark_state);
        if (!empty($data['_ltp_sandbox_mode'])) {
            $watermark_text = Tier_Access::watermark_text_for_state('sandbox');
        }

        if (!empty($watermark_text)) {
            $mpdf->SetWatermarkText($watermark_text);
            $mpdf->showWatermarkText = true;
            $mpdf->watermarkTextAlpha = 0.12;
        }

        if (!$can_download) {
            $mpdf->SetProtection(['copy', 'print'], '', uniqid('ltp_', true));
        }

        $mpdf->WriteHTML($html);

        $dir = $upload['basedir'] . '/ltp-pdfs/' . date('Y/m');
        wp_mkdir_p($dir);
        $filename = sanitize_file_name($document->type . '-' . $document->id . '-v' . $document->version . '.pdf');
        $filepath = $dir . '/' . $filename;
        $mpdf->Output($filepath, \Mpdf\Output\Destination::FILE);

        do_action('ltp_document_pdf_generated', $document->id, $filepath);
        return $filepath;
    }

    private function render_template(string $template, array $data, object $document): string {
        $template_file = LTP_PLUGIN_DIR . 'includes/PDF/templates/' . $template . '.php';
        if (!file_exists($template_file)) {
            throw new \RuntimeException('PDF template not found');
        }

        $province_name = \LifeTrustPlanning\Core\Provinces::name((string) ($data['province'] ?? 'ON'));
        ob_start();
        include $template_file;
        return (string) ob_get_clean();
    }
}
