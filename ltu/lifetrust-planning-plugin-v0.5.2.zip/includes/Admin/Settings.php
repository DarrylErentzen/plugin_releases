<?php

namespace LifeTrustPlanning\Admin;

class Settings {
    public static function register_settings(): void {
        register_setting('ltp_settings', 'ltp_ai_primary_provider');
        register_setting('ltp_settings', 'ltp_ai_fallback_providers');
        register_setting('ltp_settings', 'ltp_ai_openai_api_key');
        register_setting('ltp_settings', 'ltp_ai_gemini_api_key');
        register_setting('ltp_settings', 'ltp_ai_anthropic_api_key');
        register_setting('ltp_settings', 'ltp_ai_free_daily_limit');
        register_setting('ltp_settings', 'ltp_pdf_watermark_text');
        register_setting('ltp_settings', 'ltp_form_default_navigation_mode');

        register_setting('ltp_settings', 'ltp_membership_provider');
        register_setting('ltp_settings', 'ltp_billing_provider');
        register_setting('ltp_settings', 'ltp_wc_product_map');
        register_setting('ltp_settings', 'ltp_base_monthly_prices');
        register_setting('ltp_settings', 'ltp_quarterly_discount_percentage');
        register_setting('ltp_settings', 'ltp_yearly_discount_percentage');
        register_setting('ltp_settings', 'ltp_dashboard_cta_content');
        register_setting('ltp_settings', 'ltp_tier_capability_map');
        register_setting('ltp_settings', 'ltp_custom_capabilities');
        register_setting('ltp_settings', 'ltp_tier_role_map');
        register_setting('ltp_settings', 'ltp_manual_grace_days');
        register_setting('ltp_settings', 'ltp_custom_recurring_retry_limit');
        register_setting('ltp_settings', 'ltp_custom_recurring_grace_days');
        register_setting('ltp_settings', 'ltp_autocreate_wc_products');
        register_setting('ltp_settings', 'ltp_marketing_content');

        register_setting('ltp_settings', 'ltp_memberpress_tier_membership_map');
        register_setting('ltp_settings', 'ltp_cda_student_membership_ids');
        register_setting('ltp_settings', 'ltp_member_course_discounts');
        register_setting('ltp_settings', 'ltp_pdf_watermark_tier_text');
        register_setting('ltp_settings', 'ltp_cda_exam_passing_score');
        register_setting('ltp_settings', 'ltp_cda_experience_hour_requirement');
        register_setting('ltp_settings', 'ltp_cda_registry_default_visibility');
        register_setting('ltp_settings', 'ltp_autocreate_cda_products');
    }
}
