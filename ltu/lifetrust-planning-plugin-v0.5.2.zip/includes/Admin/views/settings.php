<?php
if (!defined('ABSPATH')) { exit; }

use LifeTrustPlanning\Migration\Migration_Manager;
use LifeTrustPlanning\Membership\MemberPress_Provider;
use LifeTrustPlanning\Billing\Woo_Product_Manager;
use LifeTrustPlanning\CDA\Program_Manager;

$memberpress_options = MemberPress_Provider::membership_options();
$memberpress_map = MemberPress_Provider::get_tier_membership_map();
$student_membership_ids = array_map('absint', (array) get_option('ltp_cda_student_membership_ids', []));
$member_discounts = get_option('ltp_member_course_discounts', ['essential' => 15, 'premium' => 25, 'ultimate' => 35]);
$watermarks = get_option('ltp_pdf_watermark_tier_text', [
    'free' => 'PREVIEW - Upgrade to unlock full PDF',
    'student' => 'STUDENT - FOR EDUCATIONAL USE ONLY',
    'member' => '',
    'graduate' => '',
    'sandbox' => 'SANDBOX - NOT FOR CLIENT USE',
]);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('ltp_settings_save', 'ltp_settings_nonce')) {
    update_option('ltp_ai_primary_provider', sanitize_text_field($_POST['ltp_ai_primary_provider'] ?? 'gemini'));
    update_option('ltp_ai_fallback_providers', array_map('sanitize_text_field', (array) ($_POST['ltp_ai_fallback_providers'] ?? [])));
    update_option('ltp_ai_openai_api_key', sanitize_text_field($_POST['ltp_ai_openai_api_key'] ?? ''));
    update_option('ltp_ai_gemini_api_key', sanitize_text_field($_POST['ltp_ai_gemini_api_key'] ?? ''));
    update_option('ltp_ai_anthropic_api_key', sanitize_text_field($_POST['ltp_ai_anthropic_api_key'] ?? ''));
    update_option('ltp_ai_free_daily_limit', absint($_POST['ltp_ai_free_daily_limit'] ?? 5));
    update_option('ltp_form_default_navigation_mode', sanitize_text_field($_POST['ltp_form_default_navigation_mode'] ?? 'tab'));

    update_option('ltp_membership_provider', sanitize_key($_POST['ltp_membership_provider'] ?? 'memberpress'));
    update_option('ltp_billing_provider', sanitize_key($_POST['ltp_billing_provider'] ?? 'custom_recurring'));

    $base_monthly = [
        'essential' => (float) ($_POST['ltp_price_essential_monthly'] ?? 30),
        'premium' => (float) ($_POST['ltp_price_premium_monthly'] ?? 60),
        'ultimate' => (float) ($_POST['ltp_price_ultimate_monthly'] ?? 150),
    ];
    update_option('ltp_base_monthly_prices', $base_monthly);

    update_option('ltp_quarterly_discount_percentage', (float) ($_POST['ltp_quarterly_discount_percentage'] ?? 15));
    update_option('ltp_yearly_discount_percentage', (float) ($_POST['ltp_yearly_discount_percentage'] ?? 30));

    $custom_caps_raw = (string) ($_POST['ltp_custom_capabilities'] ?? '');
    $custom_caps = array_filter(array_map('sanitize_key', array_map('trim', explode("\n", $custom_caps_raw))));
    update_option('ltp_custom_capabilities', array_values($custom_caps));

    update_option('ltp_manual_grace_days', absint($_POST['ltp_manual_grace_days'] ?? 5));
    update_option('ltp_custom_recurring_retry_limit', absint($_POST['ltp_custom_recurring_retry_limit'] ?? 3));
    update_option('ltp_custom_recurring_grace_days', absint($_POST['ltp_custom_recurring_grace_days'] ?? 7));
    update_option('ltp_autocreate_wc_products', !empty($_POST['ltp_autocreate_wc_products']) ? 1 : 0);
    update_option('ltp_autocreate_cda_products', !empty($_POST['ltp_autocreate_cda_products']) ? 1 : 0);

    if (isset($_POST['ltp_dashboard_cta_content'])) {
        update_option('ltp_dashboard_cta_content', wp_kses_post((string) $_POST['ltp_dashboard_cta_content']));
    }

    $new_memberpress_map = [
        'free' => absint((int) ($_POST['ltp_mp_map_free'] ?? 0)),
        'essential' => absint((int) ($_POST['ltp_mp_map_essential'] ?? 0)),
        'premium' => absint((int) ($_POST['ltp_mp_map_premium'] ?? 0)),
        'ultimate' => absint((int) ($_POST['ltp_mp_map_ultimate'] ?? 0)),
        'graduate' => absint((int) ($_POST['ltp_mp_map_graduate'] ?? 0)),
    ];
    update_option('ltp_memberpress_tier_membership_map', $new_memberpress_map);

    update_option('ltp_cda_student_membership_ids', array_map('absint', (array) ($_POST['ltp_cda_student_membership_ids'] ?? [])));
    update_option('ltp_member_course_discounts', [
        'essential' => (float) ($_POST['ltp_member_discount_essential'] ?? 15),
        'premium' => (float) ($_POST['ltp_member_discount_premium'] ?? 25),
        'ultimate' => (float) ($_POST['ltp_member_discount_ultimate'] ?? 35),
    ]);

    update_option('ltp_pdf_watermark_tier_text', [
        'free' => sanitize_text_field((string) ($_POST['ltp_watermark_free'] ?? '')),
        'student' => sanitize_text_field((string) ($_POST['ltp_watermark_student'] ?? '')),
        'member' => sanitize_text_field((string) ($_POST['ltp_watermark_member'] ?? '')),
        'graduate' => sanitize_text_field((string) ($_POST['ltp_watermark_graduate'] ?? '')),
        'sandbox' => sanitize_text_field((string) ($_POST['ltp_watermark_sandbox'] ?? '')),
    ]);

    update_option('ltp_cda_exam_passing_score', absint((int) ($_POST['ltp_cda_exam_passing_score'] ?? 70)));
    update_option('ltp_cda_experience_hour_requirement', absint((int) ($_POST['ltp_cda_experience_hour_requirement'] ?? 1000)));
    update_option('ltp_cda_registry_default_visibility', !empty($_POST['ltp_cda_registry_default_visibility']) ? 1 : 0);

    if (!empty($_POST['ltp_regenerate_products'])) {
        Woo_Product_Manager::create_or_update_products(true);
    }
    if (!empty($_POST['ltp_regenerate_cda_products'])) {
        Program_Manager::create_or_update_cda_products();
    }

    echo '<div class="updated"><p>Settings saved.</p></div>';

    $memberpress_map = MemberPress_Provider::get_tier_membership_map();
    $student_membership_ids = array_map('absint', (array) get_option('ltp_cda_student_membership_ids', []));
    $member_discounts = get_option('ltp_member_course_discounts', ['essential' => 15, 'premium' => 25, 'ultimate' => 35]);
    $watermarks = get_option('ltp_pdf_watermark_tier_text', $watermarks);
}

$base_prices = get_option('ltp_base_monthly_prices', ['essential' => 30, 'premium' => 60, 'ultimate' => 150]);
$detections = Migration_Manager::detect_targets();
$custom_caps = implode("\n", (array) get_option('ltp_custom_capabilities', []));

$membership_select = static function(string $field_name, int $selected_id) use ($memberpress_options): string {
    $html = '<select name="' . esc_attr($field_name) . '"><option value="0">— Not mapped —</option>';
    foreach ($memberpress_options as $option) {
        $html .= '<option value="' . esc_attr((string) $option['id']) . '" ' . selected($selected_id, (int) $option['id'], false) . '>'
            . esc_html($option['name'] . ' (#' . $option['id'] . ', ' . $option['status'] . ')')
            . '</option>';
    }
    $html .= '</select>';
    return $html;
};
?>
<div class="wrap">
  <h1>LifeTrust Planning Settings</h1>
  <form method="post">
    <?php wp_nonce_field('ltp_settings_save', 'ltp_settings_nonce'); ?>

    <h2>AI Configuration</h2>
    <p><label>Primary Provider
      <select name="ltp_ai_primary_provider">
        <?php foreach (['gemini','openai','anthropic'] as $provider): ?>
          <option value="<?php echo esc_attr($provider); ?>" <?php selected(get_option('ltp_ai_primary_provider', 'gemini'), $provider); ?>><?php echo esc_html(ucfirst($provider)); ?></option>
        <?php endforeach; ?>
      </select>
    </label></p>

    <p><label>OpenAI API Key<br><input type="password" name="ltp_ai_openai_api_key" value="<?php echo esc_attr((string) get_option('ltp_ai_openai_api_key', '')); ?>" class="regular-text"></label></p>
    <p><label>Gemini API Key<br><input type="password" name="ltp_ai_gemini_api_key" value="<?php echo esc_attr((string) get_option('ltp_ai_gemini_api_key', '')); ?>" class="regular-text"></label></p>
    <p><label>Anthropic API Key<br><input type="password" name="ltp_ai_anthropic_api_key" value="<?php echo esc_attr((string) get_option('ltp_ai_anthropic_api_key', '')); ?>" class="regular-text"></label></p>
    <p><label>Free/Student Daily AI Limit<br><input type="number" name="ltp_ai_free_daily_limit" min="0" value="<?php echo esc_attr((string) get_option('ltp_ai_free_daily_limit', 5)); ?>"></label></p>

    <h2>Membership & Billing Providers</h2>
    <p><label>Membership Provider
      <select name="ltp_membership_provider">
        <option value="memberpress" <?php selected(get_option('ltp_membership_provider', 'memberpress'), 'memberpress'); ?>>MemberPress Growth (recommended)</option>
        <option value="members_legacy" <?php selected(get_option('ltp_membership_provider', 'memberpress'), 'members_legacy'); ?>>Legacy Members provider (migration fallback)</option>
      </select>
    </label></p>

    <p><label>Billing Provider
      <select name="ltp_billing_provider">
        <option value="custom_recurring" <?php selected(get_option('ltp_billing_provider', 'custom_recurring'), 'custom_recurring'); ?>>Custom Recurring (Woo gateways)</option>
        <option value="manual_renewal" <?php selected(get_option('ltp_billing_provider', 'custom_recurring'), 'manual_renewal'); ?>>Manual Renewal</option>
        <option value="wc_subscriptions" <?php selected(get_option('ltp_billing_provider', 'custom_recurring'), 'wc_subscriptions'); ?>>WooCommerce Subscriptions (if installed)</option>
      </select>
    </label></p>

    <h3>MemberPress Tier Mapping</h3>
    <p>Detected MemberPress memberships are listed below. Map each tier to a MemberPress membership product ID.</p>
    <table class="widefat striped" style="max-width:900px;">
      <thead><tr><th>Tier</th><th>Membership</th></tr></thead>
      <tbody>
        <tr><td>Free</td><td><?php echo $membership_select('ltp_mp_map_free', (int) ($memberpress_map['free'] ?? 0)); ?></td></tr>
        <tr><td>Essential</td><td><?php echo $membership_select('ltp_mp_map_essential', (int) ($memberpress_map['essential'] ?? 0)); ?></td></tr>
        <tr><td>Premium</td><td><?php echo $membership_select('ltp_mp_map_premium', (int) ($memberpress_map['premium'] ?? 0)); ?></td></tr>
        <tr><td>Ultimate</td><td><?php echo $membership_select('ltp_mp_map_ultimate', (int) ($memberpress_map['ultimate'] ?? 0)); ?></td></tr>
        <tr><td>Graduate</td><td><?php echo $membership_select('ltp_mp_map_graduate', (int) ($memberpress_map['graduate'] ?? 0)); ?></td></tr>
      </tbody>
    </table>

    <h3>CDA Student Membership Detection</h3>
    <p>Select the MemberPress membership IDs that should auto-mark users as CDA students.</p>
    <select name="ltp_cda_student_membership_ids[]" multiple size="6" style="min-width:420px;">
      <?php foreach ($memberpress_options as $option): ?>
        <option value="<?php echo esc_attr((string) $option['id']); ?>" <?php selected(in_array((int) $option['id'], $student_membership_ids, true), true); ?>>
          <?php echo esc_html($option['name'] . ' (#' . $option['id'] . ')'); ?>
        </option>
      <?php endforeach; ?>
    </select>

    <h2>Pricing & Discounts</h2>
    <p><label>Essential Monthly Base Price <input type="number" step="0.01" name="ltp_price_essential_monthly" value="<?php echo esc_attr((string) ($base_prices['essential'] ?? 30)); ?>"></label></p>
    <p><label>Premium Monthly Base Price <input type="number" step="0.01" name="ltp_price_premium_monthly" value="<?php echo esc_attr((string) ($base_prices['premium'] ?? 60)); ?>"></label></p>
    <p><label>Ultimate Monthly Base Price <input type="number" step="0.01" name="ltp_price_ultimate_monthly" value="<?php echo esc_attr((string) ($base_prices['ultimate'] ?? 150)); ?>"></label></p>
    <p><label>Quarterly Discount % <input type="number" step="0.01" name="ltp_quarterly_discount_percentage" value="<?php echo esc_attr((string) get_option('ltp_quarterly_discount_percentage', 15)); ?>"></label></p>
    <p><label>Yearly Discount % <input type="number" step="0.01" name="ltp_yearly_discount_percentage" value="<?php echo esc_attr((string) get_option('ltp_yearly_discount_percentage', 30)); ?>"></label></p>

    <h3>Member Discount on CDA Courses</h3>
    <p><label>Essential discount % <input type="number" step="0.01" name="ltp_member_discount_essential" value="<?php echo esc_attr((string) ($member_discounts['essential'] ?? 15)); ?>"></label></p>
    <p><label>Premium discount % <input type="number" step="0.01" name="ltp_member_discount_premium" value="<?php echo esc_attr((string) ($member_discounts['premium'] ?? 25)); ?>"></label></p>
    <p><label>Ultimate discount % <input type="number" step="0.01" name="ltp_member_discount_ultimate" value="<?php echo esc_attr((string) ($member_discounts['ultimate'] ?? 35)); ?>"></label></p>

    <p><label><input type="checkbox" name="ltp_autocreate_wc_products" value="1" <?php checked((int) get_option('ltp_autocreate_wc_products', 1), 1); ?>> Auto-create/update WooCommerce membership products</label></p>
    <p><label><input type="checkbox" name="ltp_autocreate_cda_products" value="1" <?php checked((int) get_option('ltp_autocreate_cda_products', 1), 1); ?>> Auto-create/update WooCommerce CDA course products</label></p>
    <p><label><input type="checkbox" name="ltp_regenerate_products" value="1"> Force regenerate membership products on save</label></p>
    <p><label><input type="checkbox" name="ltp_regenerate_cda_products" value="1"> Force regenerate CDA products on save</label></p>

    <h2>Watermarks</h2>
    <p><label>Free watermark <input type="text" name="ltp_watermark_free" class="regular-text" value="<?php echo esc_attr((string) ($watermarks['free'] ?? '')); ?>"></label></p>
    <p><label>Student watermark <input type="text" name="ltp_watermark_student" class="regular-text" value="<?php echo esc_attr((string) ($watermarks['student'] ?? '')); ?>"></label></p>
    <p><label>Member watermark (blank for none) <input type="text" name="ltp_watermark_member" class="regular-text" value="<?php echo esc_attr((string) ($watermarks['member'] ?? '')); ?>"></label></p>
    <p><label>Graduate watermark (blank for none) <input type="text" name="ltp_watermark_graduate" class="regular-text" value="<?php echo esc_attr((string) ($watermarks['graduate'] ?? '')); ?>"></label></p>
    <p><label>Sandbox watermark <input type="text" name="ltp_watermark_sandbox" class="regular-text" value="<?php echo esc_attr((string) ($watermarks['sandbox'] ?? '')); ?>"></label></p>

    <h2>CDA Program Settings</h2>
    <p><label>Exam passing score (%) <input type="number" min="1" max="100" name="ltp_cda_exam_passing_score" value="<?php echo esc_attr((string) get_option('ltp_cda_exam_passing_score', 70)); ?>"></label></p>
    <p><label>Experience hour requirement <input type="number" min="1" name="ltp_cda_experience_hour_requirement" value="<?php echo esc_attr((string) get_option('ltp_cda_experience_hour_requirement', 1000)); ?>"></label></p>
    <p><label><input type="checkbox" name="ltp_cda_registry_default_visibility" value="1" <?php checked((int) get_option('ltp_cda_registry_default_visibility', 1), 1); ?>> Graduates public by default in registry</label></p>

    <h2>Capability Extension</h2>
    <p>One capability per line.</p>
    <p><textarea name="ltp_custom_capabilities" rows="6" class="large-text code"><?php echo esc_textarea($custom_caps); ?></textarea></p>

    <h2>Billing Reliability Controls</h2>
    <p><label>Custom recurring retry limit <input type="number" min="0" name="ltp_custom_recurring_retry_limit" value="<?php echo esc_attr((string) get_option('ltp_custom_recurring_retry_limit', 3)); ?>"></label></p>
    <p><label>Custom recurring grace days <input type="number" min="0" name="ltp_custom_recurring_grace_days" value="<?php echo esc_attr((string) get_option('ltp_custom_recurring_grace_days', 7)); ?>"></label></p>
    <p><label>Manual renewal grace days <input type="number" min="0" name="ltp_manual_grace_days" value="<?php echo esc_attr((string) get_option('ltp_manual_grace_days', 5)); ?>"></label></p>

    <h2>Dashboard CTA</h2>
    <?php
      wp_editor(
          (string) get_option('ltp_dashboard_cta_content', '<p>Upgrade your plan to unlock more planning tools, AI workflows, and premium guidance.</p>'),
          'ltp_dashboard_cta_content',
          ['textarea_name' => 'ltp_dashboard_cta_content', 'textarea_rows' => 8]
      );
    ?>

    <h2>Form Settings</h2>
    <p><label>Default Navigation Mode
      <select name="ltp_form_default_navigation_mode">
        <option value="tab" <?php selected(get_option('ltp_form_default_navigation_mode', 'tab'), 'tab'); ?>>Tab-based</option>
        <option value="step" <?php selected(get_option('ltp_form_default_navigation_mode', 'tab'), 'step'); ?>>Step wizard</option>
      </select>
    </label></p>

    <h2>Migration Detection & Tools</h2>
    <ul>
      <li>WooCommerce Subscriptions detected: <strong><?php echo $detections['wc_subscriptions'] ? 'Yes' : 'No'; ?></strong></li>
      <li>MemberPress detected: <strong><?php echo $detections['memberpress'] ? 'Yes' : 'No'; ?></strong></li>
    </ul>

    <?php submit_button('Save Settings'); ?>
  </form>

  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:2rem;">
    <?php wp_nonce_field('ltp_run_migration_tool'); ?>
    <input type="hidden" name="action" value="ltp_run_migration_tool" />
    <select name="ltp_migration_action">
      <option value="export_to_wc_subscriptions">Export subscriptions to WooCommerce Subscriptions payload</option>
      <option value="export_to_memberpress">Export role/tier data to MemberPress payload</option>
      <option value="migrate_v004_to_memberpress">Migrate v0.0.4 role tiers to MemberPress tier meta/report</option>
      <option value="rollback">Rollback last migration snapshot</option>
    </select>
    <?php submit_button('Run Migration Tool', 'secondary', 'submit', false); ?>
  </form>
</div>
