<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap">
  <h1>LifeTrust Planning Documentation</h1>

  <h2>v0.0.3 Highlights</h2>
  <ul>
    <li>Professional pricing comparison components + shortcode system</li>
    <li>Marketing Content admin panel (editable tier copy/features/benefits/pricing)</li>
    <li>Member portal shortcode and default member pages</li>
    <li>Tier-based page/post content protection</li>
    <li>Elementor widget integration with shortcode fallback</li>
  </ul>

  <h2>Quick Start</h2>
  <ol>
    <li>Configure providers and billing in <strong>LifeTrust Planning → Settings</strong>.</li>
    <li>Configure tier copy and pricing in <strong>LifeTrust Planning → Marketing Content</strong>.</li>
    <li>Add pricing and member pages using shortcodes or Elementor widgets.</li>
    <li>Use Tier Access Control meta box on pages/posts to restrict content.</li>
  </ol>

  <h2>Core Shortcodes</h2>
  <ul>
    <li><code>[ltp_pricing_table]</code></li>
    <li><code>[ltp_tier_card tier="essential"]</code></li>
    <li><code>[ltp_member_portal]</code></li>
    <li><code>[ltp_tier_content tier="essential,premium"]...[/ltp_tier_content]</code></li>
  </ul>

  <h2>Full Docs</h2>
  <ul>
    <li><code>SETUP_INSTRUCTIONS.md</code></li>
    <li><code>SHORTCODE_REFERENCE.md</code></li>
    <li><code>docs/MEMBER_PAGES_GUIDE.md</code></li>
  </ul>

  <h2>Troubleshooting</h2>
  <ul>
    <li>If pricing CTAs are missing, regenerate/check WooCommerce product mapping.</li>
    <li>If AI fails, verify API keys and provider settings.</li>
    <li>If assets don’t load, reinstall from the official plugin ZIP to restore bundled files.</li>
    <li>If Elementor widgets do not appear, ensure Elementor is active (shortcodes still work).</li>
  </ul>
</div>
