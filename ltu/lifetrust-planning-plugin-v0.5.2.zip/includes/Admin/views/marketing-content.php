<?php
if (!defined('ABSPATH')) { exit; }

use LifeTrustPlanning\Marketing\Marketing_Content;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('ltp_marketing_content_save', 'ltp_marketing_content_nonce')) {
    if (!empty($_POST['ltp_reset_defaults'])) {
        Marketing_Content::reset_to_defaults();
        $message = 'Marketing content reset to defaults.';
    } elseif (!empty($_POST['ltp_import_content'])) {
        $ok = Marketing_Content::import_json((string) ($_POST['ltp_import_json'] ?? ''));
        if ($ok) {
            $message = 'Marketing content imported.';
        } else {
            $error = 'Import failed. Please provide valid JSON.';
        }
    } else {
        $existing = Marketing_Content::get();
        $incoming = $existing;

        $incoming['recommended_tier'] = sanitize_key((string) ($_POST['recommended_tier'] ?? 'essential'));
        $incoming['pricing_display']['currency_symbol'] = sanitize_text_field((string) ($_POST['currency_symbol'] ?? '$'));
        $incoming['pricing_display']['default_interval'] = sanitize_key((string) ($_POST['default_interval'] ?? 'monthly'));
        $incoming['pricing_display']['show_savings_badges'] = !empty($_POST['show_savings_badges']);

        foreach (['accent_color', 'essential_color', 'premium_color', 'ultimate_color', 'free_color', 'font_family'] as $style_key) {
            if (isset($_POST['styling'][$style_key])) {
                $incoming['styling'][$style_key] = (string) $_POST['styling'][$style_key];
            }
        }

        foreach (['free', 'essential', 'premium', 'ultimate'] as $tier) {
            $incoming['tiers'][$tier]['tagline'] = sanitize_text_field((string) ($_POST['tiers'][$tier]['tagline'] ?? ''));
            $incoming['tiers'][$tier]['name'] = sanitize_text_field((string) ($_POST['tiers'][$tier]['name'] ?? ucfirst($tier)));
            $incoming['tiers'][$tier]['description'] = wp_kses_post((string) ($_POST['tiers'][$tier]['description'] ?? ''));

            $features_raw = (string) ($_POST['tiers'][$tier]['features_text'] ?? '');
            $incoming['tiers'][$tier]['features'] = array_values(array_filter(array_map('trim', explode("\n", $features_raw))));

            $benefits_raw = (string) ($_POST['tiers'][$tier]['benefits_text'] ?? '');
            $incoming['tiers'][$tier]['benefits'] = array_values(array_filter(array_map('trim', explode("\n", $benefits_raw))));

            foreach (['monthly', 'quarterly', 'yearly'] as $interval) {
                $incoming['tiers'][$tier]['pricing'][$interval] = (float) ($_POST['tiers'][$tier]['pricing'][$interval] ?? 0);
                $incoming['tiers'][$tier]['savings'][$interval] = (float) ($_POST['tiers'][$tier]['savings'][$interval] ?? 0);
            }
        }

        $rows_raw = (string) ($_POST['comparison_rows'] ?? '');
        $rows = [];
        foreach (array_filter(array_map('trim', explode("\n", $rows_raw))) as $line) {
            $parts = array_map('trim', explode('|', $line));
            if (count($parts) < 5) {
                continue;
            }
            $row = ['label' => $parts[0]];
            foreach (['free', 'essential', 'premium', 'ultimate'] as $index => $tier) {
                $value = strtolower($parts[$index + 1]);
                if (in_array($value, ['yes', 'true', '1', 'check', '✔'], true)) {
                    $row[$tier] = true;
                } elseif (in_array($value, ['no', 'false', '0', 'x', '✖'], true)) {
                    $row[$tier] = false;
                } else {
                    $row[$tier] = $parts[$index + 1];
                }
            }
            $rows[] = $row;
        }
        $incoming['comparison_features'] = $rows;

        Marketing_Content::save($incoming);
        $message = 'Marketing content updated.';
    }
}

$content = Marketing_Content::get();
$comparison_rows = [];
foreach ((array) $content['comparison_features'] as $row) {
    $parts = [(string) ($row['label'] ?? '')];
    foreach (['free', 'essential', 'premium', 'ultimate'] as $tier) {
        $value = $row[$tier] ?? '';
        if (is_bool($value)) {
            $parts[] = $value ? 'yes' : 'no';
        } else {
            $parts[] = (string) $value;
        }
    }
    $comparison_rows[] = implode(' | ', $parts);
}
?>
<div class="wrap">
    <h1>Marketing Content</h1>
    <?php if ($message): ?><div class="updated"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
    <?php if ($error): ?><div class="error"><p><?php echo esc_html($error); ?></p></div><?php endif; ?>

    <form method="post">
        <?php wp_nonce_field('ltp_marketing_content_save', 'ltp_marketing_content_nonce'); ?>

        <h2>Global Display Options</h2>
        <p><label>Recommended Tier
            <select name="recommended_tier">
                <?php foreach (['essential', 'premium'] as $tier): ?>
                    <option value="<?php echo esc_attr($tier); ?>" <?php selected($content['recommended_tier'], $tier); ?>><?php echo esc_html(ucfirst($tier)); ?></option>
                <?php endforeach; ?>
            </select>
        </label></p>
        <p><label>Currency Symbol <input type="text" name="currency_symbol" value="<?php echo esc_attr((string) $content['pricing_display']['currency_symbol']); ?>" style="width:80px;"></label></p>
        <p><label>Default Interval
            <select name="default_interval">
                <?php foreach (['monthly', 'quarterly', 'yearly'] as $interval): ?>
                    <option value="<?php echo esc_attr($interval); ?>" <?php selected($content['pricing_display']['default_interval'], $interval); ?>><?php echo esc_html(ucfirst($interval)); ?></option>
                <?php endforeach; ?>
            </select>
        </label></p>
        <p><label><input type="checkbox" name="show_savings_badges" value="1" <?php checked(!empty($content['pricing_display']['show_savings_badges'])); ?>> Show savings badges</label></p>

        <h2>Table Styling</h2>
        <p><label>Accent Color <input type="color" name="styling[accent_color]" value="<?php echo esc_attr((string) $content['styling']['accent_color']); ?>"></label></p>
        <p><label>Free Color <input type="color" name="styling[free_color]" value="<?php echo esc_attr((string) $content['styling']['free_color']); ?>"></label></p>
        <p><label>Essential Color <input type="color" name="styling[essential_color]" value="<?php echo esc_attr((string) $content['styling']['essential_color']); ?>"></label></p>
        <p><label>Premium Color <input type="color" name="styling[premium_color]" value="<?php echo esc_attr((string) $content['styling']['premium_color']); ?>"></label></p>
        <p><label>Ultimate Color <input type="color" name="styling[ultimate_color]" value="<?php echo esc_attr((string) $content['styling']['ultimate_color']); ?>"></label></p>
        <p><label>Font Family <input type="text" class="regular-text" name="styling[font_family]" value="<?php echo esc_attr((string) $content['styling']['font_family']); ?>"></label></p>

        <?php foreach (['free', 'essential', 'premium', 'ultimate'] as $tier):
            $tier_data = $content['tiers'][$tier];
            ?>
            <hr>
            <h2><?php echo esc_html(ucfirst($tier)); ?> Tier Content</h2>
            <p><label>Name <input type="text" name="tiers[<?php echo esc_attr($tier); ?>][name]" value="<?php echo esc_attr((string) $tier_data['name']); ?>"></label></p>
            <p><label>Tagline <input type="text" class="regular-text" name="tiers[<?php echo esc_attr($tier); ?>][tagline]" value="<?php echo esc_attr((string) $tier_data['tagline']); ?>"></label></p>
            <?php
                wp_editor(
                    (string) $tier_data['description'],
                    'ltp_desc_' . $tier,
                    [
                        'textarea_name' => 'tiers[' . $tier . '][description]',
                        'textarea_rows' => 5,
                    ]
                );
            ?>
            <p><label>Features (one per line)<br>
                <textarea name="tiers[<?php echo esc_attr($tier); ?>][features_text]" rows="5" class="large-text code"><?php echo esc_textarea(implode("\n", (array) $tier_data['features'])); ?></textarea>
            </label></p>
            <p><label>Benefits (one per line)<br>
                <textarea name="tiers[<?php echo esc_attr($tier); ?>][benefits_text]" rows="3" class="large-text"><?php echo esc_textarea(implode("\n", (array) $tier_data['benefits'])); ?></textarea>
            </label></p>
            <p>
                <label>Monthly <input type="number" step="0.01" name="tiers[<?php echo esc_attr($tier); ?>][pricing][monthly]" value="<?php echo esc_attr((string) $tier_data['pricing']['monthly']); ?>"></label>
                <label>Quarterly <input type="number" step="0.01" name="tiers[<?php echo esc_attr($tier); ?>][pricing][quarterly]" value="<?php echo esc_attr((string) $tier_data['pricing']['quarterly']); ?>"></label>
                <label>Yearly <input type="number" step="0.01" name="tiers[<?php echo esc_attr($tier); ?>][pricing][yearly]" value="<?php echo esc_attr((string) $tier_data['pricing']['yearly']); ?>"></label>
            </p>
            <p>
                <label>Quarterly Savings % <input type="number" step="0.01" name="tiers[<?php echo esc_attr($tier); ?>][savings][quarterly]" value="<?php echo esc_attr((string) $tier_data['savings']['quarterly']); ?>"></label>
                <label>Yearly Savings % <input type="number" step="0.01" name="tiers[<?php echo esc_attr($tier); ?>][savings][yearly]" value="<?php echo esc_attr((string) $tier_data['savings']['yearly']); ?>"></label>
            </p>
        <?php endforeach; ?>

        <h2>Feature Comparison Rows</h2>
        <p>One row per line using format: <code>Label | free | essential | premium | ultimate</code>. Values can be yes/no or text.</p>
        <textarea name="comparison_rows" rows="10" class="large-text code"><?php echo esc_textarea(implode("\n", $comparison_rows)); ?></textarea>

        <?php submit_button('Save Marketing Content'); ?>
        <p><button type="submit" name="ltp_reset_defaults" value="1" class="button">Reset to Default</button></p>
    </form>

    <h2>Import / Export</h2>
    <form method="post">
        <?php wp_nonce_field('ltp_marketing_content_save', 'ltp_marketing_content_nonce'); ?>
        <textarea name="ltp_import_json" rows="10" class="large-text code" placeholder="Paste exported JSON here..."></textarea>
        <p>
            <button type="submit" name="ltp_import_content" value="1" class="button button-secondary">Import Marketing Content</button>
        </p>
    </form>
    <p><strong>Export JSON</strong></p>
    <textarea rows="10" class="large-text code" readonly><?php echo esc_textarea(Marketing_Content::export_json()); ?></textarea>

    <h2>Preview</h2>
    <?php echo Marketing_Renderer::render_pricing_table(['interval' => 'monthly']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
