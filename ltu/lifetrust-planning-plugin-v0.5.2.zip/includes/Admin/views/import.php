<?php
if (!defined('ABSPATH')) { exit; }

use LifeTrustPlanning\Content\Content_Importer;

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('ltp_import', 'ltp_import_nonce')) {
    if (!empty($_FILES['ltp_import_file']['tmp_name'])) {
        $result = Content_Importer::import_file($_FILES['ltp_import_file']['tmp_name']);
        $message = $result['message'] ?? 'Import complete.';
    } elseif (!empty($_POST['ltp_import_path'])) {
        $result = Content_Importer::import_file(sanitize_text_field($_POST['ltp_import_path']));
        $message = $result['message'] ?? 'Import complete.';
    } elseif (!empty($_POST['ltp_seed_dummy'])) {
        Content_Importer::seed_dummy_content();
        $message = 'Dummy content generated.';
    }
}
?>
<div class="wrap">
  <h1>Knowledge Base Import</h1>
  <?php if ($message): ?><div class="notice notice-info"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
  <p>Import XML, JSON, or CSV after activation. If no source exists yet, generate dummy articles.</p>

  <form method="post" enctype="multipart/form-data">
    <?php wp_nonce_field('ltp_import', 'ltp_import_nonce'); ?>
    <p><label>Upload import file (XML/JSON/CSV): <input type="file" name="ltp_import_file" accept=".xml,.json,.csv"></label></p>
    <p><label>Or server file path: <input type="text" class="regular-text" name="ltp_import_path" placeholder="/path/to/file.json"></label></p>
    <p><label><input type="checkbox" name="ltp_seed_dummy" value="1"> Generate dummy content if no real file available.</label></p>
    <?php submit_button('Run Import'); ?>
  </form>
</div>
