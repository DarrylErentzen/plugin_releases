<?php

namespace LifeTrustPlanning\Admin;

class Admin_Menu {
    public static function register(): void {
        add_menu_page(
            __('LifeTrust Planning', 'lifetrust-planning'),
            __('LifeTrust Planning', 'lifetrust-planning'),
            'manage_options',
            'lifetrust-planning',
            [self::class, 'render_settings_page'],
            'dashicons-shield',
            56
        );

        add_submenu_page('lifetrust-planning', 'Settings', 'Settings', 'manage_options', 'lifetrust-planning', [self::class, 'render_settings_page']);
        add_submenu_page('lifetrust-planning', 'Content Import', 'Content Import', 'manage_options', 'lifetrust-planning-import', [self::class, 'render_import_page']);
        add_submenu_page('lifetrust-planning', 'Marketing Content', 'Marketing Content', 'manage_options', 'lifetrust-planning-marketing', [self::class, 'render_marketing_page']);
        add_submenu_page('lifetrust-planning', 'Documentation', 'Documentation', 'manage_options', 'lifetrust-planning-docs', [self::class, 'render_docs_page']);
    }

    public static function render_settings_page(): void {
        include LTP_PLUGIN_DIR . 'includes/Admin/views/settings.php';
    }

    public static function render_import_page(): void {
        include LTP_PLUGIN_DIR . 'includes/Admin/views/import.php';
    }

    public static function render_marketing_page(): void {
        include LTP_PLUGIN_DIR . 'includes/Admin/views/marketing-content.php';
    }

    public static function render_docs_page(): void {
        include LTP_PLUGIN_DIR . 'includes/Admin/views/docs.php';
    }
}
