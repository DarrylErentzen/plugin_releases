<?php

namespace LifeTrustPlanning\Migration;

class Migration_Manager {
    public static function init(): void {
        add_action('admin_post_ltp_run_migration_tool', [self::class, 'handle_admin_tool_action']);
    }

    public static function detect_targets(): array {
        return [
            'wc_subscriptions' => function_exists('wcs_get_subscriptions') || class_exists('WC_Subscriptions'),
            'memberpress' => class_exists('MeprProduct') || defined('MEPR_PLUGIN_SLUG'),
        ];
    }

    public static function handle_admin_tool_action(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        check_admin_referer('ltp_run_migration_tool');

        $action = sanitize_key((string) ($_POST['ltp_migration_action'] ?? ''));

        self::create_rollback_snapshot();

        switch ($action) {
            case 'export_to_wc_subscriptions':
                self::export_subscriptions_for_wc_subscriptions();
                break;
            case 'export_to_memberpress':
                self::export_roles_for_memberpress();
                break;
            case 'rollback':
                self::rollback_last_snapshot();
                break;
            case 'migrate_v004_to_memberpress':
                self::migrate_v004_roles_to_memberpress_meta();
                break;
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('admin.php?page=lifetrust-planning'));
        exit;
    }

    private static function create_rollback_snapshot(): void {
        global $wpdb;
        $snapshot = [
            'created_at' => current_time('mysql'),
            'subscriptions' => $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ltp_subscriptions", ARRAY_A),
            'billing_history' => $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ltp_billing_history", ARRAY_A),
        ];

        update_option('ltp_last_migration_snapshot', $snapshot, false);
    }

    private static function rollback_last_snapshot(): void {
        global $wpdb;
        $snapshot = get_option('ltp_last_migration_snapshot', []);
        if (empty($snapshot['subscriptions'])) {
            return;
        }

        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}ltp_subscriptions");
        foreach ($snapshot['subscriptions'] as $row) {
            $wpdb->insert($wpdb->prefix . 'ltp_subscriptions', $row);
        }

        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}ltp_billing_history");
        foreach ((array) ($snapshot['billing_history'] ?? []) as $row) {
            $wpdb->insert($wpdb->prefix . 'ltp_billing_history', $row);
        }
    }

    private static function export_subscriptions_for_wc_subscriptions(): void {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ltp_subscriptions", ARRAY_A);
        update_option('ltp_migration_wc_subscriptions_payload', $rows, false);
    }

    private static function export_roles_for_memberpress(): void {
        $payload = [
            'generated_at' => current_time('mysql'),
            'role_map' => get_option('ltp_tier_role_map', []),
            'tier_caps' => get_option('ltp_tier_capability_map', []),
            'users' => self::collect_user_tiers(),
        ];

        update_option('ltp_migration_memberpress_payload', $payload, false);
    }

    private static function collect_user_tiers(): array {
        $users = get_users(['fields' => ['ID']]);
        $out = [];
        foreach ($users as $user) {
            $out[] = [
                'user_id' => $user->ID,
                'tier' => get_user_meta($user->ID, '_ltp_active_tier', true) ?: 'free',
            ];
        }
        return $out;
    }

    private static function migrate_v004_roles_to_memberpress_meta(): void {
        $role_to_tier = [
            'ltp_free' => 'free',
            'ltp_essential' => 'essential',
            'ltp_premium' => 'premium',
            'ltp_ultimate' => 'ultimate',
            'ltp_graduate' => 'graduate',
        ];

        $users = get_users(['fields' => ['ID', 'roles']]);
        $report = [
            'ran_at' => current_time('mysql'),
            'migrated' => 0,
            'users' => [],
            'errors' => [],
        ];

        foreach ($users as $user) {
            $target_tier = 'free';
            foreach ((array) $user->roles as $role) {
                if (isset($role_to_tier[$role])) {
                    $target_tier = $role_to_tier[$role];
                    break;
                }
            }

            update_user_meta($user->ID, '_ltp_active_tier', $target_tier);
            update_user_meta($user->ID, '_ltp_migrated_from_v004', 1);
            $report['migrated']++;
            $report['users'][] = ['user_id' => $user->ID, 'tier' => $target_tier];
        }

        update_option('ltp_v050_migration_report', $report, false);
    }
}
