<?php

namespace LifeTrustPlanning\Migration;

use LifeTrustPlanning\CDA\Data_Store;
use LifeTrustPlanning\Marketing\Marketing_Content;

class Upgrade_Manager {
    public static function maybe_run_upgrade(): void {
        $current = (string) get_option('ltp_schema_version', '0.0.1');

        if (version_compare($current, '0.0.2', '<')) {
            self::migrate_billing_subscriptions_table();
        }

        if (version_compare($current, '0.0.3', '<')) {
            self::migrate_marketing_content_defaults();
            self::sync_pricing_defaults();
        }

        if (version_compare($current, '0.5.0', '<')) {
            self::migrate_v004_to_v050();
            update_option('ltp_schema_version', '0.5.0');
        }

        if (version_compare($current, '0.5.2', '<')) {
            update_option('ltp_schema_version', '0.5.2');
        }
    }

    private static function migrate_billing_subscriptions_table(): void {
        global $wpdb;
        $legacy = $wpdb->prefix . 'ltp_billing_subscriptions';
        $new = $wpdb->prefix . 'ltp_subscriptions';

        $legacy_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $legacy));
        if (!$legacy_exists) {
            return;
        }

        $rows = $wpdb->get_results("SELECT * FROM {$legacy}", ARRAY_A) ?: [];
        foreach ($rows as $row) {
            $wpdb->insert($new, [
                'user_id' => (int) ($row['user_id'] ?? 0),
                'tier' => sanitize_key((string) ($row['tier'] ?? 'free')),
                'billing_interval' => sanitize_key((string) ($row['billing_period'] ?? 'monthly')),
                'provider_key' => 'custom_recurring',
                'status' => sanitize_key((string) ($row['status'] ?? 'active')),
                'next_billing_at' => !empty($row['next_billing_date']) ? ($row['next_billing_date'] . ' 00:00:00') : null,
                'created_at' => (string) ($row['created_at'] ?? current_time('mysql')),
                'updated_at' => (string) ($row['updated_at'] ?? current_time('mysql')),
                'cancelled_at' => $row['cancelled_at'] ?? null,
            ]);
        }
    }

    private static function migrate_marketing_content_defaults(): void {
        $content = get_option('ltp_marketing_content', []);
        if (!is_array($content) || empty($content)) {
            update_option('ltp_marketing_content', Marketing_Content::get_defaults());
            return;
        }

        update_option('ltp_marketing_content', Marketing_Content::sanitize($content));
    }

    private static function sync_pricing_defaults(): void {
        $base = get_option('ltp_base_monthly_prices', []);
        if (!is_array($base)) {
            $base = [];
        }

        if (empty($base['ultimate']) || (float) $base['ultimate'] < 150) {
            $base['ultimate'] = 150;
        }

        if (empty($base['essential'])) {
            $base['essential'] = 30;
        }

        if (empty($base['premium'])) {
            $base['premium'] = 60;
        }

        update_option('ltp_base_monthly_prices', $base);
    }

    private static function migrate_v004_to_v050(): void {
        Data_Store::create_tables();

        if (!get_option('ltp_membership_provider')) {
            update_option('ltp_membership_provider', 'memberpress');
        }

        $role_to_tier = [
            'ltp_free' => 'free',
            'ltp_essential' => 'essential',
            'ltp_premium' => 'premium',
            'ltp_ultimate' => 'ultimate',
            'ltp_graduate' => 'graduate',
        ];

        $users = get_users(['fields' => ['ID', 'roles']]);
        $report = [
            'migration' => 'v0.0.4_to_v0.5.0',
            'ran_at' => current_time('mysql'),
            'total_users' => count($users),
            'tier_updates' => 0,
            'notes' => [
                'Existing form submissions and billing history were preserved in-place.',
                'Role-driven tiers migrated to _ltp_active_tier user meta for MemberPress mapping.',
            ],
            'users' => [],
        ];

        foreach ($users as $user) {
            $tier = 'free';
            foreach ((array) $user->roles as $role) {
                if (isset($role_to_tier[$role])) {
                    $tier = $role_to_tier[$role];
                    break;
                }
            }
            update_user_meta($user->ID, '_ltp_active_tier', $tier);
            $report['tier_updates']++;
            $report['users'][] = ['user_id' => $user->ID, 'tier' => $tier];
        }

        update_option('ltp_v050_migration_report', $report, false);
    }
}
