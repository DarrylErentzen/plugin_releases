<?php

namespace LifeTrustPlanning;

use LifeTrustPlanning\Admin\Admin_Menu;
use LifeTrustPlanning\Billing\Billing_Manager;
use LifeTrustPlanning\Billing\Dashboard_CTA;
use LifeTrustPlanning\Billing\Woo_Product_Manager;
use LifeTrustPlanning\Content\Content_Importer;
use LifeTrustPlanning\CDA\Program_Manager;
use LifeTrustPlanning\Content\Content_Post_Types;
use LifeTrustPlanning\Content\Content_Protection;
use LifeTrustPlanning\Content\Content_Taxonomies;
use LifeTrustPlanning\Elementor\Integration as Elementor_Integration;
use LifeTrustPlanning\Marketing\Marketing_Content;
use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Documents\Document_Types;
use LifeTrustPlanning\Membership\Free_Tier_Signup;
use LifeTrustPlanning\Membership\Membership_Manager;
use LifeTrustPlanning\Migration\Migration_Manager;
use LifeTrustPlanning\Migration\Upgrade_Manager;
use LifeTrustPlanning\REST\REST_AI_Controller;
use LifeTrustPlanning\REST\REST_Billing_Controller;
use LifeTrustPlanning\REST\REST_Content_Controller;
use LifeTrustPlanning\REST\REST_Documents_Controller;
use LifeTrustPlanning\REST\REST_PDF_Controller;

class Plugin {
    public function run(): void {
        add_action('init', [Content_Post_Types::class, 'register']);
        add_action('init', [Content_Taxonomies::class, 'register']);
        add_action('init', [Document_Types::class, 'register_defaults']);
        add_action('init', [Shortcodes::class, 'register']);
        add_action('init', [Marketing_Content::class, 'get']);

        add_action('admin_init', [Admin\Settings::class, 'register_settings']);
        add_action('admin_menu', [Admin_Menu::class, 'register']);

        add_action('rest_api_init', [REST_Documents_Controller::class, 'register_routes']);
        add_action('rest_api_init', [REST_AI_Controller::class, 'register_routes']);
        add_action('rest_api_init', [REST_PDF_Controller::class, 'register_routes']);
        add_action('rest_api_init', [REST_Billing_Controller::class, 'register_routes']);
        add_action('rest_api_init', [REST_Content_Controller::class, 'register_routes']);

        add_action('wp_enqueue_scripts', [Assets::class, 'register']);

        $membership = new Membership_Manager();
        $membership->init();

        $billing = new Billing_Manager();
        $billing->init();

        Free_Tier_Signup::init();
        Dashboard_CTA::init();
        Woo_Product_Manager::init();
        Program_Manager::init();
        Migration_Manager::init();
        Content_Protection::init();
        Elementor_Integration::init();

        add_action('plugins_loaded', [Upgrade_Manager::class, 'maybe_run_upgrade'], 25);

        add_action('ltp_content_auto_update', [AI\AI_Content_Updater::class, 'run_auto_update']);

        // Optional post-activation seed if no import file has been supplied.
        add_action('admin_init', [Content_Importer::class, 'maybe_seed_after_activation']);

        // Ensure daily counters are clean.
        add_action('init', [Tier_Access::class, 'cleanup_old_ai_counters']);
    }
}
