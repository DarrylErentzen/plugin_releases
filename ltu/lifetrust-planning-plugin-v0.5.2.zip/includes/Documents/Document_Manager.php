<?php

namespace LifeTrustPlanning\Documents;

use WP_Error;

class Document_Manager {
    public static function create(array $payload, int $user_id): array|WP_Error {
        $type = sanitize_key($payload['type'] ?? '');
        if (!Document_Types::get($type)) {
            return new WP_Error('invalid_type', 'Unknown document type', ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_documents';

        $wpdb->insert($table, [
            'user_id' => $user_id,
            'type' => $type,
            'title' => sanitize_text_field($payload['title'] ?? 'Untitled'),
            'status' => sanitize_text_field($payload['status'] ?? 'draft'),
            'content' => wp_json_encode($payload['content'] ?? []),
            'province' => sanitize_text_field(($payload['content']['province'] ?? '') ?: ''),
        ]);

        $id = (int) $wpdb->insert_id;
        do_action('ltp_document_created', $id, $type, $user_id);

        return self::get($id, $user_id);
    }

    public static function update(int $id, array $payload, int $user_id): bool|WP_Error {
        $doc = self::get($id, $user_id);
        if (!$doc) {
            return new WP_Error('not_found', 'Document not found', ['status' => 404]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_documents';

        $updates = [];
        if (array_key_exists('content', $payload)) {
            $updates['content'] = wp_json_encode($payload['content']);
            $updates['progress_percentage'] = self::calculate_progress((string) $doc->type, (array) $payload['content']);
        }

        if (isset($payload['status'])) {
            $updates['status'] = sanitize_text_field((string) $payload['status']);
            if ($updates['status'] === 'completed') {
                $errors = (new Form_Validator())->validate((string) $doc->type, (array) ($payload['content'] ?? json_decode((string) $doc->content, true)));
                if (!empty($errors)) {
                    return new WP_Error('validation_failed', 'Form has errors', ['status' => 422, 'errors' => $errors]);
                }
                do_action('ltp_document_completed', $id);
            }
        }

        if (empty($updates)) {
            return true;
        }

        $wpdb->update($table, $updates, ['id' => $id]);
        return true;
    }

    public static function get(int $id, int $user_id): ?object {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_documents';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));

        if (!$row || (int) $row->user_id !== $user_id) {
            return null;
        }

        return $row;
    }

    public static function list(int $user_id): array {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_documents';
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE user_id=%d ORDER BY updated_at DESC", $user_id)) ?: [];
    }

    private static function calculate_progress(string $type, array $content): int {
        if ($type !== 'henson_trust') {
            return 0;
        }

        $required = ['trustName', 'effectiveDate', 'province', 'beneficiaryName', 'primaryTrusteeName'];
        $filled = 0;
        foreach ($required as $field) {
            if (!empty($content[$field])) {
                $filled++;
            }
        }

        return (int) round(($filled / count($required)) * 100);
    }
}
