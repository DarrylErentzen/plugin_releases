<?php

namespace LifeTrustPlanning\Documents;

class Document_Types {
    private static array $types = [];

    public static function register(string $slug, array $config): void {
        self::$types[$slug] = wp_parse_args($config, [
            'label' => '',
            'pdf_template' => '',
            'tabs' => [],
            'tiers' => ['free', 'essential', 'premium', 'ultimate'],
            'schema' => [],
        ]);
    }

    public static function register_defaults(): void {
        if (!empty(self::$types)) {
            return;
        }

        self::register('henson_trust', [
            'label' => 'Henson Trust Agreement',
            'pdf_template' => 'henson-trust',
            'tabs' => [
                ['id' => 'trust_info', 'label' => 'Trust Information'],
                ['id' => 'settlors', 'label' => 'Settlor(s)'],
                ['id' => 'beneficiary', 'label' => 'Beneficiary'],
                ['id' => 'trustees', 'label' => 'Trustees'],
                ['id' => 'personal_reps', 'label' => 'Personal Representatives'],
                ['id' => 'remainder_beneficiaries', 'label' => 'Remainder Beneficiaries'],
                ['id' => 'trust_estate', 'label' => 'Trust Estate'],
                ['id' => 'distribution_guidelines', 'label' => 'Distribution Guidelines'],
                ['id' => 'termination_compensation', 'label' => 'Termination & Compensation'],
                ['id' => 'letter_of_intent', 'label' => 'Letter of Intent'],
                ['id' => 'witnesses', 'label' => 'Witnesses'],
            ],
        ]);
    }

    public static function get(string $slug): ?array {
        return self::$types[$slug] ?? null;
    }

    public static function get_all(): array {
        return self::$types;
    }
}
