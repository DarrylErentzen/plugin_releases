<?php

namespace LifeTrustPlanning\Documents;

class Form_Validator {
    public function validate(string $type, array $data): array {
        if ($type !== 'henson_trust') {
            return [];
        }

        $errors = [];

        if (empty($data['trustName'])) {
            $errors['trustName'] = 'Trust name is required.';
        }
        if (empty($data['effectiveDate'])) {
            $errors['effectiveDate'] = 'Effective date is required.';
        }
        if (empty($data['province'])) {
            $errors['province'] = 'Province is required.';
        }

        $remainder = $data['remainderBeneficiaries'] ?? [];
        if (!is_array($remainder) || count($remainder) === 0) {
            $errors['remainderBeneficiaries'] = 'At least one remainder beneficiary is required.';
        } else {
            $total = 0;
            foreach ($remainder as $idx => $item) {
                $pct = (float) ($item['percentage'] ?? 0);
                $total += $pct;
                if ($pct < 0 || $pct > 100) {
                    $errors["remainderBeneficiaries.{$idx}.percentage"] = 'Percentage must be between 0 and 100.';
                }
            }
            if (round($total, 2) !== 100.0) {
                $errors['remainderBeneficiaries.total'] = 'Remainder beneficiary percentages must equal exactly 100%.';
            }
        }

        return $errors;
    }
}
