<?php

namespace LifeTrustPlanning\Marketing;

class Marketing_Content {
    public const OPTION_KEY = 'ltp_marketing_content';

    public static function get_defaults(): array {
        return [
            'recommended_tier' => 'essential',
            'pricing_display' => [
                'currency_symbol' => '$',
                'show_savings_badges' => true,
                'default_interval' => 'monthly',
            ],
            'styling' => [
                'accent_color' => '#1453ff',
                'essential_color' => '#1453ff',
                'premium_color' => '#6d28d9',
                'ultimate_color' => '#0f766e',
                'free_color' => '#475569',
                'font_family' => "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
            ],
            'tiers' => [
                'free' => [
                    'name' => 'Free',
                    'tagline' => 'Try Before You Buy',
                    'description' => '<p>Test-drive LifeTrust Planning with no commitment. Preview forms, explore workflows, and get a feel for the platform.</p>',
                    'features' => [
                        'View forms and planning workflows',
                        'Save drafts (locked until upgrade)',
                        '5 AI queries/day',
                        'Preview mode',
                    ],
                    'benefits' => [
                        'Explore the platform risk-free',
                    ],
                    'pricing' => [
                        'monthly' => 0,
                        'quarterly' => 0,
                        'yearly' => 0,
                    ],
                    'savings' => [
                        'quarterly' => 0,
                        'yearly' => 0,
                    ],
                ],
                'essential' => [
                    'name' => 'Essential',
                    'tagline' => 'Everything You Need to Get Started',
                    'description' => '<p>Unlock full access to the core planning suite, unlimited AI guidance, and downloadable documents.</p>',
                    'features' => [
                        'All forms and workflows',
                        'Unlimited AI assistance',
                        'PDF downloads',
                        'Full access to saved drafts',
                    ],
                    'benefits' => [
                        'Complete your special needs planning documents with AI assistance',
                    ],
                    'pricing' => [
                        'monthly' => 30,
                        'quarterly' => 76.50,
                        'yearly' => 252,
                    ],
                    'savings' => [
                        'quarterly' => 15,
                        'yearly' => 30,
                    ],
                ],
                'premium' => [
                    'name' => 'Premium',
                    'tagline' => 'For Families with Complex Needs',
                    'description' => '<p>Designed for advanced planning scenarios with deeper guidance and higher-touch support.</p>',
                    'features' => [
                        'Everything in Essential',
                        'Multi-beneficiary support',
                        'Advanced AI guidance',
                        'Priority support',
                    ],
                    'benefits' => [
                        'Manage multiple beneficiaries and complex family situations',
                    ],
                    'pricing' => [
                        'monthly' => 60,
                        'quarterly' => 153,
                        'yearly' => 504,
                    ],
                    'savings' => [
                        'quarterly' => 15,
                        'yearly' => 30,
                    ],
                ],
                'ultimate' => [
                    'name' => 'Ultimate',
                    'tagline' => 'Professional Solution for Law Firms',
                    'description' => '<p>Scale operations with multi-client and team-ready capabilities for professional practices.</p>',
                    'features' => [
                        'Everything in Premium',
                        'Multi-tenant workspace',
                        'Client management tools',
                        'Team collaboration features',
                    ],
                    'benefits' => [
                        'Serve multiple clients with professional-grade tools',
                    ],
                    'pricing' => [
                        'monthly' => 150,
                        'quarterly' => 382.50,
                        'yearly' => 1260,
                    ],
                    'savings' => [
                        'quarterly' => 15,
                        'yearly' => 30,
                    ],
                ],
            ],
            'comparison_features' => [
                ['label' => 'Form Preview', 'free' => true, 'essential' => true, 'premium' => true, 'ultimate' => true],
                ['label' => 'Full Form Access', 'free' => false, 'essential' => true, 'premium' => true, 'ultimate' => true],
                ['label' => 'AI Usage', 'free' => '5/day', 'essential' => 'Unlimited', 'premium' => 'Unlimited + Advanced', 'ultimate' => 'Unlimited + Advanced'],
                ['label' => 'PDF Downloads', 'free' => false, 'essential' => true, 'premium' => true, 'ultimate' => true],
                ['label' => 'Draft Access', 'free' => 'Locked', 'essential' => true, 'premium' => true, 'ultimate' => true],
                ['label' => 'Multi-Beneficiary Support', 'free' => false, 'essential' => false, 'premium' => true, 'ultimate' => true],
                ['label' => 'Priority Support', 'free' => false, 'essential' => false, 'premium' => true, 'ultimate' => true],
                ['label' => 'Team Collaboration', 'free' => false, 'essential' => false, 'premium' => false, 'ultimate' => true],
                ['label' => 'Client Management', 'free' => false, 'essential' => false, 'premium' => false, 'ultimate' => true],
            ],
        ];
    }

    public static function get(): array {
        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved) || empty($saved)) {
            $saved = self::get_defaults();
            update_option(self::OPTION_KEY, $saved);
        }

        return self::deep_merge(self::get_defaults(), $saved);
    }

    public static function save(array $content): void {
        update_option(self::OPTION_KEY, self::sanitize($content));
    }

    public static function reset_to_defaults(): void {
        update_option(self::OPTION_KEY, self::get_defaults());
    }

    public static function export_json(): string {
        return wp_json_encode(self::get(), JSON_PRETTY_PRINT);
    }

    public static function import_json(string $json): bool {
        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return false;
        }

        self::save($decoded);
        return true;
    }

    public static function sanitize(array $content): array {
        $defaults = self::get_defaults();
        $content = self::deep_merge($defaults, $content);

        $content['recommended_tier'] = sanitize_key((string) ($content['recommended_tier'] ?? 'essential'));
        if (!isset($defaults['tiers'][$content['recommended_tier']])) {
            $content['recommended_tier'] = 'essential';
        }

        foreach ($content['tiers'] as $tier => &$tier_data) {
            $tier_data['name'] = sanitize_text_field((string) ($tier_data['name'] ?? ucfirst($tier)));
            $tier_data['tagline'] = sanitize_text_field((string) ($tier_data['tagline'] ?? ''));
            $tier_data['description'] = wp_kses_post((string) ($tier_data['description'] ?? ''));
            $tier_data['features'] = array_values(array_filter(array_map('sanitize_text_field', (array) ($tier_data['features'] ?? []))));
            $tier_data['benefits'] = array_values(array_filter(array_map('sanitize_text_field', (array) ($tier_data['benefits'] ?? []))));
            foreach (['monthly', 'quarterly', 'yearly'] as $interval) {
                $tier_data['pricing'][$interval] = isset($tier_data['pricing'][$interval]) ? (float) $tier_data['pricing'][$interval] : 0;
                $tier_data['savings'][$interval] = isset($tier_data['savings'][$interval]) ? (float) $tier_data['savings'][$interval] : 0;
            }
        }

        $content['pricing_display']['currency_symbol'] = sanitize_text_field((string) ($content['pricing_display']['currency_symbol'] ?? '$'));
        $content['pricing_display']['default_interval'] = sanitize_key((string) ($content['pricing_display']['default_interval'] ?? 'monthly'));
        $content['pricing_display']['show_savings_badges'] = !empty($content['pricing_display']['show_savings_badges']);

        foreach (['accent_color', 'essential_color', 'premium_color', 'ultimate_color', 'free_color'] as $color_key) {
            $content['styling'][$color_key] = sanitize_hex_color((string) ($content['styling'][$color_key] ?? '#1453ff')) ?: $defaults['styling'][$color_key];
        }
        $content['styling']['font_family'] = sanitize_text_field((string) ($content['styling']['font_family'] ?? $defaults['styling']['font_family']));

        $sanitized_rows = [];
        foreach ((array) $content['comparison_features'] as $row) {
            if (!is_array($row) || empty($row['label'])) {
                continue;
            }
            $line = ['label' => sanitize_text_field((string) $row['label'])];
            foreach (array_keys($defaults['tiers']) as $tier) {
                $value = $row[$tier] ?? false;
                if (is_bool($value)) {
                    $line[$tier] = $value;
                } else {
                    $line[$tier] = sanitize_text_field((string) $value);
                }
            }
            $sanitized_rows[] = $line;
        }
        $content['comparison_features'] = $sanitized_rows;

        return $content;
    }

    private static function deep_merge(array $defaults, array $saved): array {
        foreach ($defaults as $key => $default_value) {
            if (!array_key_exists($key, $saved)) {
                $saved[$key] = $default_value;
                continue;
            }

            if (is_array($default_value) && is_array($saved[$key])) {
                $saved[$key] = self::deep_merge($default_value, $saved[$key]);
            }
        }

        return $saved;
    }
}
