<?php

namespace LifeTrustPlanning\Marketing;

use LifeTrustPlanning\Core\Tier_Access;

class Marketing_Renderer {
    public static function enqueue_assets(): void {
        wp_enqueue_style('ltp-marketing');
        wp_enqueue_script('ltp-marketing');
    }

    public static function get_tier_data(string $tier): array {
        $content = Marketing_Content::get();
        return $content['tiers'][$tier] ?? $content['tiers']['free'];
    }

    public static function render_pricing_table(array $atts = []): string {
        self::enqueue_assets();
        $content = Marketing_Content::get();
        $interval = sanitize_key((string) ($atts['interval'] ?? $content['pricing_display']['default_interval'] ?? 'monthly'));
        if (!in_array($interval, ['monthly', 'quarterly', 'yearly'], true)) {
            $interval = 'monthly';
        }

        $current_tier = Tier_Access::get_user_tier();
        $recommended = $content['recommended_tier'] ?? 'essential';
        $symbol = $content['pricing_display']['currency_symbol'] ?? '$';

        ob_start();
        ?>
        <section class="ltp-marketing ltp-pricing-table-wrap" style="<?php echo esc_attr(self::style_vars()); ?>" data-default-interval="<?php echo esc_attr($interval); ?>">
            <?php self::render_interval_selector($interval); ?>
            <div class="ltp-table-scroll" role="region" aria-label="LifeTrust Pricing Comparison">
                <table class="ltp-pricing-table">
                    <thead>
                        <tr>
                            <th scope="col" class="ltp-feature-col">Features</th>
                            <?php foreach (['free', 'essential', 'premium', 'ultimate'] as $tier): ?>
                                <?php $tier_data = $content['tiers'][$tier]; ?>
                                <th scope="col" class="ltp-tier-col <?php echo esc_attr($tier === $recommended ? 'is-recommended' : ''); ?> <?php echo esc_attr($tier === $current_tier ? 'is-current' : ''); ?>" style="--ltp-tier-color: <?php echo esc_attr($content['styling'][$tier . '_color'] ?? '#64748b'); ?>;">
                                    <span class="ltp-tier-name"><?php echo esc_html($tier_data['name']); ?></span>
                                    <?php if ($tier === $recommended): ?><span class="ltp-badge">Recommended</span><?php endif; ?>
                                    <?php if ($tier === $current_tier): ?><span class="ltp-badge ltp-current">Current</span><?php endif; ?>
                                    <?php $intervals = $tier === 'free' ? ['monthly'] : ['monthly', 'quarterly', 'yearly']; ?>
                                    <?php foreach ($intervals as $price_interval): ?>
                                        <?php echo self::price_html($tier, $price_interval, $symbol); ?>
                                        <?php echo self::render_add_to_cart_button($tier, $price_interval); ?>
                                    <?php endforeach; ?>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ((array) $content['comparison_features'] as $row): ?>
                            <tr>
                                <th scope="row"><?php echo esc_html((string) ($row['label'] ?? '')); ?></th>
                                <?php foreach (['free', 'essential', 'premium', 'ultimate'] as $tier): ?>
                                    <td><?php echo self::feature_value_html($row[$tier] ?? false); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    public static function render_tier_card(string $tier, string $interval = 'monthly'): string {
        self::enqueue_assets();
        $content = Marketing_Content::get();
        $tier = sanitize_key($tier);
        if (!isset($content['tiers'][$tier])) {
            return '';
        }

        $tier_data = $content['tiers'][$tier];
        $recommended = $content['recommended_tier'] ?? 'essential';
        $current_tier = Tier_Access::get_user_tier();
        $symbol = $content['pricing_display']['currency_symbol'] ?? '$';

        ob_start();
        ?>
        <article class="ltp-marketing ltp-tier-card <?php echo esc_attr($tier === $recommended ? 'is-recommended' : ''); ?> <?php echo esc_attr($tier === $current_tier ? 'is-current' : ''); ?>" style="<?php echo esc_attr(self::style_vars()); ?> --ltp-tier-color: <?php echo esc_attr($content['styling'][$tier . '_color'] ?? '#64748b'); ?>;" aria-label="<?php echo esc_attr($tier_data['name']); ?>">
            <header>
                <h3><?php echo esc_html($tier_data['name']); ?></h3>
                <p class="ltp-tagline"><?php echo esc_html($tier_data['tagline']); ?></p>
                <?php if ($tier === $recommended): ?><span class="ltp-badge">Recommended</span><?php endif; ?>
                <?php if ($tier === $current_tier): ?><span class="ltp-badge ltp-current">Your Plan</span><?php endif; ?>
            </header>
            <?php $intervals = $tier === 'free' ? ['monthly'] : ['monthly', 'quarterly', 'yearly']; ?>
            <?php foreach ($intervals as $price_interval): ?>
                <?php echo self::price_html($tier, $price_interval, $symbol); ?>
            <?php endforeach; ?>
            <div class="ltp-description"><?php echo wp_kses_post((string) $tier_data['description']); ?></div>
            <?php echo self::render_feature_list($tier); ?>
            <?php echo self::render_tier_benefits($tier); ?>
            <?php foreach ($intervals as $cta_interval): ?>
                <?php echo self::render_add_to_cart_button($tier, $cta_interval); ?>
            <?php endforeach; ?>
        </article>
        <?php
        return (string) ob_get_clean();
    }

    public static function render_add_to_cart_button(string $tier, string $interval): string {
        $tier = sanitize_key($tier);
        $interval = sanitize_key($interval);

        if ($tier === 'free') {
            return '<span class="ltp-price-free">No payment required</span>';
        }

        $map = get_option('ltp_wc_product_map', []);
        $product_id = isset($map[$tier][$interval]) ? (int) $map[$tier][$interval] : 0;
        if (!$product_id || !function_exists('wc_get_checkout_url')) {
            return '<p class="ltp-muted">Checkout setup pending.</p>';
        }

        $label = sprintf('Choose %s (%s)', ucfirst($tier), ucfirst($interval));
        $link = add_query_arg('add-to-cart', $product_id, wc_get_checkout_url());
        return '<a class="button ltp-cta-button" data-interval="' . esc_attr($interval) . '" href="' . esc_url($link) . '">' . esc_html($label) . '</a>';
    }

    public static function render_feature_list(string $tier): string {
        $tier_data = self::get_tier_data($tier);
        $items = (array) ($tier_data['features'] ?? []);
        $html = '<ul class="ltp-list" aria-label="Plan features">';
        foreach ($items as $item) {
            $html .= '<li>' . esc_html((string) $item) . '</li>';
        }
        $html .= '</ul>';

        return $html;
    }

    public static function render_tier_benefits(string $tier): string {
        $tier_data = self::get_tier_data($tier);
        $items = (array) ($tier_data['benefits'] ?? []);
        $html = '<ul class="ltp-benefits" aria-label="Plan benefits">';
        foreach ($items as $item) {
            $html .= '<li>' . esc_html((string) $item) . '</li>';
        }
        $html .= '</ul>';

        return $html;
    }

    public static function render_price_only(string $tier, string $interval): string {
        $content = Marketing_Content::get();
        $symbol = $content['pricing_display']['currency_symbol'] ?? '$';
        return self::price_html($tier, $interval, $symbol);
    }

    public static function render_member_portal(): string {
        self::enqueue_assets();
        if (!is_user_logged_in()) {
            return '<div class="ltp-member-portal"><p>Please log in to access your member portal.</p></div>';
        }

        global $wpdb;
        $user_id = get_current_user_id();
        $tier = Tier_Access::get_user_tier($user_id);
        $table = $wpdb->prefix . 'ltp_documents';

        $drafts = $wpdb->get_results($wpdb->prepare("SELECT id,title,type,updated_at FROM {$table} WHERE user_id=%d AND status='draft' ORDER BY updated_at DESC LIMIT 5", $user_id), ARRAY_A) ?: [];
        $completed = $wpdb->get_results($wpdb->prepare("SELECT id,title,type,updated_at FROM {$table} WHERE user_id=%d AND status='completed' ORDER BY updated_at DESC LIMIT 5", $user_id), ARRAY_A) ?: [];

        $types = \LifeTrustPlanning\Documents\Document_Types::get_all();
        $available_forms = [];
        foreach ($types as $slug => $config) {
            $tiers = (array) ($config['tiers'] ?? ['free', 'essential', 'premium', 'ultimate']);
            if (in_array($tier, $tiers, true)) {
                $available_forms[$slug] = $config;
            }
        }

        ob_start();
        ?>
        <section class="ltp-marketing ltp-member-portal" style="<?php echo esc_attr(self::style_vars()); ?>">
            <header class="ltp-portal-header">
                <h2>Member Portal</h2>
                <p>Your current tier: <strong><?php echo esc_html(ucfirst($tier)); ?></strong></p>
                <?php echo self::render_tier_benefits($tier); ?>
            </header>

            <div class="ltp-portal-grid">
                <article>
                    <h3>Start a New Form</h3>
                    <ul class="ltp-list">
                        <?php foreach ($available_forms as $slug => $config): ?>
                            <li><a href="<?php echo esc_url(add_query_arg(['type' => $slug], get_permalink())); ?>"><?php echo esc_html((string) ($config['label'] ?? ucfirst($slug))); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </article>

                <article>
                    <h3>Saved Drafts</h3>
                    <?php if (empty($drafts)): ?>
                        <p>No drafts yet.</p>
                    <?php else: ?>
                        <ul class="ltp-list">
                            <?php foreach ($drafts as $doc): ?>
                                <li><?php echo esc_html((string) $doc['title']); ?> (<?php echo esc_html((string) $doc['type']); ?>)</li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </article>

                <article>
                    <h3>Completed Forms</h3>
                    <?php if (empty($completed)): ?>
                        <p>No completed forms yet.</p>
                    <?php else: ?>
                        <ul class="ltp-list">
                            <?php foreach ($completed as $doc): ?>
                                <li><?php echo esc_html((string) $doc['title']); ?> (<?php echo esc_html((string) $doc['type']); ?>)</li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </article>

                <article>
                    <h3>Resources & Support</h3>
                    <ul class="ltp-list">
                        <li><a href="<?php echo esc_url(home_url('/my-account/edit-account/')); ?>">Account Management</a></li>
                        <li><a href="<?php echo esc_url(home_url('/knowledge-base/')); ?>">Knowledge Base</a></li>
                        <li><a href="<?php echo esc_url(home_url('/support/')); ?>">Support</a></li>
                    </ul>
                    <?php if (in_array($tier, ['free', 'essential', 'premium'], true)): ?>
                        <div class="ltp-upgrade-inline"><?php echo wp_kses_post(self::render_upgrade_prompt()); ?></div>
                    <?php endif; ?>
                </article>
            </div>
        </section>
        <?php

        return (string) ob_get_clean();
    }

    public static function render_upgrade_prompt(): string {
        $current = Tier_Access::get_user_tier();
        $next = match ($current) {
            'free' => 'essential',
            'essential' => 'premium',
            'premium' => 'ultimate',
            default => 'ultimate',
        };

        return '<div class="ltp-upgrade-prompt"><strong>Upgrade recommendation:</strong> Move to ' . esc_html(ucfirst($next)) . ' to unlock more advanced planning tools.</div>';
    }

    public static function render_current_tier(): string {
        return '<span class="ltp-current-tier">' . esc_html(ucfirst(Tier_Access::get_user_tier())) . '</span>';
    }

    public static function user_has_tier_access(array $allowed_tiers, int $user_id = 0): bool {
        if (empty($allowed_tiers)) {
            return true;
        }

        $allowed_tiers = array_values(array_filter(array_map('sanitize_key', $allowed_tiers)));
        $user_tier = Tier_Access::get_user_tier($user_id);

        return in_array($user_tier, $allowed_tiers, true);
    }

    private static function style_vars(): string {
        $styling = Marketing_Content::get()['styling'] ?? [];

        $font = sanitize_text_field((string) ($styling['font_family'] ?? "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"));
        $accent = sanitize_hex_color((string) ($styling['accent_color'] ?? '#1453ff')) ?: '#1453ff';

        return '--ltp-font: ' . $font . '; --ltp-accent: ' . $accent . ';';
    }

    private static function render_interval_selector(string $selected): void {
        ?>
        <div class="ltp-interval-switch" role="group" aria-label="Billing Interval Selector">
            <?php foreach (['monthly' => 'Monthly', 'quarterly' => 'Quarterly', 'yearly' => 'Yearly'] as $key => $label): ?>
                <button type="button" class="ltp-interval-btn <?php echo esc_attr($selected === $key ? 'is-active' : ''); ?>" data-interval="<?php echo esc_attr($key); ?>" aria-pressed="<?php echo esc_attr($selected === $key ? 'true' : 'false'); ?>"><?php echo esc_html($label); ?></button>
            <?php endforeach; ?>
        </div>
        <?php
    }

    private static function feature_value_html($value): string {
        if ($value === true) {
            return '<span class="ltp-check" aria-label="Included">✔</span>';
        }

        if ($value === false || $value === '') {
            return '<span class="ltp-x" aria-label="Not included">✖</span>';
        }

        return '<span>' . esc_html((string) $value) . '</span>';
    }

    private static function price_html(string $tier, string $interval, string $symbol): string {
        $content = Marketing_Content::get();
        $tier_data = $content['tiers'][$tier] ?? null;
        if (!$tier_data) {
            return '';
        }

        $interval = sanitize_key($interval);
        $price = (float) ($tier_data['pricing'][$interval] ?? 0);
        $savings = (float) ($tier_data['savings'][$interval] ?? 0);
        $show_savings = !empty($content['pricing_display']['show_savings_badges']);

        $suffix = match ($interval) {
            'quarterly' => '/quarter',
            'yearly' => '/year',
            default => '/month',
        };

        $out = '<p class="ltp-price" data-interval="' . esc_attr($interval) . '"><strong>' . esc_html($symbol . number_format($price, 2)) . '</strong>' . esc_html($suffix) . '</p>';
        if ($show_savings && $savings > 0) {
            $out .= '<p class="ltp-savings" data-interval="' . esc_attr($interval) . '">Save ' . esc_html((string) $savings) . '%</p>';
        }

        return $out;
    }
}
