<?php

namespace LifeTrustPlanning;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Shortcodes {
    public static function register(): void {
        add_shortcode('ltp_form', [self::class, 'render_form']);
        add_shortcode('ltp_pricing_table', [self::class, 'render_pricing_table']);
        add_shortcode('ltp_tier_card', [self::class, 'render_tier_card']);
        add_shortcode('ltp_add_to_cart', [self::class, 'render_add_to_cart']);
        add_shortcode('ltp_feature_list', [self::class, 'render_feature_list']);
        add_shortcode('ltp_current_tier', [self::class, 'render_current_tier']);
        add_shortcode('ltp_upgrade_prompt', [self::class, 'render_upgrade_prompt']);
        add_shortcode('ltp_tier_benefits', [self::class, 'render_tier_benefits']);
        add_shortcode('ltp_pricing', [self::class, 'render_pricing_only']);
        add_shortcode('ltp_member_portal', [self::class, 'render_member_portal']);
        add_shortcode('ltp_tier_content', [self::class, 'render_tier_content']);
    }

    public static function render_form(array $atts): string {
        $atts = shortcode_atts([
            'type' => 'henson_trust',
            'document_id' => 0,
        ], $atts);

        if (!is_user_logged_in()) {
            return '<div class="ltp-login-required">Please log in to use this form.</div>';
        }

        wp_enqueue_script('ltp-forms');
        wp_enqueue_style('ltp-forms');

        $form_type = sanitize_key($atts['type']);
        $user_id = get_current_user_id();
        $nav_mode = get_user_meta($user_id, "_ltp_form_nav_mode_{$form_type}", true) ?: get_option('ltp_form_default_navigation_mode', 'tab');

        wp_localize_script('ltp-forms', 'ltpFormRuntime', [
            'type' => $form_type,
            'documentId' => absint($atts['document_id']),
            'navigationMode' => $nav_mode,
            'limits' => Tier_Access::get_limits_info($user_id),
        ]);

        return '<div id="ltp-form-root" data-type="' . esc_attr($form_type) . '"></div>';
    }

    public static function render_pricing_table(array $atts): string {
        return Marketing_Renderer::render_pricing_table($atts);
    }

    public static function render_tier_card(array $atts): string {
        $atts = shortcode_atts(['tier' => 'essential', 'interval' => 'monthly'], $atts);
        return Marketing_Renderer::render_tier_card((string) $atts['tier'], (string) $atts['interval']);
    }

    public static function render_add_to_cart(array $atts): string {
        $atts = shortcode_atts(['tier' => 'essential', 'interval' => 'monthly'], $atts);
        return Marketing_Renderer::render_add_to_cart_button((string) $atts['tier'], (string) $atts['interval']);
    }

    public static function render_feature_list(array $atts): string {
        $atts = shortcode_atts(['tier' => 'essential'], $atts);
        return Marketing_Renderer::render_feature_list((string) $atts['tier']);
    }

    public static function render_current_tier(): string {
        return Marketing_Renderer::render_current_tier();
    }

    public static function render_upgrade_prompt(): string {
        return Marketing_Renderer::render_upgrade_prompt();
    }

    public static function render_tier_benefits(array $atts): string {
        $atts = shortcode_atts(['tier' => 'premium'], $atts);
        return Marketing_Renderer::render_tier_benefits((string) $atts['tier']);
    }

    public static function render_pricing_only(array $atts): string {
        $atts = shortcode_atts(['tier' => 'essential', 'interval' => 'yearly'], $atts);
        return Marketing_Renderer::render_price_only((string) $atts['tier'], (string) $atts['interval']);
    }

    public static function render_member_portal(): string {
        return Marketing_Renderer::render_member_portal();
    }

    public static function render_tier_content(array $atts, ?string $content = null): string {
        $atts = shortcode_atts(['tier' => 'essential'], $atts);
        $allowed_tiers = array_values(array_filter(array_map('sanitize_key', array_map('trim', explode(',', (string) $atts['tier'])))));

        if (Marketing_Renderer::user_has_tier_access($allowed_tiers)) {
            return do_shortcode((string) $content);
        }

        return Marketing_Renderer::render_upgrade_prompt();
    }
}
