<?php

namespace LifeTrustPlanning\Content;

class Content_Taxonomies {
    public static function register(): void {
        register_taxonomy('ltp_province', ['ltp_knowledge_base', 'ltp_gov_program'], [
            'label' => __('Province', 'lifetrust-planning'),
            'hierarchical' => true,
            'show_ui' => true,
            'show_in_rest' => true,
        ]);

        register_taxonomy('ltp_topic', ['ltp_knowledge_base'], [
            'label' => __('Topic', 'lifetrust-planning'),
            'hierarchical' => true,
            'show_ui' => true,
            'show_in_rest' => true,
        ]);

        register_taxonomy('ltp_program_type', ['ltp_gov_program'], [
            'label' => __('Program Type', 'lifetrust-planning'),
            'hierarchical' => true,
            'show_ui' => true,
            'show_in_rest' => true,
        ]);

        self::seed_terms();
    }

    private static function seed_terms(): void {
        $provinces = ['ON','BC','AB','SK','MB','QC','NB','NS','PE','NL','NT','YT','NU','ALL'];
        foreach ($provinces as $p) {
            if (!term_exists(strtolower($p), 'ltp_province')) {
                wp_insert_term($p, 'ltp_province', ['slug' => strtolower($p)]);
            }
        }

        $topics = ['Henson Trust', 'Estate Planning', 'Government Benefits', 'Tax Credits', 'RDSP', 'Planning Framework'];
        foreach ($topics as $topic) {
            if (!term_exists($topic, 'ltp_topic')) {
                wp_insert_term($topic, 'ltp_topic');
            }
        }

        $types = ['Disability Support', 'Tax Credit', 'Savings Plan', 'Housing', 'Employment', 'Income Assistance'];
        foreach ($types as $type) {
            if (!term_exists($type, 'ltp_program_type')) {
                wp_insert_term($type, 'ltp_program_type');
            }
        }
    }
}
