<?php

namespace LifeTrustPlanning\Content;

class Content_Importer {
    public static function maybe_seed_after_activation(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (!(int) get_option('ltp_activation_seed_pending', 0)) {
            return;
        }

        if (self::has_content()) {
            update_option('ltp_activation_seed_pending', 0);
            return;
        }

        self::seed_dummy_content();
        update_option('ltp_activation_seed_pending', 0);
    }

    public static function has_content(): bool {
        $kb = wp_count_posts('ltp_knowledge_base');
        $gp = wp_count_posts('ltp_gov_program');
        return (($kb->publish ?? 0) + ($kb->draft ?? 0) + ($gp->publish ?? 0) + ($gp->draft ?? 0)) > 0;
    }

    public static function import_file(string $path): array {
        if (!file_exists($path)) {
            return ['success' => false, 'message' => 'File not found'];
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        return match ($ext) {
            'json' => self::import_json($path),
            'csv' => self::import_csv($path),
            'xml' => self::import_xml($path),
            default => ['success' => false, 'message' => 'Unsupported format'],
        };
    }

    public static function seed_dummy_content(): void {
        $items = [
            ['title' => 'Henson Trust Basics', 'content' => 'Placeholder knowledge article for Henson Trust planning.'],
            ['title' => 'Disability Benefits Checklist', 'content' => 'Placeholder knowledge article for benefit coordination.'],
            ['title' => 'Four Essentials Overview', 'content' => 'Placeholder article for the Four Essentials methodology.'],
        ];

        foreach ($items as $item) {
            wp_insert_post([
                'post_type' => 'ltp_knowledge_base',
                'post_status' => 'publish',
                'post_title' => $item['title'],
                'post_content' => $item['content'],
            ]);
        }

        wp_insert_post([
            'post_type' => 'ltp_gov_program',
            'post_status' => 'publish',
            'post_title' => 'Ontario Disability Support Program (Placeholder)',
            'post_content' => 'Placeholder government program entry for ODSP.',
        ]);

        update_option('ltp_content_import_completed', 1);
    }

    private static function import_json(string $path): array {
        $data = json_decode((string) file_get_contents($path), true);
        if (!is_array($data)) {
            return ['success' => false, 'message' => 'Invalid JSON'];
        }

        $count = 0;
        foreach ($data as $item) {
            if (empty($item['title'])) {
                continue;
            }
            wp_insert_post([
                'post_type' => $item['post_type'] ?? 'ltp_knowledge_base',
                'post_status' => 'publish',
                'post_title' => sanitize_text_field($item['title']),
                'post_content' => wp_kses_post($item['content'] ?? ''),
            ]);
            $count++;
        }

        return ['success' => true, 'imported' => $count, 'message' => "Imported {$count} JSON records"];
    }

    private static function import_csv(string $path): array {
        $fh = fopen($path, 'rb');
        if (!$fh) {
            return ['success' => false, 'message' => 'Cannot open CSV file'];
        }

        $header = fgetcsv($fh);
        $count = 0;
        while (($row = fgetcsv($fh)) !== false) {
            $record = array_combine($header ?: [], $row);
            if (!$record || empty($record['title'])) {
                continue;
            }

            wp_insert_post([
                'post_type' => $record['post_type'] ?? 'ltp_knowledge_base',
                'post_status' => 'publish',
                'post_title' => sanitize_text_field($record['title']),
                'post_content' => wp_kses_post($record['content'] ?? ''),
            ]);
            $count++;
        }

        fclose($fh);
        return ['success' => true, 'imported' => $count, 'message' => "Imported {$count} CSV records"];
    }

    private static function import_xml(string $path): array {
        $xml = simplexml_load_file($path);
        if (!$xml) {
            return ['success' => false, 'message' => 'Invalid XML'];
        }

        $count = 0;
        foreach ($xml->item as $item) {
            $title = (string) ($item->title ?? '');
            if (!$title) {
                continue;
            }
            wp_insert_post([
                'post_type' => (string) ($item->post_type ?? 'ltp_knowledge_base'),
                'post_status' => 'publish',
                'post_title' => sanitize_text_field($title),
                'post_content' => wp_kses_post((string) ($item->content ?? '')),
            ]);
            $count++;
        }

        return ['success' => true, 'imported' => $count, 'message' => "Imported {$count} XML records"];
    }
}
