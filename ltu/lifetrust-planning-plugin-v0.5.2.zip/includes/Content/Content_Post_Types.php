<?php

namespace LifeTrustPlanning\Content;

class Content_Post_Types {
    public static function register(): void {
        register_post_type('ltp_knowledge_base', [
            'labels' => [
                'name' => __('Knowledge Base', 'lifetrust-planning'),
                'singular_name' => __('Knowledge Article', 'lifetrust-planning'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'lifetrust-planning',
            'show_in_rest' => true,
            'rest_base' => 'ltp-knowledge',
            'supports' => ['title', 'editor', 'excerpt', 'revisions', 'custom-fields', 'author'],
            'has_archive' => false,
            'menu_icon' => 'dashicons-book-alt',
        ]);

        register_post_type('ltp_gov_program', [
            'labels' => [
                'name' => __('Government Programs', 'lifetrust-planning'),
                'singular_name' => __('Government Program', 'lifetrust-planning'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'lifetrust-planning',
            'show_in_rest' => true,
            'rest_base' => 'ltp-programs',
            'supports' => ['title', 'editor', 'excerpt', 'revisions', 'custom-fields'],
            'has_archive' => false,
            'menu_icon' => 'dashicons-admin-site-alt3',
        ]);
    }
}
