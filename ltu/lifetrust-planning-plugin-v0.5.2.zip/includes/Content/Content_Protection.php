<?php

namespace LifeTrustPlanning\Content;

use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Content_Protection {
    public static function init(): void {
        add_action('add_meta_boxes', [self::class, 'add_meta_box']);
        add_action('save_post', [self::class, 'save_meta_box']);
        add_action('template_redirect', [self::class, 'handle_redirect']);
        add_filter('the_content', [self::class, 'filter_content_for_access'], 20);
    }

    public static function add_meta_box(): void {
        foreach (['page', 'post'] as $type) {
            add_meta_box(
                'ltp-tier-access-control',
                __('Tier Access Control', 'lifetrust-planning'),
                [self::class, 'render_meta_box'],
                $type,
                'side'
            );
        }
    }

    public static function render_meta_box(\WP_Post $post): void {
        wp_nonce_field('ltp_tier_access_control', 'ltp_tier_access_nonce');

        $allowed = (array) get_post_meta($post->ID, '_ltp_allowed_tiers', true);
        $redirect_url = (string) get_post_meta($post->ID, '_ltp_access_redirect_url', true);
        $teaser = (string) get_post_meta($post->ID, '_ltp_teaser_content', true);
        $show_upgrade = (int) get_post_meta($post->ID, '_ltp_show_upgrade_prompt', true);
        ?>
        <p><strong><?php esc_html_e('Allowed tiers', 'lifetrust-planning'); ?></strong></p>
        <?php foreach (['free', 'essential', 'premium', 'ultimate'] as $tier): ?>
            <label style="display:block; margin-bottom:4px;">
                <input type="checkbox" name="ltp_allowed_tiers[]" value="<?php echo esc_attr($tier); ?>" <?php checked(in_array($tier, $allowed, true)); ?>>
                <?php echo esc_html(ucfirst($tier)); ?>
            </label>
        <?php endforeach; ?>

        <p style="margin-top:12px;"><label><?php esc_html_e('Redirect unauthorized users to URL', 'lifetrust-planning'); ?><br>
            <input type="url" name="ltp_access_redirect_url" class="widefat" value="<?php echo esc_attr($redirect_url); ?>" placeholder="https://example.com/upgrade">
        </label></p>

        <p><label><?php esc_html_e('Teaser content for unauthorized users', 'lifetrust-planning'); ?><br>
            <textarea name="ltp_teaser_content" rows="4" class="widefat"><?php echo esc_textarea($teaser); ?></textarea>
        </label></p>

        <p><label>
            <input type="checkbox" name="ltp_show_upgrade_prompt" value="1" <?php checked($show_upgrade, 1); ?>>
            <?php esc_html_e('Show upgrade prompt', 'lifetrust-planning'); ?>
        </label></p>
        <?php
    }

    public static function save_meta_box(int $post_id): void {
        if (!isset($_POST['ltp_tier_access_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ltp_tier_access_nonce'])), 'ltp_tier_access_control')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $allowed = array_values(array_unique(array_map('sanitize_key', (array) ($_POST['ltp_allowed_tiers'] ?? []))));
        update_post_meta($post_id, '_ltp_allowed_tiers', $allowed);

        $redirect_url = esc_url_raw((string) ($_POST['ltp_access_redirect_url'] ?? ''));
        update_post_meta($post_id, '_ltp_access_redirect_url', $redirect_url);

        $teaser = sanitize_textarea_field((string) ($_POST['ltp_teaser_content'] ?? ''));
        update_post_meta($post_id, '_ltp_teaser_content', $teaser);

        update_post_meta($post_id, '_ltp_show_upgrade_prompt', !empty($_POST['ltp_show_upgrade_prompt']) ? 1 : 0);
    }

    public static function handle_redirect(): void {
        if (!is_singular() || is_admin()) {
            return;
        }

        $post_id = get_queried_object_id();
        if (!$post_id || self::has_access($post_id)) {
            return;
        }

        $redirect = (string) get_post_meta($post_id, '_ltp_access_redirect_url', true);
        if (!empty($redirect)) {
            wp_safe_redirect($redirect);
            exit;
        }
    }

    public static function filter_content_for_access(string $content): string {
        if (!is_singular() || is_admin() || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        $post_id = get_the_ID();
        if (!$post_id || self::has_access($post_id)) {
            return $content;
        }

        $teaser = (string) get_post_meta($post_id, '_ltp_teaser_content', true);
        $show_upgrade = (int) get_post_meta($post_id, '_ltp_show_upgrade_prompt', true);

        $locked = '<div class="ltp-content-locked">';
        if (!empty($teaser)) {
            $locked .= wpautop(esc_html($teaser));
        } else {
            $locked .= '<p>This content is available to members on higher tiers.</p>';
        }

        if ($show_upgrade) {
            $locked .= Marketing_Renderer::render_upgrade_prompt();
        }

        $locked .= '</div>';
        return $locked;
    }

    public static function has_access(int $post_id, int $user_id = 0): bool {
        $allowed = (array) get_post_meta($post_id, '_ltp_allowed_tiers', true);
        if (empty($allowed)) {
            return true;
        }

        return Marketing_Renderer::user_has_tier_access($allowed, $user_id);
    }
}
