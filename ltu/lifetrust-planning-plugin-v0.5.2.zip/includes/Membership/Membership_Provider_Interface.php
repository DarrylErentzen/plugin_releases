<?php

namespace LifeTrustPlanning\Membership;

interface Membership_Provider_Interface {
    public function get_key(): string;

    public function get_label(): string;

    public function is_available(): bool;

    public function init(): void;

    public function assign_tier(int $user_id, string $tier, array $context = []): bool;

    public function downgrade_to_free(int $user_id, array $context = []): bool;

    public function get_user_tier(int $user_id): string;
}
