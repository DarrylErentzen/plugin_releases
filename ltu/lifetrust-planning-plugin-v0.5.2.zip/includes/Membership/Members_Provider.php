<?php

namespace LifeTrustPlanning\Membership;

use LifeTrustPlanning\Core\Roles;
use LifeTrustPlanning\Core\Tier_Config;

class Members_Provider implements Membership_Provider_Interface {
    public function get_key(): string {
        return 'members_legacy';
    }

    public function get_label(): string {
        return 'Members Plugin (roles/capabilities)';
    }

    public function is_available(): bool {
        return function_exists('members_register_cap') || class_exists('Members_Plugin');
    }

    public function init(): void {
        add_action('init', [Roles::class, 'register_roles_and_caps'], 20);
        add_action('set_user_role', [$this, 'sync_meta_from_role'], 20, 2);
    }

    public function assign_tier(int $user_id, string $tier, array $context = []): bool {
        $tier = sanitize_key($tier ?: 'free');
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return false;
        }

        $role_map = Tier_Config::get_role_map();
        $target_role = $role_map[$tier] ?? $role_map['free'];

        foreach ($role_map as $role) {
            $user->remove_role($role);
        }
        $user->add_role($target_role);

        update_user_meta($user_id, '_ltp_active_tier', $tier);
        update_user_meta($user_id, '_ltp_active_tier_updated_at', current_time('mysql'));

        do_action('ltp_membership_assigned_tier', $user_id, $tier, $context, $this->get_key());

        return true;
    }

    public function downgrade_to_free(int $user_id, array $context = []): bool {
        return $this->assign_tier($user_id, 'free', $context);
    }

    public function get_user_tier(int $user_id): string {
        $meta_tier = sanitize_key((string) get_user_meta($user_id, '_ltp_active_tier', true));
        if ($meta_tier) {
            return $meta_tier;
        }

        $user = get_user_by('id', $user_id);
        if (!$user) {
            return 'free';
        }

        $role_map = Tier_Config::get_role_map();
        foreach ($role_map as $tier => $role) {
            if (in_array($role, (array) $user->roles, true)) {
                update_user_meta($user_id, '_ltp_active_tier', $tier);
                return $tier;
            }
        }

        return 'free';
    }

    public function sync_meta_from_role(int $user_id, string $role): void {
        $role_map = Tier_Config::get_role_map();
        foreach ($role_map as $tier => $role_slug) {
            if ($role_slug === $role) {
                update_user_meta($user_id, '_ltp_active_tier', $tier);
                return;
            }
        }
    }
}
