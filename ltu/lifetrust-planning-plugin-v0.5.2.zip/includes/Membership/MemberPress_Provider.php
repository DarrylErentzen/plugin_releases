<?php

namespace LifeTrustPlanning\Membership;

class MemberPress_Provider implements Membership_Provider_Interface {
    /** @var array<int, string> */
    private const PRIORITY = [
        'graduate',
        'ultimate',
        'premium',
        'essential',
        'free',
    ];

    public function get_key(): string {
        return 'memberpress';
    }

    public function get_label(): string {
        return 'MemberPress Growth';
    }

    public function is_available(): bool {
        return class_exists('MeprProduct') || defined('MEPR_PLUGIN_SLUG') || post_type_exists('memberpressproduct');
    }

    public function init(): void {
        // Runtime reads membership status directly; no extra hook required.
    }

    public function assign_tier(int $user_id, string $tier, array $context = []): bool {
        $tier = sanitize_key($tier ?: 'free');
        $map = self::get_tier_membership_map();
        $membership_id = (int) ($map[$tier] ?? 0);

        update_user_meta($user_id, '_ltp_active_tier', $tier);
        update_user_meta($user_id, '_ltp_memberpress_membership_id', $membership_id);
        update_user_meta($user_id, '_ltp_active_tier_updated_at', current_time('mysql'));

        do_action('ltp_memberpress_assign_tier', $user_id, $tier, $membership_id, $context);
        return true;
    }

    public function downgrade_to_free(int $user_id, array $context = []): bool {
        return $this->assign_tier($user_id, 'free', $context);
    }

    public function get_user_tier(int $user_id): string {
        $active_ids = self::get_active_membership_ids($user_id);
        $map = self::get_tier_membership_map();

        foreach (self::PRIORITY as $tier) {
            $membership_id = (int) ($map[$tier] ?? 0);
            if ($membership_id > 0 && in_array($membership_id, $active_ids, true)) {
                update_user_meta($user_id, '_ltp_active_tier', $tier);
                return $tier;
            }
        }

        $meta_tier = sanitize_key((string) get_user_meta($user_id, '_ltp_active_tier', true));
        return $meta_tier ?: 'free';
    }

    /** @return array<string, int> */
    public static function get_tier_membership_map(): array {
        $saved = get_option('ltp_memberpress_tier_membership_map', []);
        $defaults = ['free' => 0, 'essential' => 0, 'premium' => 0, 'ultimate' => 0, 'graduate' => 0];
        if (!is_array($saved)) {
            return $defaults;
        }

        foreach ($defaults as $tier => $default_id) {
            $saved[$tier] = isset($saved[$tier]) ? absint((int) $saved[$tier]) : $default_id;
        }

        return $saved;
    }

    /** @return array<int, array<string, mixed>> */
    public static function membership_options(): array {
        $options = [];
        $products = get_posts([
            'post_type' => 'memberpressproduct',
            'posts_per_page' => -1,
            'post_status' => ['publish', 'draft', 'private'],
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        foreach ($products as $product) {
            $options[] = [
                'id' => (int) $product->ID,
                'name' => (string) $product->post_title,
                'status' => (string) $product->post_status,
            ];
        }

        return $options;
    }

    /** @return array<int, int> */
    public static function get_active_membership_ids(int $user_id): array {
        $ids = [];

        if (class_exists('MeprUser')) {
            try {
                $mepr_user = new \MeprUser($user_id);
                if (method_exists($mepr_user, 'active_product_subscriptions')) {
                    $from_method = $mepr_user->active_product_subscriptions('ids');
                    if (is_array($from_method)) {
                        foreach ($from_method as $id) {
                            $ids[] = absint((int) $id);
                        }
                    }
                }
            } catch (\Throwable $e) {
                // Fall through to DB lookup.
            }
        }

        if (!empty($ids)) {
            return array_values(array_unique(array_filter($ids)));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'mepr_transactions';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if (!$exists) {
            return [];
        }

        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT product_id FROM {$table}
            WHERE user_id=%d
              AND status IN ('complete','confirmed')
              AND (expires_at IS NULL OR expires_at='0000-00-00 00:00:00' OR expires_at > %s)",
            $user_id,
            current_time('mysql')
        ));

        foreach ((array) $rows as $row) {
            $ids[] = absint((int) $row);
        }

        return array_values(array_unique(array_filter($ids)));
    }
}
