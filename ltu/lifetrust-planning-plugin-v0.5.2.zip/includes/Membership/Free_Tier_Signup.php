<?php

namespace LifeTrustPlanning\Membership;

class Free_Tier_Signup {
    public static function init(): void {
        add_shortcode('ltp_free_tier_signup', [self::class, 'render_shortcode']);
        add_action('admin_post_ltp_free_tier_signup', [self::class, 'handle_signup']);
        add_action('admin_post_nopriv_ltp_free_tier_signup', [self::class, 'handle_signup']);
    }

    public static function render_shortcode(): string {
        if (!is_user_logged_in()) {
            return '<p>Please log in to sign up for the free tier.</p>';
        }

        $action = esc_url(admin_url('admin-post.php'));
        $nonce = wp_create_nonce('ltp_free_tier_signup');

        return '<form method="post" action="' . $action . '">
            <input type="hidden" name="action" value="ltp_free_tier_signup" />
            <input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '" />
            <button type="submit" class="button button-primary">Activate Free Tier</button>
        </form>';
    }

    public static function handle_signup(): void {
        if (!is_user_logged_in()) {
            wp_safe_redirect(wp_login_url());
            exit;
        }

        check_admin_referer('ltp_free_tier_signup');

        $user_id = get_current_user_id();
        do_action('ltp_membership_assign_tier', $user_id, 'free', ['source' => 'free_tier_signup']);

        $user = wp_get_current_user();
        if ($user && !empty($user->user_email)) {
            wp_mail($user->user_email, 'Welcome to LifeTrust Free Tier', 'Your LifeTrust free tier is now active.');
        }

        wp_safe_redirect(wp_get_referer() ?: home_url('/my-account/'));
        exit;
    }
}
