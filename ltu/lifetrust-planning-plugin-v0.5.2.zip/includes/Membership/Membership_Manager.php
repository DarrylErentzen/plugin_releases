<?php

namespace LifeTrustPlanning\Membership;

class Membership_Manager {
    /** @var array<string, Membership_Provider_Interface> */
    private array $providers = [];

    private Membership_Provider_Interface $active_provider;

    public function __construct() {
        $this->providers = [
            'memberpress' => new MemberPress_Provider(),
            'members_legacy' => new Members_Provider(),
        ];

        $selected = sanitize_key((string) get_option('ltp_membership_provider', 'memberpress'));
        $provider = $this->providers[$selected] ?? $this->providers['memberpress'];

        if (!$provider->is_available()) {
            $provider = $this->providers['memberpress'];
            if (!$provider->is_available()) {
                $provider = $this->providers['members_legacy'];
            }
        }

        $this->active_provider = $provider;
    }

    public function init(): void {
        $this->active_provider->init();
        add_action('ltp_membership_assign_tier', [$this, 'assign_tier'], 10, 3);
        add_action('ltp_membership_downgrade_to_free', [$this, 'downgrade_to_free'], 10, 2);
        add_filter('ltp_user_tier', [$this, 'filter_user_tier'], 10, 2);
    }

    public function assign_tier(int $user_id, string $tier, array $context = []): bool {
        return $this->active_provider->assign_tier($user_id, $tier, $context);
    }

    public function downgrade_to_free(int $user_id, array $context = []): bool {
        return $this->active_provider->downgrade_to_free($user_id, $context);
    }

    public function get_user_tier(int $user_id): string {
        return $this->active_provider->get_user_tier($user_id);
    }

    public function filter_user_tier(string $tier, int $user_id): string {
        if ($user_id <= 0) {
            return $tier;
        }

        $provider_tier = sanitize_key($this->active_provider->get_user_tier($user_id));
        return $provider_tier ?: $tier;
    }

    public function get_active_provider_key(): string {
        return $this->active_provider->get_key();
    }

    /** @return array<string, string> */
    public function list_available_providers(): array {
        $out = [];
        foreach ($this->providers as $key => $provider) {
            if ($provider->is_available() || 'members_legacy' === $key) {
                $out[$key] = $provider->get_label();
            }
        }
        return $out;
    }
}
