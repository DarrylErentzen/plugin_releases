<?php

namespace LifeTrustPlanning\Elementor;

class Integration {
    public static function init(): void {
        add_action('init', [self::class, 'register_templates']);

        if (!did_action('elementor/loaded')) {
            return;
        }

        add_action('elementor/widgets/register', [self::class, 'register_widgets']);
        add_action('elementor/elements/categories_registered', [self::class, 'register_category']);
    }

    public static function register_category($elements_manager): void {
        $elements_manager->add_category('lifetrust-planning', [
            'title' => __('LifeTrust Planning', 'lifetrust-planning'),
            'icon' => 'fa fa-shield',
        ]);
    }

    public static function register_widgets($widgets_manager): void {
        require_once LTP_PLUGIN_DIR . 'includes/Elementor/Widgets/Pricing_Table_Widget.php';
        require_once LTP_PLUGIN_DIR . 'includes/Elementor/Widgets/Tier_Card_Widget.php';
        require_once LTP_PLUGIN_DIR . 'includes/Elementor/Widgets/Add_To_Cart_Widget.php';
        require_once LTP_PLUGIN_DIR . 'includes/Elementor/Widgets/Feature_Comparison_Widget.php';
        require_once LTP_PLUGIN_DIR . 'includes/Elementor/Widgets/Member_Portal_Widget.php';

        $widgets_manager->register(new Widgets\Pricing_Table_Widget());
        $widgets_manager->register(new Widgets\Tier_Card_Widget());
        $widgets_manager->register(new Widgets\Add_To_Cart_Widget());
        $widgets_manager->register(new Widgets\Feature_Comparison_Widget());
        $widgets_manager->register(new Widgets\Member_Portal_Widget());
    }

    public static function register_templates(): void {
        if (!post_type_exists('elementor_library') || !current_user_can('manage_options')) {
            return;
        }

        $templates = [
            'LifeTrust Pricing Page Template' => "[ltp_pricing_table]\n\n[ltp_upgrade_prompt]",
            'LifeTrust Member Portal Template' => "[ltp_member_portal]",
            'LifeTrust Tier Comparison Template' => "[ltp_pricing_table interval=\"yearly\"]\n\n[ltp_tier_card tier=\"essential\"]\n\n[ltp_tier_card tier=\"premium\"]",
        ];

        foreach ($templates as $title => $content) {
            $existing = get_page_by_title($title, OBJECT, 'elementor_library');
            if ($existing) {
                continue;
            }

            wp_insert_post([
                'post_type' => 'elementor_library',
                'post_status' => 'publish',
                'post_title' => $title,
                'post_content' => $content,
            ]);
        }
    }
}
