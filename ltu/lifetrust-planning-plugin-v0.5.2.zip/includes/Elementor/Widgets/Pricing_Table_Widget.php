<?php

namespace LifeTrustPlanning\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Pricing_Table_Widget extends Widget_Base {
    public function get_name() {
        return 'ltp_pricing_table';
    }

    public function get_title() {
        return __('LifeTrust Pricing Table', 'lifetrust-planning');
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories() {
        return ['lifetrust-planning'];
    }

    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Content', 'lifetrust-planning')]);
        $this->add_control('interval', [
            'label' => __('Default Interval', 'lifetrust-planning'),
            'type' => Controls_Manager::SELECT,
            'default' => 'monthly',
            'options' => ['monthly' => 'Monthly', 'quarterly' => 'Quarterly', 'yearly' => 'Yearly'],
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo Marketing_Renderer::render_pricing_table(['interval' => $settings['interval'] ?? 'monthly']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
