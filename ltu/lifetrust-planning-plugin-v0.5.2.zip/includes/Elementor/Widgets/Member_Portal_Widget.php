<?php

namespace LifeTrustPlanning\Elementor\Widgets;

use Elementor\Widget_Base;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Member_Portal_Widget extends Widget_Base {
    public function get_name() { return 'ltp_member_portal'; }
    public function get_title() { return __('LifeTrust Member Portal', 'lifetrust-planning'); }
    public function get_icon() { return 'eicon-my-account'; }
    public function get_categories() { return ['lifetrust-planning']; }

    protected function render() {
        echo Marketing_Renderer::render_member_portal(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
