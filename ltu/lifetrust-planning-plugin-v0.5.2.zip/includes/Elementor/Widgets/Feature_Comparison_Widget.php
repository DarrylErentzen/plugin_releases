<?php

namespace LifeTrustPlanning\Elementor\Widgets;

use Elementor\Widget_Base;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Feature_Comparison_Widget extends Widget_Base {
    public function get_name() { return 'ltp_feature_comparison'; }
    public function get_title() { return __('LifeTrust Feature Comparison', 'lifetrust-planning'); }
    public function get_icon() { return 'eicon-table'; }
    public function get_categories() { return ['lifetrust-planning']; }

    protected function render() {
        echo Marketing_Renderer::render_pricing_table(['interval' => 'monthly']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
