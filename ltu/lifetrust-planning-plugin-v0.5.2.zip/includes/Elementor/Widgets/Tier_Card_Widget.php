<?php

namespace LifeTrustPlanning\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Tier_Card_Widget extends Widget_Base {
    public function get_name() { return 'ltp_tier_card'; }
    public function get_title() { return __('LifeTrust Tier Card', 'lifetrust-planning'); }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_categories() { return ['lifetrust-planning']; }

    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Content', 'lifetrust-planning')]);
        $this->add_control('tier', [
            'label' => __('Tier', 'lifetrust-planning'),
            'type' => Controls_Manager::SELECT,
            'default' => 'essential',
            'options' => ['free' => 'Free', 'essential' => 'Essential', 'premium' => 'Premium', 'ultimate' => 'Ultimate'],
        ]);
        $this->add_control('interval', [
            'label' => __('Interval', 'lifetrust-planning'),
            'type' => Controls_Manager::SELECT,
            'default' => 'monthly',
            'options' => ['monthly' => 'Monthly', 'quarterly' => 'Quarterly', 'yearly' => 'Yearly'],
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        echo Marketing_Renderer::render_tier_card((string) ($s['tier'] ?? 'essential'), (string) ($s['interval'] ?? 'monthly')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
