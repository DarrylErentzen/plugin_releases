<?php

namespace LifeTrustPlanning\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Add_To_Cart_Widget extends Widget_Base {
    public function get_name() { return 'ltp_add_to_cart'; }
    public function get_title() { return __('LifeTrust Add To Cart', 'lifetrust-planning'); }
    public function get_icon() { return 'eicon-cart-medium'; }
    public function get_categories() { return ['lifetrust-planning']; }

    protected function register_controls() {
        $this->start_controls_section('content_section', ['label' => __('Content', 'lifetrust-planning')]);
        $this->add_control('tier', [
            'label' => __('Tier', 'lifetrust-planning'),
            'type' => Controls_Manager::SELECT,
            'default' => 'essential',
            'options' => ['essential' => 'Essential', 'premium' => 'Premium', 'ultimate' => 'Ultimate'],
        ]);
        $this->add_control('interval', [
            'label' => __('Interval', 'lifetrust-planning'),
            'type' => Controls_Manager::SELECT,
            'default' => 'monthly',
            'options' => ['monthly' => 'Monthly', 'quarterly' => 'Quarterly', 'yearly' => 'Yearly'],
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        echo Marketing_Renderer::render_add_to_cart_button((string) ($s['tier'] ?? 'essential'), (string) ($s['interval'] ?? 'monthly')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
