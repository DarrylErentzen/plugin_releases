<?php

namespace LifeTrustPlanning\Core;

class Roles {
    public static function register_roles_and_caps(): void {
        $caps = self::all_caps();
        $tier_map = Tier_Config::get_tier_cap_map();
        $role_map = Tier_Config::get_role_map();

        foreach ($role_map as $tier => $role) {
            $role_caps = ['read' => true];
            foreach (($tier_map[$tier] ?? []) as $cap) {
                $role_caps[$cap] = true;
            }
            add_role($role, 'LTP ' . ucfirst($tier), $role_caps);
        }

        add_role('ltp_firm_admin', 'Firm Administrator', array_merge(['read' => true], $caps));
        add_role('ltp_firm_manager', 'Firm Manager', array_merge(['read' => true], $caps));
        add_role('ltp_firm_employee', 'Firm Employee', [
            'read' => true,
            'ltp_create_document' => true,
            'ltp_edit_own_documents' => true,
            'ltp_use_ai_field_advisor' => true,
        ]);

        $administrator = get_role('administrator');
        if ($administrator) {
            foreach ($caps as $cap => $grant) {
                $administrator->add_cap($cap, $grant);
            }
        }

        // Optional compatibility if Members plugin is still installed.
        if (function_exists('members_register_cap')) {
            foreach (array_keys($caps) as $cap) {
                members_register_cap($cap);
            }
        }
    }

    public static function all_caps(): array {
        $caps = [
            'ltp_create_document' => true,
            'ltp_edit_own_documents' => true,
            'ltp_delete_own_documents' => true,
            'ltp_save_draft' => true,
            'ltp_download_pdf' => true,
            'ltp_use_ai_field_advisor' => true,
            'ltp_use_ai_sidebar' => true,
            'ltp_use_ai_interview' => true,
            'ltp_manage_firm' => true,
            'ltp_manage_seats' => true,
            'ltp_create_client_profile' => true,
            'ltp_view_firm_reports' => true,
            'ltp_cda_view_student_portal' => true,
            'ltp_cda_access_lab' => true,
            'ltp_cda_log_experience' => true,
            'ltp_cda_schedule_exam' => true,
            'ltp_cda_manage_program' => true,
            'ltp_cda_issue_certificates' => true,
        ];

        $custom_caps = get_option('ltp_custom_capabilities', []);
        if (is_array($custom_caps)) {
            foreach ($custom_caps as $cap) {
                $cap = sanitize_key((string) $cap);
                if ($cap) {
                    $caps[$cap] = true;
                }
            }
        }

        return apply_filters('ltp_all_caps_map', $caps);
    }
}
