<?php

namespace LifeTrustPlanning\Core;

/**
 * @deprecated Kept for backward compatibility with v0.0.1 hooks.
 */
class Membership_Bridge {
    public function init(): void {
        add_action('ltp_subscription_activated', [$this, 'on_activation'], 10, 2);
        add_action('ltp_subscription_cancelled', [$this, 'on_deactivation'], 10, 2);
    }

    public function on_activation(int $user_id, string $tier = 'free'): void {
        do_action('ltp_membership_assign_tier', $user_id, $tier, ['source' => 'legacy_bridge']);
    }

    public function on_deactivation(int $user_id): void {
        do_action('ltp_membership_downgrade_to_free', $user_id, ['source' => 'legacy_bridge']);
    }
}
