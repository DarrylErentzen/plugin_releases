<?php

namespace LifeTrustPlanning\Core;

class Tier_Config {
    public const DEFAULT_TIER_ROLE_MAP = [
        'free' => 'ltp_free',
        'essential' => 'ltp_essential',
        'premium' => 'ltp_premium',
        'ultimate' => 'ltp_ultimate',
        'graduate' => 'ltp_graduate',
    ];

    public static function all_caps(): array {
        return apply_filters('ltp_all_capabilities', Roles::all_caps());
    }

    public static function get_tier_cap_map(): array {
        $defaults = [
            'free' => [
                'ltp_create_document',
                'ltp_edit_own_documents',
                'ltp_use_ai_field_advisor',
            ],
            'essential' => [
                'ltp_create_document',
                'ltp_edit_own_documents',
                'ltp_save_draft',
                'ltp_download_pdf',
                'ltp_use_ai_field_advisor',
                'ltp_use_ai_sidebar',
                'ltp_use_ai_interview',
            ],
            'premium' => array_keys(self::all_caps()),
            'ultimate' => array_keys(self::all_caps()),
            'graduate' => array_keys(self::all_caps()),
        ];

        $saved = get_option('ltp_tier_capability_map', []);
        if (!is_array($saved) || empty($saved)) {
            $saved = $defaults;
        }

        foreach (array_keys(self::DEFAULT_TIER_ROLE_MAP) as $tier) {
            if (!isset($saved[$tier]) || !is_array($saved[$tier])) {
                $saved[$tier] = $defaults[$tier] ?? [];
            }
            $saved[$tier] = array_values(array_unique(array_filter(array_map('sanitize_key', $saved[$tier]))));
        }

        return apply_filters('ltp_tier_capability_map', $saved, $defaults);
    }

    public static function get_role_map(): array {
        $saved = get_option('ltp_tier_role_map', self::DEFAULT_TIER_ROLE_MAP);
        if (!is_array($saved) || empty($saved)) {
            $saved = self::DEFAULT_TIER_ROLE_MAP;
        }

        foreach (self::DEFAULT_TIER_ROLE_MAP as $tier => $role) {
            if (empty($saved[$tier])) {
                $saved[$tier] = $role;
            }
            $saved[$tier] = sanitize_key((string) $saved[$tier]);
        }

        return apply_filters('ltp_tier_role_map', $saved);
    }

    public static function role_for_tier(string $tier): string {
        $map = self::get_role_map();
        return $map[$tier] ?? $map['free'];
    }
}
