<?php

namespace LifeTrustPlanning\Core;

use LifeTrustPlanning\CDA\Program_Manager;

class Tier_Access {
    public static function get_user_tier(int $user_id = 0): string {
        $user_id = $user_id ?: get_current_user_id();
        if (!$user_id) {
            return 'free';
        }

        $tier = sanitize_key((string) get_user_meta($user_id, '_ltp_active_tier', true));
        if (!$tier) {
            $tier = 'free';
        }

        $tier = sanitize_key((string) apply_filters('ltp_user_tier', $tier, $user_id));
        return $tier ?: 'free';
    }

    public static function is_student(int $user_id = 0): bool {
        $user_id = $user_id ?: get_current_user_id();
        if (!$user_id) {
            return false;
        }

        return class_exists(Program_Manager::class) && Program_Manager::is_student($user_id);
    }

    public static function can(string $action, int $user_id = 0): bool {
        $user_id = $user_id ?: get_current_user_id();
        $tier = self::get_user_tier($user_id);

        return self::check_limits($action, $tier, $user_id);
    }

    private static function check_limits(string $action, string $tier, int $user_id): bool {
        $is_student = self::is_student($user_id);

        switch ($action) {
            case 'save_draft':
                if ($tier === 'free' && !$is_student) {
                    return self::count_active_drafts($user_id) < 1;
                }
                if ($tier === 'essential') {
                    return self::count_active_drafts($user_id) < 5;
                }
                return true;

            case 'access_draft':
                return $tier !== 'free' || $is_student;

            case 'download_pdf':
                return in_array($tier, ['essential', 'premium', 'ultimate', 'graduate'], true) || $is_student;

            case 'ai_field_advisor':
            case 'ai_sidebar':
            case 'ai_interview':
                if ($tier === 'free' || $is_student) {
                    return self::get_daily_ai_count($user_id) < (int) get_option('ltp_ai_free_daily_limit', 5);
                }
                return true;

            default:
                return true;
        }
    }

    public static function get_pdf_access_state(int $user_id = 0): string {
        $user_id = $user_id ?: get_current_user_id();
        $tier = self::get_user_tier($user_id);

        if ($tier === 'graduate') {
            return 'graduate';
        }

        if (in_array($tier, ['essential', 'premium', 'ultimate'], true)) {
            return 'member';
        }

        if (self::is_student($user_id)) {
            return 'student';
        }

        return 'free';
    }

    public static function watermark_text_for_state(string $state): string {
        $map = get_option('ltp_pdf_watermark_tier_text', [
            'free' => 'PREVIEW - Upgrade to unlock full PDF',
            'student' => 'STUDENT - FOR EDUCATIONAL USE ONLY',
            'member' => '',
            'graduate' => '',
            'sandbox' => 'SANDBOX - NOT FOR CLIENT USE',
        ]);

        if (!is_array($map)) {
            return '';
        }

        return sanitize_text_field((string) ($map[$state] ?? ''));
    }

    public static function get_limits_info(int $user_id = 0): array {
        $user_id = $user_id ?: get_current_user_id();
        $tier = self::get_user_tier($user_id);
        $ai_limit = (int) get_option('ltp_ai_free_daily_limit', 5);
        $daily = self::get_daily_ai_count($user_id);
        $draft_count = self::count_active_drafts($user_id);
        $is_student = self::is_student($user_id);

        return [
            'tier' => $tier,
            'is_student' => $is_student,
            'pdf_access_state' => self::get_pdf_access_state($user_id),
            'can_access_draft' => self::can('access_draft', $user_id),
            'can_use_ai_interview' => self::can('ai_interview', $user_id),
            'ai_remaining_today' => ($tier === 'free' || $is_student) ? max(0, $ai_limit - $daily) : -1,
            'drafts_locked' => ($tier === 'free' && !$is_student) ? $draft_count : 0,
            'drafts_saved' => $draft_count,
        ];
    }

    public static function count_active_drafts(int $user_id): int {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_documents';
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND status='draft'", $user_id));
    }

    public static function get_daily_ai_count(int $user_id): int {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_ai_interactions';
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND DATE(created_at)=%s",
            $user_id,
            current_time('Y-m-d')
        ));
    }

    public static function cleanup_old_ai_counters(): void {
        // No-op in table mode; retained for compatibility with older meta key strategy.
    }
}
