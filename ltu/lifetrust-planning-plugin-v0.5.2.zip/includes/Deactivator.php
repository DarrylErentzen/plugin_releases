<?php

namespace LifeTrustPlanning;

class Deactivator {
    public static function deactivate(): void {
        wp_clear_scheduled_hook('ltp_process_renewals');
        wp_clear_scheduled_hook('ltp_custom_recurring_tick');
        wp_clear_scheduled_hook('ltp_manual_renewal_tick');
        wp_clear_scheduled_hook('ltp_cleanup_pdfs');
        wp_clear_scheduled_hook('ltp_stale_draft_reminder');
        wp_clear_scheduled_hook('ltp_content_auto_update');
        flush_rewrite_rules();
    }
}
