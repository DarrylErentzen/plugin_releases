<?php

namespace LifeTrustPlanning\CDA;

class Data_Store {
    public static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ltp_';

        $sql = [];

        $sql[] = "CREATE TABLE {$p}cda_students (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            memberpress_membership_id BIGINT UNSIGNED DEFAULT NULL,
            enrolled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME DEFAULT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user (user_id),
            INDEX idx_status (status)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_course_progress (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            course_code VARCHAR(20) NOT NULL,
            completion_percent DECIMAL(5,2) DEFAULT 0,
            quiz_score DECIMAL(5,2) DEFAULT NULL,
            assignment_score DECIMAL(5,2) DEFAULT NULL,
            status VARCHAR(20) DEFAULT 'in_progress',
            lab_usage_count INT UNSIGNED DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user_course (user_id, course_code),
            INDEX idx_status (status)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_exams (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            exam_provider VARCHAR(50) DEFAULT 'memberpress_quiz',
            started_at DATETIME DEFAULT NULL,
            completed_at DATETIME DEFAULT NULL,
            score DECIMAL(5,2) DEFAULT NULL,
            passed TINYINT(1) DEFAULT 0,
            attempt_number INT UNSIGNED DEFAULT 1,
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_passed (passed)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_certificates (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            certificate_number VARCHAR(80) NOT NULL,
            issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) DEFAULT 'issued',
            pdf_path TEXT,
            UNIQUE KEY uniq_certificate_number (certificate_number),
            UNIQUE KEY uniq_user (user_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_experience_log (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            category VARCHAR(60) NOT NULL,
            hours DECIMAL(7,2) NOT NULL,
            entry_date DATE NOT NULL,
            description TEXT,
            verification_status VARCHAR(20) DEFAULT 'pending',
            reviewer_user_id BIGINT UNSIGNED DEFAULT NULL,
            reviewed_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_status (verification_status)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_graduates (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            display_name VARCHAR(255) NOT NULL,
            province VARCHAR(10) DEFAULT '',
            specializations TEXT,
            designation_date DATE NOT NULL,
            is_public TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user (user_id),
            INDEX idx_public (is_public),
            INDEX idx_province (province)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}cda_scenarios (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            scenario_code VARCHAR(30) NOT NULL,
            title VARCHAR(255) NOT NULL,
            payload LONGTEXT,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_code (scenario_code)
        ) {$charset_collate};";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }

        self::seed_scenarios();
        self::seed_catalog_options();
    }

    public static function seed_catalog_options(): void {
        if (!get_option('ltp_cda_course_tool_map')) {
            update_option('ltp_cda_course_tool_map', Catalog::course_tool_map());
        }

        if (!get_option('ltp_cda_curriculum_domains')) {
            update_option('ltp_cda_curriculum_domains', Catalog::domains());
        }
    }

    public static function seed_scenarios(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_scenarios';

        foreach (Catalog::scenarios() as $scenario) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE scenario_code=%s LIMIT 1",
                $scenario['code']
            ));

            if ($exists) {
                continue;
            }

            $wpdb->insert($table, [
                'scenario_code' => $scenario['code'],
                'title' => $scenario['name'],
                'payload' => wp_json_encode([
                    'watermark' => $scenario['watermark'],
                    'prefill' => [
                        'client_name' => $scenario['name'],
                        'notes' => 'Sandbox training profile for CDA practicum.',
                    ],
                ]),
                'is_active' => 1,
            ]);
        }
    }

    public static function ensure_student_record(int $user_id, ?int $membership_id = null): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_students';

        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$table} WHERE user_id=%d", $user_id));
        if ($existing) {
            $wpdb->update($table, [
                'status' => 'active',
                'memberpress_membership_id' => $membership_id,
            ], ['id' => (int) $existing->id]);
            return;
        }

        $wpdb->insert($table, [
            'user_id' => $user_id,
            'status' => 'active',
            'memberpress_membership_id' => $membership_id,
            'enrolled_at' => current_time('mysql'),
        ]);
    }

    public static function is_student(int $user_id): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_students';

        $status = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$table} WHERE user_id=%d LIMIT 1",
            $user_id
        ));

        return in_array((string) $status, ['active', 'exam_eligible', 'certification_pending'], true);
    }

    /** @return array<string, mixed> */
    public static function dashboard_data(int $user_id): array {
        global $wpdb;
        $progress_table = $wpdb->prefix . 'ltp_cda_course_progress';
        $exp_table = $wpdb->prefix . 'ltp_cda_experience_log';
        $exam_table = $wpdb->prefix . 'ltp_cda_exams';
        $cert_table = $wpdb->prefix . 'ltp_cda_certificates';

        $courses = Catalog::all_courses();
        $completed_codes = $wpdb->get_col($wpdb->prepare(
            "SELECT course_code FROM {$progress_table} WHERE user_id=%d AND status='completed'",
            $user_id
        )) ?: [];

        $domain_stats = [];
        foreach (Catalog::domains() as $domain) {
            $domain_courses = (array) ($domain['courses'] ?? []);
            $total = count($domain_courses);
            $done = 0;
            foreach ($domain_courses as $course) {
                if (in_array($course['code'], $completed_codes, true)) {
                    $done++;
                }
            }
            $domain_stats[] = [
                'domain_code' => $domain['domain_code'],
                'domain_name' => $domain['name'],
                'completed' => $done,
                'total' => $total,
                'percent' => $total ? round(($done / $total) * 100, 2) : 0,
            ];
        }

        $approved_hours = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(hours),0) FROM {$exp_table} WHERE user_id=%d AND verification_status='approved'",
            $user_id
        ));
        $pending_hours = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(hours),0) FROM {$exp_table} WHERE user_id=%d AND verification_status='pending'",
            $user_id
        ));

        $exam_passed = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$exam_table} WHERE user_id=%d AND passed=1",
            $user_id
        )) > 0;

        $certificate_status = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$cert_table} WHERE user_id=%d LIMIT 1",
            $user_id
        ));

        return [
            'domain_progress' => $domain_stats,
            'next_course' => Catalog::next_course_code($completed_codes),
            'available_lab_tools' => self::resolve_available_lab_tools($completed_codes),
            'approved_hours' => $approved_hours,
            'pending_hours' => $pending_hours,
            'hours_required' => (float) get_option('ltp_cda_experience_hour_requirement', 1000),
            'exam_eligible' => count($completed_codes) >= count($courses) && $approved_hours >= (float) get_option('ltp_cda_experience_hour_requirement', 1000),
            'exam_passed' => $exam_passed,
            'certificate_status' => $certificate_status ?: 'not_issued',
        ];
    }

    /** @param array<int, string> $completed_codes */
    private static function resolve_available_lab_tools(array $completed_codes): array {
        $map = get_option('ltp_cda_course_tool_map', Catalog::course_tool_map());
        $tools = [];

        foreach ($completed_codes as $code) {
            foreach ((array) ($map[$code] ?? []) as $tool) {
                if ($tool === 'all_tools') {
                    return ['all_tools'];
                }
                $tools[$tool] = true;
            }
        }

        return array_keys($tools);
    }

    /** @return array<int, array<string, mixed>> */
    public static function list_graduates(string $search = ''): array {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_graduates';

        $where = 'WHERE is_public=1';
        $params = [];

        if ($search !== '') {
            $where .= ' AND (display_name LIKE %s OR province LIKE %s OR specializations LIKE %s)';
            $like = '%' . $wpdb->esc_like($search) . '%';
            $params = [$like, $like, $like];
        }

        if (!empty($params)) {
            $sql = $wpdb->prepare("SELECT display_name, province, specializations, designation_date FROM {$table} {$where} ORDER BY designation_date DESC LIMIT 100", ...$params);
            return $wpdb->get_results($sql, ARRAY_A) ?: [];
        }

        return $wpdb->get_results("SELECT display_name, province, specializations, designation_date FROM {$table} {$where} ORDER BY designation_date DESC LIMIT 100", ARRAY_A) ?: [];
    }
}
