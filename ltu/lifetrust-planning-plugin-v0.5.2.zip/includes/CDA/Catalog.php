<?php

namespace LifeTrustPlanning\CDA;

class Catalog {
    /** @return array<int, array<string, mixed>> */
    public static function domains(): array {
        return [
            [
                'domain_code' => 'D1',
                'name' => 'Foundations',
                'hours' => 14,
                'courses' => [
                    ['code' => 'CDA_101', 'title' => 'CDA 101: Disability Landscape', 'hours' => 3],
                    ['code' => 'CDA_102', 'title' => 'CDA 102: Legal Frameworks', 'hours' => 3],
                    ['code' => 'CDA_103', 'title' => 'CDA 103: Person-Centred Planning', 'hours' => 4],
                    ['code' => 'CDA_104', 'title' => 'CDA 104: Ethics & Professional Responsibility', 'hours' => 4],
                ],
            ],
            [
                'domain_code' => 'D2',
                'name' => 'RDSP Mastery',
                'hours' => 18,
                'courses' => [
                    ['code' => 'CDA_201', 'title' => 'CDA 201: RDSP Fundamentals', 'hours' => 4],
                    ['code' => 'CDA_202', 'title' => 'CDA 202: Grant & Bond Calculations', 'hours' => 4],
                    ['code' => 'CDA_203', 'title' => 'CDA 203: Investment Strategies', 'hours' => 5],
                    ['code' => 'CDA_204', 'title' => 'CDA 204: Withdrawal Planning', 'hours' => 5],
                ],
            ],
            [
                'domain_code' => 'D3',
                'name' => 'Government Benefits',
                'hours' => 22,
                'courses' => [
                    ['code' => 'CDA_301', 'title' => 'CDA 301: DTC Eligibility', 'hours' => 4],
                    ['code' => 'CDA_302', 'title' => 'CDA 302: Provincial Programs (ODSP, PWD, AISH, etc.)', 'hours' => 8],
                    ['code' => 'CDA_303', 'title' => 'CDA 303: CPP-D & CDB', 'hours' => 5],
                    ['code' => 'CDA_304', 'title' => 'CDA 304: Clawback Calculations', 'hours' => 5],
                ],
            ],
            [
                'domain_code' => 'D4',
                'name' => 'Banking & Trusts',
                'hours' => 24,
                'courses' => [
                    ['code' => 'CDA_401', 'title' => 'CDA 401: Henson Trusts', 'hours' => 6],
                    ['code' => 'CDA_402', 'title' => 'CDA 402: QDTs & Safe Harbour Trusts', 'hours' => 6],
                    ['code' => 'CDA_403', 'title' => 'CDA 403: Testamentary Trusts', 'hours' => 6],
                    ['code' => 'CDA_404', 'title' => 'CDA 404: Banking Instruments', 'hours' => 6],
                ],
            ],
            [
                'domain_code' => 'D5',
                'name' => 'Discounts & Supports',
                'hours' => 12,
                'courses' => [
                    ['code' => 'CDA_501', 'title' => 'CDA 501: Federal Discounts', 'hours' => 4],
                    ['code' => 'CDA_502', 'title' => 'CDA 502: Provincial Programs', 'hours' => 4],
                    ['code' => 'CDA_503', 'title' => 'CDA 503: Community Resources', 'hours' => 4],
                ],
            ],
            [
                'domain_code' => 'D6',
                'name' => 'Holistic Planning',
                'hours' => 18,
                'courses' => [
                    ['code' => 'CDA_601', 'title' => 'CDA 601: Integrated Planning', 'hours' => 6],
                    ['code' => 'CDA_602', 'title' => 'CDA 602: Crisis Planning', 'hours' => 6],
                    ['code' => 'CDA_603', 'title' => 'CDA 603: Capstone Case Study', 'hours' => 6],
                ],
            ],
        ];
    }

    /** @return array<string, array<int, string>> */
    public static function course_tool_map(): array {
        return [
            'CDA_201' => ['rdsp_calculator'],
            'CDA_204' => ['rdsp_withdrawal_planner'],
            'CDA_302' => ['odsp_application'],
            'CDA_301' => ['dtc_application'],
            'CDA_401' => ['henson_trust'],
            'CDA_402' => ['qdt_calculator'],
            'CDA_603' => ['all_tools'],
        ];
    }

    /** @return array<int, array<string, string>> */
    public static function scenarios(): array {
        return [
            ['code' => 'SCENARIO_A', 'name' => 'Scenario A: Young Adult with CP', 'watermark' => 'SANDBOX - NOT FOR CLIENT USE'],
            ['code' => 'SCENARIO_B', 'name' => 'Scenario B: Mid-Life ASD', 'watermark' => 'SANDBOX - NOT FOR CLIENT USE'],
            ['code' => 'SCENARIO_C', 'name' => 'Scenario C: Senior with Dementia', 'watermark' => 'SANDBOX - NOT FOR CLIENT USE'],
            ['code' => 'SCENARIO_D', 'name' => 'Scenario D: Dual Diagnosis', 'watermark' => 'SANDBOX - NOT FOR CLIENT USE'],
            ['code' => 'SCENARIO_E', 'name' => 'Scenario E: Complex Family', 'watermark' => 'SANDBOX - NOT FOR CLIENT USE'],
        ];
    }

    /** @return array<string, float> */
    public static function member_course_discounts(): array {
        $saved = get_option('ltp_member_course_discounts', []);
        $defaults = ['essential' => 15.0, 'premium' => 25.0, 'ultimate' => 35.0];
        if (!is_array($saved)) {
            return $defaults;
        }

        foreach ($defaults as $tier => $value) {
            if (!isset($saved[$tier])) {
                $saved[$tier] = $value;
            }
            $saved[$tier] = (float) $saved[$tier];
        }

        return $saved;
    }

    /** @return array<string, float> */
    public static function bundle_prices(): array {
        return [
            'foundations_bundle' => 500,
            'rdsp_mastery_bundle' => 800,
            'government_benefits_bundle' => 900,
            'banking_trusts_bundle' => 1200,
            'discounts_supports_bundle' => 500,
            'holistic_planning_bundle' => 800,
            'full_designation_standard' => 3495,
            'full_designation_non_profit' => 1995,
            'full_designation_employer_seat' => 2795,
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public static function all_courses(): array {
        $courses = [];
        foreach (self::domains() as $domain) {
            foreach ((array) ($domain['courses'] ?? []) as $course) {
                $course['domain_code'] = $domain['domain_code'];
                $course['domain_name'] = $domain['name'];
                $courses[] = $course;
            }
        }
        return $courses;
    }

    public static function next_course_code(array $completed_codes): ?string {
        $completed_lookup = array_fill_keys(array_map('strtoupper', $completed_codes), true);
        foreach (self::all_courses() as $course) {
            if (!isset($completed_lookup[strtoupper((string) $course['code'])])) {
                return (string) $course['code'];
            }
        }
        return null;
    }
}
