<?php

namespace LifeTrustPlanning\CDA;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Membership\MemberPress_Provider;

class Program_Manager {
    public static function init(): void {
        add_shortcode('ltp_cda_course_catalog', [self::class, 'render_course_catalog']);
        add_shortcode('ltp_cda_student_dashboard', [self::class, 'render_student_dashboard']);
        add_shortcode('ltp_cda_graduate_registry', [self::class, 'render_graduate_registry']);
        add_shortcode('ltp_cda_enrollment_cta', [self::class, 'render_enrollment_cta']);
        add_shortcode('ltp_cda_certification_badge', [self::class, 'render_certification_badge']);
        add_shortcode('ltp_cda_experience_log', [self::class, 'render_experience_log']);
        add_shortcode('ltp_cda_exam_schedule', [self::class, 'render_exam_schedule']);

        add_action('init', [self::class, 'sync_current_user_student_status'], 30);
        add_action('admin_post_ltp_cda_log_experience', [self::class, 'handle_experience_log']);
        add_action('admin_post_ltp_cda_admin_mark_experience', [self::class, 'handle_admin_experience_review']);
        add_action('admin_post_ltp_cda_issue_certificate', [self::class, 'handle_issue_certificate']);

        add_action('woocommerce_before_calculate_totals', [self::class, 'apply_member_course_discount'], 20);
        add_action('ltp_document_pdf_generated', [self::class, 'track_document_usage'], 10, 2);

        add_action('admin_menu', [self::class, 'register_admin_menu']);
        add_action('init', [self::class, 'maybe_create_cda_products'], 40);
    }

    public static function register_admin_menu(): void {
        add_submenu_page(
            'lifetrust-planning',
            'CDA Management',
            'CDA Management',
            'manage_options',
            'lifetrust-planning-cda',
            [self::class, 'render_admin_page']
        );
    }

    public static function sync_current_user_student_status(): void {
        if (!is_user_logged_in()) {
            return;
        }

        $user_id = get_current_user_id();
        $course_memberships = array_filter(array_map('absint', (array) get_option('ltp_cda_student_membership_ids', [])));
        if (empty($course_memberships)) {
            return;
        }

        $active_ids = MemberPress_Provider::get_active_membership_ids($user_id);
        $matched = array_values(array_intersect($active_ids, $course_memberships));
        if (!empty($matched)) {
            Data_Store::ensure_student_record($user_id, (int) $matched[0]);
            return;
        }

        // Revoke student lab access once course-linked enrollments end, unless user is on paid member/graduate tier.
        $tier = Tier_Access::get_user_tier($user_id);
        if (in_array($tier, ['essential', 'premium', 'ultimate', 'graduate'], true)) {
            return;
        }

        global $wpdb;
        $students_table = $wpdb->prefix . 'ltp_cda_students';
        $progress_table = $wpdb->prefix . 'ltp_cda_course_progress';
        $completed_courses = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$progress_table} WHERE user_id=%d AND status='completed'",
            $user_id
        ));

        $required_courses = count(Catalog::all_courses());
        if ($completed_courses >= $required_courses) {
            $wpdb->update($students_table, ['status' => 'completed', 'completed_at' => current_time('mysql')], ['user_id' => $user_id]);
        } else {
            $wpdb->update($students_table, ['status' => 'withdrawn'], ['user_id' => $user_id]);
        }
    }

    public static function is_student(int $user_id): bool {
        return Data_Store::is_student($user_id);
    }

    public static function apply_member_course_discount($cart): void {
        if (!function_exists('is_admin') || is_admin()) {
            return;
        }

        if (!$cart || !is_user_logged_in()) {
            return;
        }

        $tier = Tier_Access::get_user_tier(get_current_user_id());
        $discounts = Catalog::member_course_discounts();
        $discount_percent = (float) ($discounts[$tier] ?? 0);

        if ($discount_percent <= 0) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item) {
            if (empty($cart_item['data']) || !is_object($cart_item['data'])) {
                continue;
            }

            $product_id = (int) $cart_item['data']->get_id();
            $is_course = (string) get_post_meta($product_id, '_ltp_cda_product_type', true);
            if (!in_array($is_course, ['course', 'bundle', 'full_designation'], true)) {
                continue;
            }

            $base_price = (float) $cart_item['data']->get_regular_price();
            if ($base_price <= 0) {
                $base_price = (float) $cart_item['data']->get_price();
            }

            $discounted = round($base_price * (1 - ($discount_percent / 100)), 2);
            $cart_item['data']->set_price($discounted);
        }
    }

    public static function maybe_create_cda_products(): void {
        if (!function_exists('wc_get_product') || !current_user_can('manage_options')) {
            return;
        }

        if (!get_option('ltp_autocreate_cda_products', 1)) {
            return;
        }

        if (get_option('ltp_cda_products_initialized', 0)) {
            return;
        }

        self::create_or_update_cda_products();
        update_option('ltp_cda_products_initialized', 1);
    }

    /** @return array<string, int> */
    public static function create_or_update_cda_products(): array {
        if (!function_exists('wc_get_product')) {
            return [];
        }

        $map = (array) get_option('ltp_cda_wc_product_map', []);

        foreach (Catalog::all_courses() as $course) {
            $code = (string) $course['code'];
            $price = max(99.0, min(499.0, ((float) $course['hours']) * 25));
            $map[$code] = self::upsert_product(
                (int) ($map[$code] ?? 0),
                $course['title'],
                $price,
                ['_ltp_cda_product_type' => 'course', '_ltp_cda_course_code' => $code]
            );
        }

        $bundles = [
            'Foundations Bundle' => ['foundations_bundle', 500],
            'RDSP Mastery Bundle' => ['rdsp_mastery_bundle', 800],
            'Government Benefits Bundle' => ['government_benefits_bundle', 900],
            'Banking & Trusts Bundle' => ['banking_trusts_bundle', 1200],
            'Discounts & Supports Bundle' => ['discounts_supports_bundle', 500],
            'Holistic Planning Bundle' => ['holistic_planning_bundle', 800],
            'Full Designation - Standard' => ['full_designation_standard', 3495],
            'Full Designation - Non-Profit' => ['full_designation_non_profit', 1995],
            'Full Designation - Employer (per seat)' => ['full_designation_employer_seat', 2795],
        ];

        foreach ($bundles as $name => $definition) {
            $key = (string) $definition[0];
            $price = (float) $definition[1];
            $ptype = str_starts_with($key, 'full_designation') ? 'full_designation' : 'bundle';
            $map[$key] = self::upsert_product((int) ($map[$key] ?? 0), $name, $price, [
                '_ltp_cda_product_type' => $ptype,
                '_ltp_cda_bundle_key' => $key,
            ]);
        }

        update_option('ltp_cda_wc_product_map', $map);
        return $map;
    }

    private static function upsert_product(int $product_id, string $name, float $price, array $meta): int {
        $product = $product_id ? wc_get_product($product_id) : false;
        if (!$product) {
            $product = new \WC_Product_Simple();
            $product->set_status('publish');
            $product->set_virtual(true);
        }

        $product->set_name($name);
        $product->set_regular_price((string) round($price, 2));
        $product->set_price((string) round($price, 2));
        $new_id = $product->save();

        foreach ($meta as $key => $value) {
            update_post_meta($new_id, $key, $value);
        }

        return (int) $new_id;
    }

    public static function track_document_usage(int $document_id, string $filepath): void {
        $user_id = get_current_user_id();
        if (!$user_id || !self::is_student($user_id)) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_course_progress';
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET lab_usage_count = lab_usage_count + 1 WHERE user_id=%d",
            $user_id
        ));
    }

    public static function render_course_catalog(): string {
        $html = '<div class="ltp-cda-catalog"><h3>CDA Course Catalog</h3>';
        foreach (Catalog::domains() as $domain) {
            $html .= '<h4>' . esc_html($domain['name'] . ' (' . $domain['hours'] . 'h)') . '</h4><ul>';
            foreach ((array) $domain['courses'] as $course) {
                $html .= '<li><strong>' . esc_html($course['code']) . '</strong> — ' . esc_html($course['title']) . ' (' . esc_html((string) $course['hours']) . 'h)</li>';
            }
            $html .= '</ul>';
        }
        $html .= '</div>';
        return $html;
    }

    public static function render_student_dashboard(): string {
        if (!is_user_logged_in()) {
            return '<p>Please log in to view your student dashboard.</p>';
        }

        $data = Data_Store::dashboard_data(get_current_user_id());

        $html = '<div class="ltp-cda-student-dashboard">';
        $html .= '<h3>CDA Student Portal</h3>';
        $html .= '<p><strong>Next recommended course:</strong> ' . esc_html((string) ($data['next_course'] ?: 'All courses completed')) . '</p>';

        $html .= '<h4>Domain Progress</h4><ul>';
        foreach ((array) $data['domain_progress'] as $domain) {
            $html .= '<li>' . esc_html($domain['domain_name']) . ': ' . esc_html((string) $domain['percent']) . '% (' . esc_html((string) $domain['completed']) . '/' . esc_html((string) $domain['total']) . ')</li>';
        }
        $html .= '</ul>';

        $html .= '<p><strong>Available lab tools:</strong> ' . esc_html(implode(', ', (array) $data['available_lab_tools']) ?: 'None yet') . '</p>';
        $html .= '<p><strong>Experience hours:</strong> ' . esc_html((string) $data['approved_hours']) . ' approved + ' . esc_html((string) $data['pending_hours']) . ' pending (target ' . esc_html((string) $data['hours_required']) . ')</p>';
        $html .= '<p><strong>Exam eligibility:</strong> ' . ($data['exam_eligible'] ? 'Eligible' : 'Not yet') . '</p>';
        $html .= '<p><strong>Certification status:</strong> ' . esc_html((string) $data['certificate_status']) . '</p>';
        $html .= '</div>';

        return $html;
    }

    public static function render_graduate_registry(): string {
        $search = isset($_GET['ltp_cda_search']) ? sanitize_text_field((string) $_GET['ltp_cda_search']) : '';
        $graduates = Data_Store::list_graduates($search);

        $html = '<div class="ltp-cda-graduate-registry"><h3>CDA Graduate Registry</h3>';
        $html .= '<form method="get"><input type="text" name="ltp_cda_search" value="' . esc_attr($search) . '" placeholder="Search name, province, specialization"> <button type="submit">Search</button></form>';
        $html .= '<table><thead><tr><th>Name</th><th>Province</th><th>Specializations</th><th>Designation Date</th></tr></thead><tbody>';

        if (empty($graduates)) {
            $html .= '<tr><td colspan="4">No graduates found.</td></tr>';
        } else {
            foreach ($graduates as $grad) {
                $html .= '<tr><td>' . esc_html((string) $grad['display_name']) . '</td><td>' . esc_html((string) $grad['province']) . '</td><td>' . esc_html((string) $grad['specializations']) . '</td><td>' . esc_html((string) $grad['designation_date']) . '</td></tr>';
            }
        }

        $html .= '</tbody></table></div>';
        return $html;
    }

    public static function render_enrollment_cta(): string {
        return '<div class="ltp-cda-enrollment-cta"><h3>Enroll in the CDA Program</h3><p>Access 108 hours across 6 domains with MemberPress-powered progression and LifeTrust sandbox labs.</p></div>';
    }

    public static function render_certification_badge(): string {
        if (!is_user_logged_in()) {
            return '';
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_certificates';
        $cert = $wpdb->get_row($wpdb->prepare("SELECT certificate_number, issued_at FROM {$table} WHERE user_id=%d LIMIT 1", get_current_user_id()), ARRAY_A);

        if (!$cert) {
            return '<span class="ltp-cda-badge ltp-cda-badge--pending">CDA Candidate</span>';
        }

        return '<span class="ltp-cda-badge ltp-cda-badge--certified">CDA® Certified (' . esc_html((string) $cert['certificate_number']) . ')</span>';
    }

    public static function render_experience_log(): string {
        if (!is_user_logged_in()) {
            return '<p>Please log in to log experience.</p>';
        }

        $action = esc_url(admin_url('admin-post.php'));
        $nonce = wp_create_nonce('ltp_cda_log_experience');

        return '<form method="post" action="' . $action . '">
            <input type="hidden" name="action" value="ltp_cda_log_experience" />
            <input type="hidden" name="_wpnonce" value="' . esc_attr($nonce) . '" />
            <p><label>Category <select name="category"><option>RDSP</option><option>DTC</option><option>Trusts</option><option>Provincial Programs</option><option>Holistic Planning</option></select></label></p>
            <p><label>Hours <input type="number" step="0.25" min="0.25" name="hours" required /></label></p>
            <p><label>Date <input type="date" name="entry_date" required /></label></p>
            <p><label>Description <textarea name="description" rows="4" class="large-text"></textarea></label></p>
            <p><button type="submit">Log Experience</button></p>
        </form>';
    }

    public static function render_exam_schedule(): string {
        $passing = (int) get_option('ltp_cda_exam_passing_score', 70);
        return '<div class="ltp-cda-exam-schedule"><h3>CDA Comprehensive Exam</h3><p>Exam is delivered through MemberPress Quizzes/Assignments workflows with admin-controlled scheduling.</p><ul><li>Duration: 4 hours</li><li>Question count: 100 MCQs equivalent assessment coverage</li><li>Passing score: ' . esc_html((string) $passing) . '%</li></ul></div>';
    }

    public static function handle_experience_log(): void {
        if (!is_user_logged_in()) {
            wp_safe_redirect(wp_login_url());
            exit;
        }

        check_admin_referer('ltp_cda_log_experience');

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_experience_log';
        $wpdb->insert($table, [
            'user_id' => get_current_user_id(),
            'category' => sanitize_text_field((string) ($_POST['category'] ?? 'General')),
            'hours' => (float) ($_POST['hours'] ?? 0),
            'entry_date' => sanitize_text_field((string) ($_POST['entry_date'] ?? current_time('Y-m-d'))),
            'description' => sanitize_textarea_field((string) ($_POST['description'] ?? '')),
            'verification_status' => 'pending',
        ]);

        wp_safe_redirect(wp_get_referer() ?: home_url('/student-portal/'));
        exit;
    }

    public static function handle_admin_experience_review(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('ltp_cda_admin_action');

        global $wpdb;
        $table = $wpdb->prefix . 'ltp_cda_experience_log';
        $entry_id = absint((int) ($_POST['entry_id'] ?? 0));
        $status = sanitize_key((string) ($_POST['status'] ?? 'pending'));

        if ($entry_id > 0 && in_array($status, ['approved', 'rejected', 'pending'], true)) {
            $wpdb->update($table, [
                'verification_status' => $status,
                'reviewer_user_id' => get_current_user_id(),
                'reviewed_at' => current_time('mysql'),
            ], ['id' => $entry_id]);
        }

        wp_safe_redirect(admin_url('admin.php?page=lifetrust-planning-cda'));
        exit;
    }

    public static function handle_issue_certificate(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('ltp_cda_admin_action');

        $user_id = absint((int) ($_POST['user_id'] ?? 0));
        if ($user_id <= 0) {
            wp_safe_redirect(admin_url('admin.php?page=lifetrust-planning-cda'));
            exit;
        }

        if (!self::is_certification_ready($user_id)) {
            wp_safe_redirect(admin_url('admin.php?page=lifetrust-planning-cda&issue_error=not_ready'));
            exit;
        }

        global $wpdb;
        $cert_table = $wpdb->prefix . 'ltp_cda_certificates';
        $grad_table = $wpdb->prefix . 'ltp_cda_graduates';
        $students_table = $wpdb->prefix . 'ltp_cda_students';

        $cert_number = 'CDA-' . gmdate('Y') . '-' . wp_generate_password(8, false, false);
        $wpdb->replace($cert_table, [
            'user_id' => $user_id,
            'certificate_number' => $cert_number,
            'issued_at' => current_time('mysql'),
            'status' => 'issued',
            'pdf_path' => '',
        ]);

        $user = get_userdata($user_id);
        $display_name = $user ? $user->display_name : ('User ' . $user_id);
        $province = (string) get_user_meta($user_id, 'ltp_province', true);

        $wpdb->replace($grad_table, [
            'user_id' => $user_id,
            'display_name' => $display_name,
            'province' => $province,
            'specializations' => 'General CDA Planning',
            'designation_date' => current_time('Y-m-d'),
            'is_public' => 1,
        ]);

        $wpdb->update($students_table, ['status' => 'graduated', 'completed_at' => current_time('mysql')], ['user_id' => $user_id]);
        do_action('ltp_membership_assign_tier', $user_id, 'graduate', ['source' => 'cda_certification']);

        wp_safe_redirect(admin_url('admin.php?page=lifetrust-planning-cda&issue_success=1'));
        exit;
    }

    public static function is_certification_ready(int $user_id): bool {
        global $wpdb;
        $progress_table = $wpdb->prefix . 'ltp_cda_course_progress';
        $exams_table = $wpdb->prefix . 'ltp_cda_exams';
        $exp_table = $wpdb->prefix . 'ltp_cda_experience_log';

        $required_courses = count(Catalog::all_courses());
        $completed_courses = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$progress_table} WHERE user_id=%d AND status='completed'",
            $user_id
        ));

        $passing = (int) get_option('ltp_cda_exam_passing_score', 70);
        $exam_passed = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$exams_table} WHERE user_id=%d AND passed=1 AND score >= %f",
            $user_id,
            $passing
        )) > 0;

        $hours_required = (float) get_option('ltp_cda_experience_hour_requirement', 1000);
        $hours_approved = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(hours),0) FROM {$exp_table} WHERE user_id=%d AND verification_status='approved'",
            $user_id
        ));

        return $completed_courses >= $required_courses && $exam_passed && $hours_approved >= $hours_required;
    }

    public static function render_admin_page(): void {
        global $wpdb;
        $students_table = $wpdb->prefix . 'ltp_cda_students';
        $exp_table = $wpdb->prefix . 'ltp_cda_experience_log';

        $students = $wpdb->get_results("SELECT * FROM {$students_table} ORDER BY updated_at DESC LIMIT 100", ARRAY_A) ?: [];
        $pending_experience = $wpdb->get_results("SELECT * FROM {$exp_table} WHERE verification_status='pending' ORDER BY created_at DESC LIMIT 100", ARRAY_A) ?: [];

        echo '<div class="wrap"><h1>CDA Management</h1>';
        echo '<p>Student roster, progress oversight, experience review, and certification issuance.</p>';

        echo '<h2>Student Roster</h2><table class="widefat striped"><thead><tr><th>User ID</th><th>Status</th><th>Enrolled At</th><th>Actions</th></tr></thead><tbody>';
        foreach ($students as $student) {
            echo '<tr>';
            echo '<td>' . esc_html((string) $student['user_id']) . '</td>';
            echo '<td>' . esc_html((string) $student['status']) . '</td>';
            echo '<td>' . esc_html((string) $student['enrolled_at']) . '</td>';
            echo '<td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('ltp_cda_admin_action');
            echo '<input type="hidden" name="action" value="ltp_cda_issue_certificate">';
            echo '<input type="hidden" name="user_id" value="' . esc_attr((string) $student['user_id']) . '">';
            submit_button('Issue Certificate', 'secondary small', 'submit', false);
            echo '</form></td>';
            echo '</tr>';
        }
        if (empty($students)) {
            echo '<tr><td colspan="4">No students yet.</td></tr>';
        }
        echo '</tbody></table>';

        echo '<h2>Pending Experience Logs</h2><table class="widefat striped"><thead><tr><th>User ID</th><th>Category</th><th>Hours</th><th>Date</th><th>Action</th></tr></thead><tbody>';
        foreach ($pending_experience as $entry) {
            echo '<tr>';
            echo '<td>' . esc_html((string) $entry['user_id']) . '</td>';
            echo '<td>' . esc_html((string) $entry['category']) . '</td>';
            echo '<td>' . esc_html((string) $entry['hours']) . '</td>';
            echo '<td>' . esc_html((string) $entry['entry_date']) . '</td>';
            echo '<td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:flex;gap:8px;align-items:center;">';
            wp_nonce_field('ltp_cda_admin_action');
            echo '<input type="hidden" name="action" value="ltp_cda_admin_mark_experience">';
            echo '<input type="hidden" name="entry_id" value="' . esc_attr((string) $entry['id']) . '">';
            echo '<select name="status"><option value="approved">Approve</option><option value="rejected">Reject</option><option value="pending">Keep Pending</option></select>';
            submit_button('Update', 'secondary small', 'submit', false);
            echo '</form></td>';
            echo '</tr>';
        }
        if (empty($pending_experience)) {
            echo '<tr><td colspan="5">No pending logs.</td></tr>';
        }
        echo '</tbody></table>';

        echo '</div>';
    }
}
