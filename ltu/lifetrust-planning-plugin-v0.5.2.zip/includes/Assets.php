<?php

namespace LifeTrustPlanning;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Documents\Document_Types;

class Assets {
    public static function register(): void {
        wp_register_script(
            'ltp-forms',
            LTP_PLUGIN_URL . 'assets/build/ltp-forms.js',
            ['wp-element'],
            LTP_VERSION,
            true
        );

        wp_register_style(
            'ltp-forms',
            LTP_PLUGIN_URL . 'assets/build/ltp-forms.css',
            [],
            LTP_VERSION
        );

        wp_localize_script('ltp-forms', 'ltpFormData', [
            'restUrl' => esc_url_raw(rest_url('ltp/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'userTier' => Tier_Access::get_user_tier(),
            'limits' => Tier_Access::get_limits_info(),
            'documentTypes' => Document_Types::get_all(),
            'provinces' => Core\Provinces::all(),
        ]);

        wp_register_style(
            'ltp-marketing',
            LTP_PLUGIN_URL . 'assets/marketing.css',
            [],
            LTP_VERSION
        );

        wp_register_script(
            'ltp-marketing',
            LTP_PLUGIN_URL . 'assets/marketing.js',
            [],
            LTP_VERSION,
            true
        );
    }
}
