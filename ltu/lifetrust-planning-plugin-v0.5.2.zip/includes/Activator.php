<?php

namespace LifeTrustPlanning;

use LifeTrustPlanning\Content\Content_Post_Types;
use LifeTrustPlanning\Content\Content_Taxonomies;
use LifeTrustPlanning\Core\Roles;
use LifeTrustPlanning\Marketing\Marketing_Content;
use LifeTrustPlanning\CDA\Data_Store;

class Activator {
    public static function activate(): void {
        self::check_requirements();
        self::create_tables();
        Roles::register_roles_and_caps();

        Content_Post_Types::register();
        Content_Taxonomies::register();
        flush_rewrite_rules();

        self::set_default_options();
        self::create_default_pages();
        self::schedule_cron();

        if (!get_option('ltp_activation_seed_pending')) {
            update_option('ltp_activation_seed_pending', 1);
        }
    }

    private static function check_requirements(): void {
        global $wp_version;

        if (version_compare(PHP_VERSION, '8.1', '<')) {
            wp_die('LifeTrust Planning requires PHP 8.1+');
        }

        if (version_compare($wp_version, '5.9', '<')) {
            wp_die('LifeTrust Planning requires WordPress 5.9+');
        }
    }

    private static function set_default_options(): void {
        $defaults = [
            'ltp_ai_primary_provider' => 'gemini',
            'ltp_ai_fallback_providers' => ['openai', 'anthropic'],
            'ltp_ai_free_daily_limit' => 5,
            'ltp_pdf_engine' => 'mpdf',
            'ltp_pdf_watermark_text' => 'PREVIEW - Upgrade to unlock full PDF',
            'ltp_form_default_navigation_mode' => 'tab',
            'ltp_content_import_completed' => 0,
            'ltp_membership_provider' => 'memberpress',
            'ltp_billing_provider' => 'custom_recurring',
            'ltp_base_monthly_prices' => ['essential' => 30, 'premium' => 60, 'ultimate' => 150],
            'ltp_quarterly_discount_percentage' => 15,
            'ltp_yearly_discount_percentage' => 30,
            'ltp_manual_grace_days' => 5,
            'ltp_custom_recurring_retry_limit' => 3,
            'ltp_custom_recurring_grace_days' => 7,
            'ltp_dashboard_cta_content' => '<p>Upgrade your LifeTrust tier to unlock more AI help, premium forms, and full planning workflows.</p>',
            'ltp_tier_role_map' => [
                'free' => 'ltp_free',
                'essential' => 'ltp_essential',
                'premium' => 'ltp_premium',
                'ultimate' => 'ltp_ultimate',
                'graduate' => 'ltp_graduate',
            ],
            'ltp_custom_capabilities' => [],
            'ltp_autocreate_wc_products' => 1,
            'ltp_marketing_content' => Marketing_Content::get_defaults(),
            'ltp_memberpress_tier_membership_map' => ['free' => 0, 'essential' => 0, 'premium' => 0, 'ultimate' => 0, 'graduate' => 0],
            'ltp_cda_student_membership_ids' => [],
            'ltp_member_course_discounts' => ['essential' => 15, 'premium' => 25, 'ultimate' => 35],
            'ltp_pdf_watermark_tier_text' => [
                'free' => 'PREVIEW - Upgrade to unlock full PDF',
                'student' => 'STUDENT - FOR EDUCATIONAL USE ONLY',
                'member' => '',
                'graduate' => '',
                'sandbox' => 'SANDBOX - NOT FOR CLIENT USE',
            ],
            'ltp_cda_exam_passing_score' => 70,
            'ltp_cda_experience_hour_requirement' => 1000,
            'ltp_cda_registry_default_visibility' => 1,
            'ltp_autocreate_cda_products' => 1,
            'ltp_schema_version' => '0.5.2',
        ];

        foreach ($defaults as $key => $value) {
            if (get_option($key, null) === null) {
                update_option($key, $value);
            }
        }
    }

    private static function create_default_pages(): void {
        $pages = [
            [
                'slug' => 'member-portal',
                'title' => 'Member Portal',
                'content' => '[ltp_member_portal]',
            ],
            [
                'slug' => 'pricing',
                'title' => 'Pricing',
                'content' => '[ltp_pricing_table]',
            ],
            [
                'slug' => 'student-portal',
                'title' => 'Student Portal',
                'content' => '[ltp_cda_student_dashboard]',
            ],
            [
                'slug' => 'cda-graduates',
                'title' => 'CDA Graduates',
                'content' => '[ltp_cda_graduate_registry]',
            ],
            [
                'slug' => 'cda-courses',
                'title' => 'CDA Course Catalog',
                'content' => '[ltp_cda_course_catalog]',
            ],
        ];

        foreach ($pages as $page) {
            if (get_page_by_path($page['slug'])) {
                continue;
            }

            wp_insert_post([
                'post_title' => $page['title'],
                'post_name' => $page['slug'],
                'post_content' => $page['content'],
                'post_status' => 'publish',
                'post_type' => 'page',
            ]);
        }
    }

    private static function schedule_cron(): void {
        if (!wp_next_scheduled('ltp_process_renewals')) {
            wp_schedule_event(time(), 'hourly', 'ltp_process_renewals');
        }

        if (!wp_next_scheduled('ltp_custom_recurring_tick')) {
            wp_schedule_event(time(), 'hourly', 'ltp_custom_recurring_tick');
        }

        if (!wp_next_scheduled('ltp_manual_renewal_tick')) {
            wp_schedule_event(time(), 'daily', 'ltp_manual_renewal_tick');
        }

        if (!wp_next_scheduled('ltp_cleanup_pdfs')) {
            wp_schedule_event(time(), 'weekly', 'ltp_cleanup_pdfs');
        }

        if (!wp_next_scheduled('ltp_stale_draft_reminder')) {
            wp_schedule_event(time(), 'daily', 'ltp_stale_draft_reminder');
        }

        add_filter('cron_schedules', static function (array $schedules): array {
            if (!isset($schedules['ltp_30_days'])) {
                $schedules['ltp_30_days'] = [
                    'interval' => 30 * DAY_IN_SECONDS,
                    'display' => 'Every 30 Days',
                ];
            }
            return $schedules;
        });

        if (!wp_next_scheduled('ltp_content_auto_update')) {
            wp_schedule_event(time(), 'ltp_30_days', 'ltp_content_auto_update');
        }
    }

    private static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $p = $wpdb->prefix . 'ltp_';

        $sql = [];

        $sql[] = "CREATE TABLE {$p}documents (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            firm_id BIGINT UNSIGNED DEFAULT NULL,
            client_profile_id BIGINT UNSIGNED DEFAULT NULL,
            type VARCHAR(50) NOT NULL,
            title VARCHAR(255) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            content LONGTEXT,
            generated_document LONGTEXT,
            progress_percentage TINYINT UNSIGNED DEFAULT 0,
            version INT UNSIGNED DEFAULT 1,
            parent_id BIGINT UNSIGNED DEFAULT NULL,
            province VARCHAR(5) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_firm (firm_id),
            INDEX idx_client (client_profile_id),
            INDEX idx_type_status (type, status)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}contacts (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            firm_id BIGINT UNSIGNED DEFAULT NULL,
            client_profile_id BIGINT UNSIGNED DEFAULT NULL,
            first_name VARCHAR(100), last_name VARCHAR(100),
            email VARCHAR(255), phone VARCHAR(30),
            address_line1 VARCHAR(255), address_line2 VARCHAR(255),
            city VARCHAR(100), province VARCHAR(5), postal_code VARCHAR(10), country VARCHAR(5) DEFAULT 'CA',
            relationship VARCHAR(50), role_type VARCHAR(50),
            specializations TEXT, organization VARCHAR(255), notes TEXT,
            is_emergency_contact BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id), INDEX idx_firm (firm_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}assets (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            firm_id BIGINT UNSIGNED DEFAULT NULL,
            client_profile_id BIGINT UNSIGNED DEFAULT NULL,
            type VARCHAR(30) NOT NULL,
            name VARCHAR(255) NOT NULL, description TEXT,
            ownership_type VARCHAR(20), co_owners TEXT,
            estimated_value DECIMAL(15,2), currency VARCHAR(5) DEFAULT 'CAD',
            legal_description TEXT, beneficiaries TEXT, encumbrances TEXT,
            income_amount DECIMAL(15,2), expense_amount DECIMAL(15,2),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}asset_valuations (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            asset_id BIGINT UNSIGNED NOT NULL,
            valuation_type VARCHAR(20), value DECIMAL(15,2) NOT NULL,
            valuation_date DATE NOT NULL, notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_asset_id (asset_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}ai_interactions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            session_id VARCHAR(64),
            query TEXT NOT NULL, response TEXT NOT NULL,
            provider VARCHAR(30), model VARCHAR(50), tokens_used INT UNSIGNED DEFAULT 0,
            category VARCHAR(50), context_document_id BIGINT UNSIGNED DEFAULT NULL,
            context_field VARCHAR(100) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id), INDEX idx_session (session_id), INDEX idx_created (created_at)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}firms (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            owner_user_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(255) NOT NULL,
            tier VARCHAR(20) DEFAULT 'premium',
            max_seats INT UNSIGNED DEFAULT 5,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_owner (owner_user_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}firm_seats (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            firm_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED DEFAULT NULL,
            seat_status VARCHAR(20) DEFAULT 'available',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_firm (firm_id), INDEX idx_user (user_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}client_profiles (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            firm_id BIGINT UNSIGNED NOT NULL,
            assigned_user_id BIGINT UNSIGNED DEFAULT NULL,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_firm (firm_id), INDEX idx_assigned (assigned_user_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}subscriptions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            tier VARCHAR(20) NOT NULL,
            billing_interval VARCHAR(20) DEFAULT 'monthly',
            provider_key VARCHAR(50) DEFAULT 'custom_recurring',
            status VARCHAR(20) DEFAULT 'active',
            wc_order_id BIGINT UNSIGNED DEFAULT NULL,
            wc_product_id BIGINT UNSIGNED DEFAULT NULL,
            amount DECIMAL(12,2) DEFAULT 0,
            currency VARCHAR(12) DEFAULT 'CAD',
            next_billing_at DATETIME DEFAULT NULL,
            expires_at DATETIME DEFAULT NULL,
            grace_ends_at DATETIME DEFAULT NULL,
            retry_count INT UNSIGNED DEFAULT 0,
            cancelled_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_provider_status_next (provider_key, status, next_billing_at)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}payment_methods (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            gateway_id VARCHAR(100) NOT NULL,
            token_id VARCHAR(100) NOT NULL,
            is_default TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user_gateway (user_id, gateway_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}billing_history (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            subscription_id BIGINT UNSIGNED DEFAULT NULL,
            wc_order_id BIGINT UNSIGNED DEFAULT NULL,
            event_type VARCHAR(50) NOT NULL,
            status VARCHAR(30) NOT NULL,
            note TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_subscription (subscription_id),
            INDEX idx_order (wc_order_id)
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}automation_rules (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            event_key VARCHAR(100) NOT NULL,
            payload LONGTEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) {$charset_collate};";

        $sql[] = "CREATE TABLE {$p}pdf_templates (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            category VARCHAR(50) NOT NULL,
            file_type VARCHAR(10) NOT NULL,
            file_path TEXT,
            file_url TEXT,
            document_type VARCHAR(50),
            is_active BOOLEAN DEFAULT TRUE,
            version INT UNSIGNED DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_document_type (document_type),
            INDEX idx_category (category)
        ) {$charset_collate};";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }

        Data_Store::create_tables();
    }
}
