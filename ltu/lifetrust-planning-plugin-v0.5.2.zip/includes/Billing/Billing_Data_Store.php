<?php

namespace LifeTrustPlanning\Billing;

class Billing_Data_Store {
    private string $subscriptions_table;
    private string $payment_methods_table;
    private string $billing_history_table;

    public function __construct() {
        global $wpdb;
        $p = $wpdb->prefix;
        $this->subscriptions_table = $p . 'ltp_subscriptions';
        $this->payment_methods_table = $p . 'ltp_payment_methods';
        $this->billing_history_table = $p . 'ltp_billing_history';
    }

    public function get_due_subscriptions(string $provider_key): array {
        global $wpdb;
        $today = current_time('Y-m-d H:i:s');

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->subscriptions_table} WHERE provider_key=%s AND status IN ('active','past_due','grace') AND next_billing_at IS NOT NULL AND next_billing_at <= %s",
                $provider_key,
                $today
            ),
            ARRAY_A
        ) ?: [];
    }

    public function get_expiring_manual_subscriptions(): array {
        global $wpdb;
        $today = current_time('Y-m-d');

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->subscriptions_table} WHERE provider_key=%s AND status='active' AND expires_at IS NOT NULL AND DATE(expires_at) >= %s",
                'manual_renewal',
                $today
            ),
            ARRAY_A
        ) ?: [];
    }

    public function get_user_latest_subscription(int $user_id): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->subscriptions_table} WHERE user_id=%d ORDER BY id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );

        return $row ?: null;
    }

    public function create_or_update_from_order(array $payload): int {
        global $wpdb;

        $defaults = [
            'user_id' => 0,
            'tier' => 'free',
            'billing_interval' => 'monthly',
            'provider_key' => 'custom_recurring',
            'status' => 'active',
            'wc_order_id' => null,
            'wc_product_id' => null,
            'amount' => 0,
            'currency' => get_woocommerce_currency(),
            'next_billing_at' => null,
            'expires_at' => null,
            'grace_ends_at' => null,
            'retry_count' => 0,
        ];

        $data = array_merge($defaults, $payload);
        $existing = $this->get_user_latest_subscription((int) $data['user_id']);

        if ($existing && in_array($existing['status'], ['active', 'past_due', 'grace'], true)) {
            $wpdb->update(
                $this->subscriptions_table,
                [
                    'tier' => $data['tier'],
                    'billing_interval' => $data['billing_interval'],
                    'provider_key' => $data['provider_key'],
                    'status' => $data['status'],
                    'wc_order_id' => $data['wc_order_id'],
                    'wc_product_id' => $data['wc_product_id'],
                    'amount' => $data['amount'],
                    'currency' => $data['currency'],
                    'next_billing_at' => $data['next_billing_at'],
                    'expires_at' => $data['expires_at'],
                    'retry_count' => (int) $data['retry_count'],
                    'updated_at' => current_time('mysql'),
                ],
                ['id' => (int) $existing['id']],
                ['%s', '%s', '%s', '%s', '%d', '%d', '%f', '%s', '%s', '%s', '%d', '%s'],
                ['%d']
            );

            return (int) $existing['id'];
        }

        $wpdb->insert(
            $this->subscriptions_table,
            [
                'user_id' => (int) $data['user_id'],
                'tier' => $data['tier'],
                'billing_interval' => $data['billing_interval'],
                'provider_key' => $data['provider_key'],
                'status' => $data['status'],
                'wc_order_id' => $data['wc_order_id'],
                'wc_product_id' => $data['wc_product_id'],
                'amount' => $data['amount'],
                'currency' => $data['currency'],
                'next_billing_at' => $data['next_billing_at'],
                'expires_at' => $data['expires_at'],
                'grace_ends_at' => $data['grace_ends_at'],
                'retry_count' => (int) $data['retry_count'],
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%d', '%f', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );

        return (int) $wpdb->insert_id;
    }

    public function mark_payment_attempt(int $subscription_id, string $status, string $note = '', ?int $order_id = null): void {
        global $wpdb;
        $wpdb->insert(
            $this->billing_history_table,
            [
                'subscription_id' => $subscription_id,
                'wc_order_id' => $order_id,
                'event_type' => 'charge_attempt',
                'status' => $status,
                'note' => $note,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%s']
        );
    }

    public function update_subscription_status(int $subscription_id, string $status, array $extra = []): void {
        global $wpdb;
        $data = array_merge([
            'status' => $status,
            'updated_at' => current_time('mysql'),
        ], $extra);

        $formats = [];
        foreach ($data as $key => $value) {
            if (in_array($key, ['retry_count'], true)) {
                $formats[] = '%d';
            } elseif (in_array($key, ['amount'], true)) {
                $formats[] = '%f';
            } else {
                $formats[] = '%s';
            }
        }

        $wpdb->update($this->subscriptions_table, $data, ['id' => $subscription_id], $formats, ['%d']);
    }

    public function save_payment_method(int $user_id, string $gateway_id, string $token_id, bool $is_default = false): void {
        global $wpdb;
        $wpdb->insert(
            $this->payment_methods_table,
            [
                'user_id' => $user_id,
                'gateway_id' => $gateway_id,
                'token_id' => $token_id,
                'is_default' => $is_default ? 1 : 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%d', '%s', '%s']
        );
    }
}
