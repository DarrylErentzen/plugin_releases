<?php

namespace LifeTrustPlanning\Billing;

class Billing_Manager {
    /** @var array<string, Billing_Provider_Interface> */
    private array $providers = [];

    private Billing_Provider_Interface $active_provider;

    public function __construct() {
        $this->providers = [
            'custom_recurring' => new Custom_Recurring_Provider(),
            'manual_renewal' => new Manual_Renewal_Provider(),
            'stripe_subscription' => new Stripe_Subscription_Provider(),
            'wc_subscriptions' => new WC_Subscriptions_Provider(),
        ];

        $selected = sanitize_key((string) get_option('ltp_billing_provider', 'custom_recurring'));
        $provider = $this->providers[$selected] ?? $this->providers['custom_recurring'];

        if (!$provider->is_available()) {
            $provider = $this->providers['custom_recurring'];
            if (!$provider->is_available()) {
                $provider = $this->providers['manual_renewal'];
            }
        }

        $this->active_provider = $provider;
    }

    public function init(): void {
        $this->active_provider->init();

        add_action('woocommerce_order_status_completed', [$this, 'handle_completed_order'], 20);
        add_action('ltp_process_renewals', [$this, 'process_scheduled_events']);

        if (!wp_next_scheduled('ltp_custom_recurring_tick')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'ltp_custom_recurring_tick');
        }

        if (!wp_next_scheduled('ltp_manual_renewal_tick')) {
            wp_schedule_event(time() + DAY_IN_SECONDS, 'daily', 'ltp_manual_renewal_tick');
        }
    }

    public function handle_completed_order(int $order_id): void {
        $this->active_provider->handle_completed_order($order_id);
    }

    public function process_scheduled_events(): void {
        $this->active_provider->process_scheduled_events();
    }

    public function get_active_provider_key(): string {
        return $this->active_provider->get_key();
    }

    /** @return array<string, string> */
    public function list_available_providers(): array {
        $out = [];
        foreach ($this->providers as $key => $provider) {
            if ($provider->is_available() || in_array($key, ['custom_recurring', 'manual_renewal'], true)) {
                $out[$key] = $provider->get_label();
            }
        }
        return $out;
    }

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool {
        return $this->active_provider->cancel_subscription($subscription_id, $reason);
    }
}
