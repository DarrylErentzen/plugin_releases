<?php

namespace LifeTrustPlanning\Billing;

class Manual_Renewal_Provider implements Billing_Provider_Interface {
    private Billing_Data_Store $data_store;

    public function __construct(?Billing_Data_Store $data_store = null) {
        $this->data_store = $data_store ?: new Billing_Data_Store();
    }

    public function get_key(): string {
        return 'manual_renewal';
    }

    public function get_label(): string {
        return 'Manual Renewal (email reminders + grace + downgrade)';
    }

    public function is_available(): bool {
        return true;
    }

    public function init(): void {
        add_action('ltp_manual_renewal_tick', [$this, 'process_scheduled_events']);
    }

    public function handle_completed_order(int $order_id): void {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $tier = sanitize_key((string) $order->get_meta('_ltp_tier'));
        $interval = sanitize_key((string) $order->get_meta('_ltp_interval'));
        if (!$tier || !$interval) {
            return;
        }

        $expires_at = $this->calculate_expiration_datetime($interval);
        $this->data_store->create_or_update_from_order([
            'user_id' => (int) $order->get_user_id(),
            'tier' => $tier,
            'billing_interval' => $interval,
            'provider_key' => $this->get_key(),
            'status' => 'active',
            'wc_order_id' => $order->get_id(),
            'wc_product_id' => (int) $order->get_meta('_ltp_product_id'),
            'amount' => (float) $order->get_total(),
            'currency' => (string) $order->get_currency(),
            'expires_at' => $expires_at,
            'next_billing_at' => $expires_at,
        ]);

        do_action('ltp_membership_assign_tier', (int) $order->get_user_id(), $tier, ['source' => 'manual_renewal_order', 'order_id' => $order_id]);
    }

    public function process_scheduled_events(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_subscriptions';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE provider_key=%s AND status IN ('active','grace') AND expires_at IS NOT NULL",
                $this->get_key()
            ),
            ARRAY_A
        ) ?: [];

        $grace_days = max(0, (int) get_option('ltp_manual_grace_days', 5));

        foreach ($rows as $sub) {
            $user = get_user_by('id', (int) $sub['user_id']);
            if (!$user || !$user->user_email) {
                continue;
            }

            $expires_ts = strtotime((string) $sub['expires_at']);
            if (!$expires_ts) {
                continue;
            }

            $days_left = (int) floor(($expires_ts - current_time('timestamp')) / DAY_IN_SECONDS);

            if (in_array($days_left, [30, 7, 1], true)) {
                $checkout_link = $this->build_renewal_checkout_link((int) $sub['wc_product_id']);
                wp_mail(
                    $user->user_email,
                    'LifeTrust renewal reminder',
                    sprintf('Your plan expires in %d day(s). Renew here: %s', $days_left, $checkout_link)
                );
            }

            if ($days_left < 0 && 'active' === $sub['status']) {
                $grace_end = gmdate('Y-m-d H:i:s', strtotime('+' . $grace_days . ' day', $expires_ts));
                $this->data_store->update_subscription_status((int) $sub['id'], 'grace', [
                    'grace_ends_at' => $grace_end,
                ]);
            }

            if ('grace' === $sub['status'] && !empty($sub['grace_ends_at']) && strtotime((string) $sub['grace_ends_at']) <= current_time('timestamp')) {
                $this->data_store->update_subscription_status((int) $sub['id'], 'expired', [
                    'cancelled_at' => current_time('mysql'),
                ]);
                do_action('ltp_membership_downgrade_to_free', (int) $sub['user_id'], ['source' => 'manual_renewal_expired']);
            }
        }
    }

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool {
        $this->data_store->update_subscription_status($subscription_id, 'cancelled', [
            'cancelled_at' => current_time('mysql'),
        ]);
        return true;
    }

    private function calculate_expiration_datetime(string $interval): string {
        $base = current_time('timestamp');
        $map = [
            'monthly' => '+1 month',
            'quarterly' => '+3 month',
            'yearly' => '+1 year',
        ];

        return gmdate('Y-m-d H:i:s', strtotime($map[$interval] ?? '+1 month', $base));
    }

    private function build_renewal_checkout_link(int $product_id): string {
        if ($product_id && function_exists('wc_get_checkout_url')) {
            return add_query_arg('add-to-cart', $product_id, wc_get_checkout_url());
        }

        return home_url('/my-account/');
    }
}
