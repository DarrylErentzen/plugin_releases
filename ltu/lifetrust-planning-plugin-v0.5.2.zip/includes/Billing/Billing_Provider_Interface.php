<?php

namespace LifeTrustPlanning\Billing;

interface Billing_Provider_Interface {
    public function get_key(): string;

    public function get_label(): string;

    public function is_available(): bool;

    public function init(): void;

    public function handle_completed_order(int $order_id): void;

    public function process_scheduled_events(): void;

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool;
}
