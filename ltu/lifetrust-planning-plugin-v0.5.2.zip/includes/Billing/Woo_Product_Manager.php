<?php

namespace LifeTrustPlanning\Billing;

class Woo_Product_Manager {
    private const TIERS = ['essential', 'premium', 'ultimate'];
    private const INTERVALS = ['monthly', 'quarterly', 'yearly'];

    public static function init(): void {
        add_action('init', [self::class, 'maybe_create_products']);
        add_action('woocommerce_checkout_create_order_line_item', [self::class, 'attach_tier_metadata_to_order_item'], 10, 4);
    }

    public static function maybe_create_products(): void {
        if (!function_exists('wc_get_product') || !current_user_can('manage_options')) {
            return;
        }

        if (!get_option('ltp_autocreate_wc_products', 1)) {
            return;
        }

        if (!get_option('ltp_wc_products_initialized', 0)) {
            self::create_or_update_products(true);
            update_option('ltp_wc_products_initialized', 1);
        }
    }

    public static function create_or_update_products(bool $force_update = false): array {
        if (!function_exists('wc_get_product')) {
            return [];
        }

        $map = get_option('ltp_wc_product_map', []);
        if (!is_array($map)) {
            $map = [];
        }

        foreach (self::TIERS as $tier) {
            foreach (self::INTERVALS as $interval) {
                $pricing = self::price_for($tier, $interval);
                $name = ucfirst($tier) . ' - ' . ucfirst($interval);
                $product_id = isset($map[$tier][$interval]) ? (int) $map[$tier][$interval] : 0;

                $product = $product_id ? wc_get_product($product_id) : false;
                if (!$product) {
                    $product = new \WC_Product_Simple();
                    $product->set_name($name);
                    $product->set_status('publish');
                    $product->set_catalog_visibility('visible');
                    $product->set_virtual(true);
                }

                if ($force_update || !$product_id) {
                    $product->set_regular_price((string) $pricing['total']);
                    $product->set_price((string) $pricing['total']);
                }

                $new_id = $product->save();
                update_post_meta($new_id, '_ltp_tier', $tier);
                update_post_meta($new_id, '_ltp_interval', $interval);
                update_post_meta($new_id, '_ltp_base_monthly_price', (string) $pricing['base_monthly']);
                update_post_meta($new_id, '_ltp_discount_percentage', (string) $pricing['discount']);
                update_post_meta($new_id, '_ltp_is_subscription_scaffold', 'yes');

                $map[$tier][$interval] = $new_id;
            }
        }

        update_option('ltp_wc_product_map', $map);
        return $map;
    }

    public static function attach_tier_metadata_to_order_item($item, $cart_item_key, $values, $order): void {
        $product = $item->get_product();
        if (!$product) {
            return;
        }

        $tier = get_post_meta($product->get_id(), '_ltp_tier', true);
        $interval = get_post_meta($product->get_id(), '_ltp_interval', true);
        if (!$tier || !$interval) {
            return;
        }

        $order->update_meta_data('_ltp_tier', $tier);
        $order->update_meta_data('_ltp_interval', $interval);
        $order->update_meta_data('_ltp_product_id', $product->get_id());
        $order->save();
    }

    public static function price_for(string $tier, string $interval): array {
        $base_prices = get_option('ltp_base_monthly_prices', [
            'essential' => 30,
            'premium' => 60,
            'ultimate' => 150,
        ]);

        $quarterly_discount = ((float) get_option('ltp_quarterly_discount_percentage', 15)) / 100;
        $yearly_discount = ((float) get_option('ltp_yearly_discount_percentage', 30)) / 100;

        $base = isset($base_prices[$tier]) ? (float) $base_prices[$tier] : 0;

        switch ($interval) {
            case 'quarterly':
                $monthly = $base * (1 - $quarterly_discount);
                return ['base_monthly' => $base, 'discount' => $quarterly_discount * 100, 'total' => round($monthly * 3, 2)];
            case 'yearly':
                $monthly = $base * (1 - $yearly_discount);
                return ['base_monthly' => $base, 'discount' => $yearly_discount * 100, 'total' => round($monthly * 12, 2)];
            case 'monthly':
            default:
                return ['base_monthly' => $base, 'discount' => 0, 'total' => round($base, 2)];
        }
    }
}
