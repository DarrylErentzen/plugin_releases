<?php

namespace LifeTrustPlanning\Billing;

/**
 * @deprecated Use Billing_Manager directly.
 */
class Billing_Engine {
    private Billing_Manager $manager;

    public function __construct() {
        $this->manager = new Billing_Manager();
    }

    public function init(): void {
        $this->manager->init();
    }

    public function process_due_renewals(): void {
        $this->manager->process_scheduled_events();
    }

    public function handle_completed_order(int $order_id): void {
        $this->manager->handle_completed_order($order_id);
    }
}
