<?php

namespace LifeTrustPlanning\Billing;

class Stripe_Subscription_Provider implements Billing_Provider_Interface {
    public function get_key(): string {
        return 'stripe_subscription';
    }

    public function get_label(): string {
        return 'Stripe Subscription (legacy compatibility mode)';
    }

    public function is_available(): bool {
        return class_exists('WC_Gateway_Stripe') || class_exists('WC_Stripe');
    }

    public function init(): void {
        // Intentionally does not implement direct Stripe API flows.
        // Payment handling should remain in WooCommerce gateways.
        add_action('woocommerce_api_ltp_stripe_subscription_webhook', [$this, 'handle_webhook']);
    }

    public function handle_completed_order(int $order_id): void {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $tier = sanitize_key((string) $order->get_meta('_ltp_tier'));
        if (!$tier) {
            return;
        }

        do_action('ltp_membership_assign_tier', (int) $order->get_user_id(), $tier, ['source' => 'stripe_wc_order', 'order_id' => $order_id]);
    }

    public function process_scheduled_events(): void {
        // No-op: WooCommerce handles payment lifecycle for this compatibility provider.
    }

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool {
        do_action('ltp_stripe_subscription_cancel_request', $subscription_id, $reason);
        return true;
    }

    public function handle_webhook(): void {
        do_action('ltp_stripe_subscription_webhook_received', $_REQUEST);
        status_header(200);
        exit;
    }
}
