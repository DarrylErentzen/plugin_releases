<?php

namespace LifeTrustPlanning\Billing;

class WC_Subscriptions_Provider implements Billing_Provider_Interface {
    public function get_key(): string {
        return 'wc_subscriptions';
    }

    public function get_label(): string {
        return 'WooCommerce Subscriptions (migration target)';
    }

    public function is_available(): bool {
        return function_exists('wcs_get_subscriptions') || class_exists('WC_Subscriptions');
    }

    public function init(): void {
        // Reserved for future migration.
    }

    public function handle_completed_order(int $order_id): void {
        do_action('ltp_wc_subscriptions_order_completed', $order_id);
    }

    public function process_scheduled_events(): void {
        // WooCommerce Subscriptions handles its own schedule.
    }

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool {
        do_action('ltp_wc_subscriptions_cancel_request', $subscription_id, $reason);
        return true;
    }
}
