<?php

namespace LifeTrustPlanning\Billing;

use LifeTrustPlanning\Core\Tier_Access;
use LifeTrustPlanning\Marketing\Marketing_Content;
use LifeTrustPlanning\Marketing\Marketing_Renderer;

class Dashboard_CTA {
    public static function init(): void {
        add_action('woocommerce_account_dashboard', [self::class, 'render']);
    }

    public static function render(): void {
        if (!is_user_logged_in()) {
            return;
        }

        $current_tier = Tier_Access::get_user_tier(get_current_user_id());
        $content = Marketing_Content::get();
        $cta_html = (string) get_option('ltp_dashboard_cta_content', '<p>Choose the plan that fits your planning journey and unlock the right level of support.</p>');
        $interval = sanitize_key((string) ($content['pricing_display']['default_interval'] ?? 'monthly'));

        echo '<section class="ltp-dashboard-cta" style="margin-top:2rem;">';
        echo '<h3>LifeTrust Plan & Upgrades</h3>';
        echo wp_kses_post(wpautop($cta_html));
        echo '<p><strong>Current Tier:</strong> ' . esc_html(ucfirst($current_tier)) . '</p>';

        echo '<div class="ltp-cta-view-switch" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;">';
        echo '<button type="button" class="button button-primary ltp-view-btn" data-ltp-view="table" aria-pressed="true">Table View</button>';
        echo '<button type="button" class="button ltp-view-btn" data-ltp-view="cards" aria-pressed="false">Card View</button>';
        echo '</div>';

        echo '<div class="ltp-dashboard-view" data-ltp-view-panel="table">';
        echo Marketing_Renderer::render_pricing_table(['interval' => $interval]); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo '</div>';

        echo '<div class="ltp-dashboard-view" data-ltp-view-panel="cards" style="display:none;">';
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;">';
        foreach (['free', 'essential', 'premium', 'ultimate'] as $tier) {
            echo Marketing_Renderer::render_tier_card($tier, $interval); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
        echo '</div>';
        echo '</div>';

        echo '<script>
            document.addEventListener("click", function(e){
                var btn = e.target.closest(".ltp-view-btn");
                if(!btn){ return; }
                var root = btn.closest(".ltp-dashboard-cta");
                if(!root){ return; }
                var view = btn.getAttribute("data-ltp-view");
                root.querySelectorAll(".ltp-view-btn").forEach(function(b){
                    b.classList.toggle("button-primary", b === btn);
                    b.setAttribute("aria-pressed", b === btn ? "true" : "false");
                });
                root.querySelectorAll("[data-ltp-view-panel]").forEach(function(panel){
                    panel.style.display = panel.getAttribute("data-ltp-view-panel") === view ? "" : "none";
                });
            });
        </script>';

        echo '</section>';
    }
}
