<?php

namespace LifeTrustPlanning\Billing;

use LifeTrustPlanning\Core\Tier_Access;

class Custom_Recurring_Provider implements Billing_Provider_Interface {
    private Billing_Data_Store $data_store;

    public function __construct(?Billing_Data_Store $data_store = null) {
        $this->data_store = $data_store ?: new Billing_Data_Store();
    }

    public function get_key(): string {
        return 'custom_recurring';
    }

    public function get_label(): string {
        return 'Custom Recurring (Woo payment methods + WP-Cron)';
    }

    public function is_available(): bool {
        return function_exists('wc_get_order');
    }

    public function init(): void {
        add_action('ltp_custom_recurring_tick', [$this, 'process_scheduled_events']);
        add_action('ltp_send_upcoming_charge_email', [$this, 'send_upcoming_charge_email'], 10, 1);
        add_action('ltp_send_failed_payment_email', [$this, 'send_failed_payment_email'], 10, 1);
        add_action('ltp_send_success_payment_email', [$this, 'send_success_payment_email'], 10, 1);
    }

    public function handle_completed_order(int $order_id): void {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $tier = sanitize_key((string) $order->get_meta('_ltp_tier'));
        $interval = sanitize_key((string) $order->get_meta('_ltp_interval'));
        if (!$tier || !$interval) {
            return;
        }

        $next = $this->calculate_next_billing_datetime($interval);
        $sub_id = $this->data_store->create_or_update_from_order([
            'user_id' => (int) $order->get_user_id(),
            'tier' => $tier,
            'billing_interval' => $interval,
            'provider_key' => $this->get_key(),
            'status' => 'active',
            'wc_order_id' => $order->get_id(),
            'wc_product_id' => (int) $order->get_meta('_ltp_product_id'),
            'amount' => (float) $order->get_total(),
            'currency' => (string) $order->get_currency(),
            'next_billing_at' => $next,
            'retry_count' => 0,
        ]);

        do_action('ltp_membership_assign_tier', (int) $order->get_user_id(), $tier, ['source' => 'custom_recurring_order', 'order_id' => $order_id]);
        $this->data_store->mark_payment_attempt($sub_id, 'success', 'Initial order complete', $order_id);
    }

    public function process_scheduled_events(): void {
        $subs = $this->data_store->get_due_subscriptions($this->get_key());
        $max_retries = max(0, (int) get_option('ltp_custom_recurring_retry_limit', 3));
        $grace_days = max(0, (int) get_option('ltp_custom_recurring_grace_days', 7));

        foreach ($subs as $sub) {
            $user_id = (int) $sub['user_id'];
            if (!$user_id) {
                continue;
            }

            $this->send_upcoming_charge_email($user_id);

            $renewal_order_id = $this->create_renewal_order_from_subscription($sub);
            $charge_ok = $renewal_order_id > 0;

            if ($charge_ok) {
                $next = $this->calculate_next_billing_datetime((string) $sub['billing_interval']);
                $this->data_store->update_subscription_status((int) $sub['id'], 'active', [
                    'next_billing_at' => $next,
                    'retry_count' => 0,
                ]);
                $this->data_store->mark_payment_attempt((int) $sub['id'], 'success', 'Renewal order created.', $renewal_order_id);
                $this->send_success_payment_email($user_id);
                continue;
            }

            $retry_count = (int) $sub['retry_count'] + 1;
            if ($retry_count <= $max_retries) {
                $retry_date = gmdate('Y-m-d H:i:s', strtotime('+' . $retry_count . ' day', current_time('timestamp', true)));
                $this->data_store->update_subscription_status((int) $sub['id'], 'past_due', [
                    'retry_count' => $retry_count,
                    'next_billing_at' => $retry_date,
                ]);
                $this->data_store->mark_payment_attempt((int) $sub['id'], 'failed', 'Charge failed. Retry scheduled.');
                $this->send_failed_payment_email($user_id);
                continue;
            }

            $grace_ends = gmdate('Y-m-d H:i:s', strtotime('+' . $grace_days . ' day', current_time('timestamp', true)));
            $this->data_store->update_subscription_status((int) $sub['id'], 'grace', [
                'grace_ends_at' => $grace_ends,
                'next_billing_at' => $grace_ends,
            ]);
            $this->data_store->mark_payment_attempt((int) $sub['id'], 'failed', 'Moved to grace period.');
            $this->send_failed_payment_email($user_id);

            if ($grace_days === 0) {
                do_action('ltp_membership_downgrade_to_free', $user_id, ['source' => 'custom_recurring_failure']);
            }
        }

        $this->downgrade_expired_grace_subscriptions();
    }

    public function cancel_subscription(int $subscription_id, string $reason = ''): bool {
        $this->data_store->update_subscription_status($subscription_id, 'cancelled', [
            'cancelled_at' => current_time('mysql'),
        ]);
        return true;
    }

    private function create_renewal_order_from_subscription(array $subscription): int {
        if (!function_exists('wc_create_order')) {
            return 0;
        }

        $user_id = (int) $subscription['user_id'];
        $product_id = (int) $subscription['wc_product_id'];
        if (!$user_id || !$product_id) {
            return 0;
        }

        $product = wc_get_product($product_id);
        if (!$product) {
            return 0;
        }

        try {
            $order = wc_create_order(['customer_id' => $user_id]);
            $order->add_product($product, 1);
            $order->calculate_totals();
            $order->update_meta_data('_ltp_tier', (string) $subscription['tier']);
            $order->update_meta_data('_ltp_interval', (string) $subscription['billing_interval']);
            $order->update_meta_data('_ltp_product_id', $product_id);
            $order->update_status('pending', 'Auto-generated renewal order');
            $order->save();

            do_action('ltp_custom_recurring_charge_attempt', $subscription, $order);

            // If a gateway integration captures payment asynchronously, it can mark the order completed.
            // We only require order creation here to avoid bypassing Woo gateway ownership.
            return (int) $order->get_id();
        } catch (\Throwable $e) {
            return 0;
        }
    }

    private function calculate_next_billing_datetime(string $interval): string {
        $base = current_time('timestamp');
        $map = [
            'monthly' => '+1 month',
            'quarterly' => '+3 month',
            'yearly' => '+1 year',
        ];
        $rule = $map[$interval] ?? '+1 month';

        return gmdate('Y-m-d H:i:s', strtotime($rule, $base));
    }

    private function downgrade_expired_grace_subscriptions(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'ltp_subscriptions';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE provider_key=%s AND status='grace' AND grace_ends_at IS NOT NULL AND grace_ends_at <= %s",
                $this->get_key(),
                current_time('mysql')
            ),
            ARRAY_A
        ) ?: [];

        foreach ($rows as $row) {
            $this->data_store->update_subscription_status((int) $row['id'], 'cancelled', [
                'cancelled_at' => current_time('mysql'),
            ]);
            do_action('ltp_membership_downgrade_to_free', (int) $row['user_id'], ['source' => 'grace_expired']);
        }
    }

    public function send_upcoming_charge_email(int $user_id): void {
        $user = get_user_by('id', $user_id);
        if (!$user || !$user->user_email) {
            return;
        }

        wp_mail($user->user_email, 'LifeTrust upcoming renewal charge', 'Your LifeTrust renewal charge will be attempted shortly.');
    }

    public function send_failed_payment_email(int $user_id): void {
        $user = get_user_by('id', $user_id);
        if (!$user || !$user->user_email) {
            return;
        }

        wp_mail($user->user_email, 'LifeTrust payment issue', 'We were unable to process your renewal payment. Please update your payment method in WooCommerce My Account.');
    }

    public function send_success_payment_email(int $user_id): void {
        $user = get_user_by('id', $user_id);
        if (!$user || !$user->user_email) {
            return;
        }

        wp_mail($user->user_email, 'LifeTrust renewal successful', 'Your renewal was processed successfully. Thank you for continuing with LifeTrust Planning.');
    }
}
