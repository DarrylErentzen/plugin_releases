## PRE-RELEASE CHECKLIST (MANDATORY)

### Build Requirements
- [ ] Version incremented appropriately
- [ ] All dependencies included in vendor/
- [ ] NO npm/composer install required
- [ ] NO build steps required
- [ ] Plugin works: Upload → Activate → Configure → Done

### File Size (CRITICAL)
- [ ] Final ZIP size is under 5MB
- [ ] No dev dependencies included
- [ ] No test files included
- [ ] No unnecessary docs from dependencies

### Auto-Update System
- [ ] Version updated in all files
- [ ] info.json updated with new version
- [ ] Changelog updated
- [ ] Files pushed to GitHub main branch
- [ ] URLs verified (200 OK response)

### Self-Contained (CRITICAL)
- [ ] vendor/ directory included
- [ ] All assets pre-built
- [ ] No package.json at root
- [ ] No composer.json at root
- [ ] No build scripts at root

### WordPress Compatibility
- [ ] Tested on standard shared hosting
- [ ] No sudo access required
- [ ] No command line access required
