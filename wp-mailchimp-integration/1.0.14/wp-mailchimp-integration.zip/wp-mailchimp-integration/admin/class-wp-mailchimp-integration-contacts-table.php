<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Contacts_Table extends WP_List_Table {

    private $audience_id;

    public function __construct( $audience_id ) {
        parent::__construct( [
            'singular' => 'Contact',
            'plural'   => 'Contacts',
            'ajax'     => false
        ] );
        $this->audience_id = $audience_id;
    }

    public function get_columns() {
        return [
            'cb'   => '<input type="checkbox" />',
            'email_address' => 'Email',
            'status' => 'Status',
            'timestamp_opt' => 'Subscribed',
        ];
    }

    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $api = Wp_Mailchimp_Api::get_instance();
        $this->items = $api->get_contacts( $this->audience_id );
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'email_address':
                return $item->email_address;
            case 'status':
                return $item->status;
            case 'timestamp_opt':
                return $item->timestamp_opt;
            default:
                return print_r( $item, true );
        }
    }

    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="contact[]" value="%s" />', $item->id
        );
    }
}
