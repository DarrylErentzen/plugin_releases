<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Logs_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => 'Log',
            'plural'   => 'Logs',
            'ajax'     => false
        ] );
    }

    public function get_columns() {
        return [
            'type' => 'Type',
            'message' => 'Message',
            'timestamp' => 'Timestamp',
        ];
    }

    public function prepare_items() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_logs';

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->items = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id DESC", ARRAY_A );
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'type':
                return $item['type'];
            case 'message':
                return $item['message'];
            case 'timestamp':
                return $item['timestamp'];
            default:
                return print_r( $item, true );
        }
    }
}
