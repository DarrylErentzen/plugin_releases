<?php

class Wp_Mailchimp_Logger {

    public static function log( $type, $message ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_logs';

        $wpdb->insert(
            $table_name,
            array(
                'type' => $type,
                'message' => $message,
                'timestamp' => current_time( 'mysql' ),
            )
        );
    }
}
