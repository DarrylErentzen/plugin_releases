<?php

class Wp_Mailchimp_Integration_Public {

    private $plugin_name;
    private $version;
    private $option_name = 'wpmi_options';

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        add_action( 'init', array( $this, 'register_shortcodes' ) );
    }

    public function register_shortcodes() {
        add_shortcode( 'mailchimp_signup_form', array( $this, 'render_signup_form' ) );
    }

    public function render_signup_form() {
        $message = '';
        if ( isset( $_POST['wpmi_submit'] ) ) {
            $result = $this->handle_form_submission();
            if ( is_wp_error( $result ) ) {
                $message = '<p style="color: red;">' . $result->get_error_message() . '</p>';
            } else {
                $message = '<p style="color: green;">' . $result . '</p>';
            }
        }

        ob_start();
        include_once( 'partials/wp-mailchimp-integration-public-display.php' );
        $form = ob_get_clean();

        return $message . $form;
    }

    private function handle_form_submission() {
        if ( ! isset( $_POST['wpmi_nonce'] ) || ! wp_verify_nonce( $_POST['wpmi_nonce'], 'wpmi_signup_form' ) ) {
            return new WP_Error( 'security', 'Invalid nonce.' );
        }

        $email = isset( $_POST['wpmi_email'] ) ? sanitize_email( $_POST['wpmi_email'] ) : '';
        $fname = isset( $_POST['wpmi_fname'] ) ? sanitize_text_field( $_POST['wpmi_fname'] ) : '';
        $lname = isset( $_POST['wpmi_lname'] ) ? sanitize_text_field( $_POST['wpmi_lname'] ) : '';

        if ( ! is_email( $email ) ) {
            return new WP_Error( 'validation', 'Invalid email address.' );
        }

        return $this->subscribe_user( $email, $fname, $lname );
    }

    private function subscribe_user( $email, $fname, $lname ) {
        $options = get_option( $this->option_name );
        $audience_id = isset( $options['audience_id'] ) ? $options['audience_id'] : '';

        if ( empty( $audience_id ) ) {
            return new WP_Error( 'config', 'Plugin is not configured. Missing Audience ID.' );
        }

        $api = Wp_Mailchimp_Api::get_instance();

        if ( $api->subscribe_user( $audience_id, $email, $fname, $lname ) ) {
            return 'Successfully subscribed!';
        } else {
            return new WP_Error( 'api_error', 'Error: ' . $api->get_error_message() );
        }
    }
}