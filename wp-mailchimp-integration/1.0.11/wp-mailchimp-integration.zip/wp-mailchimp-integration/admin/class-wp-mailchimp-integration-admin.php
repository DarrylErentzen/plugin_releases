<?php

require_once plugin_dir_path( __FILE__ ) . 'class-wp-mailchimp-integration-audiences-table.php';
require_once plugin_dir_path( __FILE__ ) . 'class-wp-mailchimp-integration-contacts-table.php';
require_once plugin_dir_path( __FILE__ ) . 'class-wp-mailchimp-integration-automations-table.php';
require_once plugin_dir_path( __FILE__ ) . 'class-wp-mailchimp-integration-logs-table.php';
require_once plugin_dir_path( __FILE__ ) . 'wizard/class-wp-mailchimp-integration-wizard.php';

class Wp_Mailchimp_Integration_Admin {

    private $plugin_name;
    private $version;
    private $option_name = 'wpmi_options';
    private $wizard;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->wizard = new Wp_Mailchimp_Integration_Wizard( $this->plugin_name, $this->version );

        add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'options_update' ) );
        add_action( 'admin_init', array( $this, 'handle_add_automation' ) );
        add_action( 'admin_init', array( $this, 'handle_delete_automation' ) );
        add_action( 'admin_init', array( $this, 'handle_edit_automation' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_ajax_wpmi_test_connection', array( $this, 'test_api_connection' ) );
        add_action( 'wp_ajax_wpmi_bulk_sync', array( $this, 'bulk_sync_users' ) );
        add_action( 'wp_ajax_wpmi_enable_two_way_sync', array( $this, 'enable_two_way_sync' ) );
        add_action( 'save_post', array( $this, 'schedule_email' ) );
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post', array( $this, 'save_meta_box_data' ) );
        add_action( 'admin_footer', array( $this->wizard, 'render_wizard' ) );

    }

    public function handle_edit_automation() {
        if ( isset( $_POST['submit'] ) && $_POST['submit'] === 'Update Automation' ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'mailchimp_automations';

            $id = absint( $_POST['automation_id'] );
            $name = sanitize_text_field( $_POST['name'] );
            $trigger = sanitize_text_field( $_POST['trigger'] );
            $action = sanitize_text_field( $_POST['action'] );
            $audience_id = sanitize_text_field( $_POST['audience_id'] );

            $wpdb->update(
                $table_name,
                array(
                    'name' => $name,
                    'trigger_name' => $trigger,
                    'action_name' => $action,
                    'audience_id' => $audience_id,
                ),
                array( 'id' => $id )
            );

            wp_redirect( admin_url( 'admin.php?page=' . $this->plugin_name . '-automations' ) );
            exit;
        }
    }

    public function handle_delete_automation() {
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['automation'] ) ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'mailchimp_automations';
            $id = absint( $_GET['automation'] );
            $wpdb->delete( $table_name, array( 'id' => $id ) );
            wp_redirect( admin_url( 'admin.php?page=' . $this->plugin_name . '-automations' ) );
            exit;
        }
    }

    public function schedule_email( $post_id ) {
        if ( get_post_type( $post_id ) !== 'mailchimp-template' ) {
            return;
        }

        $send_now = get_post_meta( $post_id, '_wpmi_send_now', true );
        $schedule_date = get_post_meta( $post_id, '_wpmi_schedule_date', true );

        if ( $send_now ) {
            $this->send_campaign( $post_id );
        } elseif ( ! empty( $schedule_date ) ) {
            $timestamp = strtotime( $schedule_date );
            wp_schedule_single_event( $timestamp, 'wpmi_send_scheduled_campaign', array( $post_id ) );
        }
    }

    public function send_campaign( $post_id ) {
        Wp_Mailchimp_Logger::log( 'email', 'Sending campaign for post: ' . $post_id );
        $post = get_post( $post_id );
        $audience_id = get_post_meta( $post_id, '_wpmi_audience_id', true );

        if ( empty( $audience_id ) ) {
            Wp_Mailchimp_Logger::log( 'error', 'No audience selected for post: ' . $post_id );
            return;
        }

        $api = Wp_Mailchimp_Api::get_instance();
        $campaign_id = $api->create_campaign( $post->post_title, $post->post_title, $audience_id );

        if ( $campaign_id ) {
            Wp_Mailchimp_Logger::log( 'email', 'Created campaign with id: ' . $campaign_id );
            $content = apply_filters( 'the_content', $post->post_content );
            if ( $api->set_campaign_content( $campaign_id, $content ) ) {
                Wp_Mailchimp_Logger::log( 'email', 'Set campaign content for campaign id: ' . $campaign_id );
                if ( $api->send_campaign( $campaign_id ) ) {
                    Wp_Mailchimp_Logger::log( 'email', 'Sent campaign with id: ' . $campaign_id );
                } else {
                    Wp_Mailchimp_Logger::log( 'error', 'Failed to send campaign with id: ' . $campaign_id );
                }
            } else {
                Wp_Mailchimp_Logger::log( 'error', 'Failed to set campaign content for campaign id: ' . $campaign_id );
            }
        } else {
            Wp_Mailchimp_Logger::log( 'error', 'Failed to create campaign for post: ' . $post_id );
        }
    }

    public function add_meta_boxes() {
        add_meta_box(
            'wp-mailchimp-integration-schedule',
            'Schedule',
            array( $this, 'render_schedule_meta_box' ),
            'mailchimp-template',
            'side',
            'high'
        );
        add_meta_box(
            'wp-mailchimp-integration-audience',
            'Audience',
            array( $this, 'render_audience_meta_box' ),
            'mailchimp-template',
            'side',
            'high'
        );
    }

    public function render_audience_meta_box( $post ) {
        wp_nonce_field( 'wp_mailchimp_integration_audience', 'wp_mailchimp_integration_audience_nonce' );

        $selected_audience = get_post_meta( $post->ID, '_wpmi_audience_id', true );
        
        $api = Wp_Mailchimp_Api::get_instance();
        $audiences = $api->get_audiences();
        ?>
        <p>
            <label for="wpmi_audience_id">Select an audience</label>
            <select name="wpmi_audience_id" id="wpmi_audience_id" style="width: 100%;">
                <option value="">Select an audience</option>
                <?php foreach ( $audiences as $audience ) : ?>
                    <option value="<?php echo $audience->id; ?>" <?php selected( $selected_audience, $audience->id ); ?>><?php echo $audience->name; ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    public function save_meta_box_data( $post_id ) {
        if ( ! isset( $_POST['wp_mailchimp_integration_schedule_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['wp_mailchimp_integration_schedule_nonce'], 'wp_mailchimp_integration_schedule' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        if ( isset( $_POST['wpmi_send_now'] ) ) {
            update_post_meta( $post_id, '_wpmi_send_now', 1 );
        } else {
            update_post_meta( $post_id, '_wpmi_send_now', 0 );
        }

        if ( isset( $_POST['wpmi_schedule_date'] ) ) {
            update_post_meta( $post_id, '_wpmi_schedule_date', sanitize_text_field( $_POST['wpmi_schedule_date'] ) );
        }

        if ( isset( $_POST['wp_mailchimp_integration_audience_nonce'] ) && wp_verify_nonce( $_POST['wp_mailchimp_integration_audience_nonce'], 'wp_mailchimp_integration_audience' ) ) {
            if ( isset( $_POST['wpmi_audience_id'] ) ) {
                update_post_meta( $post_id, '_wpmi_audience_id', sanitize_text_field( $_POST['wpmi_audience_id'] ) );
            }
        }
    }

    public function handle_add_automation() {
        if ( isset( $_POST['submit'] ) && $_POST['submit'] === 'Add Automation' ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'mailchimp_automations';

            $name = sanitize_text_field( $_POST['name'] );
            $trigger = sanitize_text_field( $_POST['trigger'] );
            $action = sanitize_text_field( $_POST['action'] );
            $audience_id = sanitize_text_field( $_POST['audience_id'] );

            $wpdb->insert(
                $table_name,
                array(
                    'name' => $name,
                    'trigger_name' => $trigger,
                    'action_name' => $action,
                    'audience_id' => $audience_id,
                )
            );

            wp_redirect( admin_url( 'admin.php?page=' . $this->plugin_name . '-automations' ) );
            exit;
        }
    }

    public function enqueue_scripts( $hook ) {
        if ( 'toplevel_page_' . $this->plugin_name !== $hook ) {
            return;
        }
        $this->wizard->enqueue_styles();
        $this->wizard->enqueue_scripts();
        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-mailchimp-integration-admin.js', array( 'jquery' ), $this->version, false );
        wp_localize_script(
            $this->plugin_name,
            'wpmi_ajax',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'wpmi_test_connection' ),
                'bulk_sync_nonce' => wp_create_nonce( 'wpmi_bulk_sync' ),
                'two_way_sync_nonce' => wp_create_nonce( 'wpmi_enable_two_way_sync' ),
            )
        );
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'MailChimp Integration',
            'MailChimp Integration',
            'manage_options',
            $this->plugin_name,
            array( $this, 'display_plugin_setup_page' ),
            'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1NzYgNTEyIj48cGF0aCBmaWxsPSJibHVlIiBkPSJNNTc2IDMyMC4xYzAgMTAuNC04LjQgMTguOC0xOC44IDE4LjhINDY0LjNjLTExLjggMC0yMS40LTkuNi0yMS40LTIxLjRWMjU0LjNjMC0xMS44IDkuNi0yMS40IDIxLjQtMjEuNEg1NTRjMTEuOCAwIDIxLjQgOS42IDIxLjQgMjEuNHY2NS44em0tMTExLTIwOS41YzAtMTAuNC04LjQtMTguOC0xOC44LTE4LjhIMzU0LjhjLTExLjggMC0yMS40LTkuNi0yMS40LTIxLjRWOUMzMzMuNCA0LjMgMzI5LjEgMCAzMjMuOCAwSDI1Mi4yYy01LjMgMC05LjYgNC4zLTkuNiA5LjZ2MjAuNGMwIDcuMS01LjcgMTIuOC0xMi44IDEyLjhIMjAuNEM5LjEgNDIuNyAwIDUxLjggMCA2My4xdjE5Mi4xYzAgMTAuNCA4LjQgMTguOCAxOC44IDE4LjhIMTIyYzExLjggMCAyMS40IDkuNiAyMS40IDIxLjR2NjIuNGMwIDExLjgtOS42IDIxLjQtMjEuNC0yMS40SDMwLjhjLTExLjggMC0yMS40LTkuNi0yMS40LTIxLjRWMzU0YzAtMTEuOCA5LjYtMjEuNCAyMS40LTIxLjRIMTczYzExLjggMCAyMS40IDkuNiAyMS40IDIxLjR2NDAuM2MwIDcuMSA1LjcgMTIuOCAxMi44IDEyLjhIMjEyYzExLjggMCAyMS40LTkuNiAyMS40LTIxLjR2LTQ2YzAtMTEuOC05LjYtMjEuNC0yMS40LTIxLjRIMTkwLjdjLTExLjggMC0yMS40LTkuNi0yMS40LTIxLjRWMjU0LjNjMC0xMS44IDkuNi0yMS40IDIxLjQtMjEuNGgxMTEuN2MxMC40IDAgMTguOC04LjQgMTguOC0xOC44VjYzLjFjMC0xMC40LTguNC0xOC44LTE4LjgtMTguOEgyMjkuOGMtMTEuOCAwLTIxLjQtOS42LTIxLjQtMjEuNFY5LjZjMC01LjMgNC4zLTkuNiA5LjYtOS42aDQyLjdjMTEuOCAwIDIxLjQgOS42IDIxLjQgMjEuNHY0MC42YzAgMTEuOCA5LjYgMjEuNCAyMS40IDIxLjRoOTMuMWMxMS44IDAgMjEuNCA5LjYgMjEuNCAyMS40djIwOC41eiIvPjwvc3ZnPg=='
        );

        add_submenu_page(
            $this->plugin_name,
            'Audiences',
            'Audiences',
            'manage_options',
            $this->plugin_name . '-audiences',
            array( $this, 'display_audiences_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Contacts',
            'Contacts',
            'manage_options',
            $this->plugin_name . '-contacts',
            array( $this, 'display_contacts_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Automations',
            'Automations',
            'manage_options',
            $this->plugin_name . '-automations',
            array( $this, 'display_automations_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Events',
            'Events',
            'manage_options',
            $this->plugin_name . '-events',
            array( $this, 'display_events_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Debug',
            'Debug',
            'manage_options',
            $this->plugin_name . '-debug',
            array( $this, 'display_debug_page' )
        );
    }

    public function display_debug_page() {
        $logs_table = new Wp_Mailchimp_Integration_Logs_Table();
        $logs_table->prepare_items();
        ?>
        <div class="wrap">
            <h1>Debug Log</h1>
            <form method="post">
                <?php
                $logs_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function display_plugin_setup_page() {
        include_once( 'partials/wp-mailchimp-integration-admin-display.php' );
    }

    public function display_audiences_page() {
        $audiences_table = new Wp_Mailchimp_Integration_Audiences_Table();
        $audiences_table->prepare_items();
        ?>
        <div class="wrap">
            <h1>Audiences</h1>
            <form method="post">
                <?php
                $audiences_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function display_contacts_page() {
        $api = Wp_Mailchimp_Api::get_instance();
        $audiences = $api->get_audiences();
        $selected_audience = isset( $_GET['audience_id'] ) ? $_GET['audience_id'] : '';
        ?>
        <div class="wrap">
            <h1>Contacts</h1>
            <form method="get">
                <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>">
                <select name="audience_id">
                    <option value="">Select Audience</option>
                    <?php foreach ( $audiences as $audience ) : ?>
                        <option value="<?php echo $audience->id; ?>" <?php selected( $selected_audience, $audience->id ); ?>><?php echo $audience->name; ?></option>
                    <?php endforeach; ?>
                </select>
                <?php submit_button( 'Filter', 'primary', 'filter_action', false ); ?>
            </form>
            <br>
            <?php if ( $selected_audience ) : ?>
                <form method="post">
                    <?php
                    $contacts_table = new Wp_Mailchimp_Integration_Contacts_Table( $selected_audience );
                    $contacts_table->prepare_items();
                    $contacts_table->display();
                    ?>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    public function display_automations_page() {
        if ( isset( $_GET['action'] ) && $_GET['action'] == 'add' ) {
            $this->display_add_automation_page();
            return;
        }

        if ( isset( $_GET['action'] ) && $_GET['action'] == 'edit' ) {
            $this->display_edit_automation_page();
            return;
        }

        $automations_table = new Wp_Mailchimp_Integration_Automations_Table();
        $automations_table->prepare_items();
        ?>
        <div class="wrap">
            <h1>Automations <a href="?page=<?php echo $_REQUEST['page']; ?>&action=add" class="page-title-action">Add New</a></h1>
            <form method="post">
                <?php
                $automations_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function display_edit_automation_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_automations';
        $id = absint( $_GET['automation'] );
        $automation = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) );
        ?>
        <div class="wrap">
            <h1>Edit Automation</h1>
            <form method="post">
                <input type="hidden" name="automation_id" value="<?php echo $automation->id; ?>">
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="name">Name</label></th>
                            <td><input type="text" name="name" id="name" class="regular-text" value="<?php echo esc_attr( $automation->name ); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="trigger">Trigger</label></th>
                            <td>
                                <select name="trigger" id="trigger">
                                    <option value="">Select a trigger</option>
                                    <option value="user_register" <?php selected( $automation->trigger_name, 'user_register' ); ?>>User registers</option>
                                    <option value="wp_login" <?php selected( $automation->trigger_name, 'wp_login' ); ?>>User logs in</option>
                                    <option value="comment_post" <?php selected( $automation->trigger_name, 'comment_post' ); ?>>Comment is posted</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="action">Action</label></th>
                            <td>
                                <select name="action" id="action">
                                    <option value="">Select an action</option>
                                    <option value="subscribe_user" <?php selected( $automation->action_name, 'subscribe_user' ); ?>>Subscribe user</option>
                                    <option value="unsubscribe_user" <?php selected( $automation->action_name, 'unsubscribe_user' ); ?>>Unsubscribe user</option>
                                </select>
                            </td>
                        </tr>
                        <tr id="audience_row" style="<?php echo ( $automation->action_name === 'subscribe_user' || $automation->action_name === 'unsubscribe_user' ) ? '' : 'display: none;'; ?>">
                            <th scope="row"><label for="audience_id">Audience</label></th>
                            <td>
                                <select name="audience_id" id="audience_id">
                                    <option value="">Select an audience</option>
                                    <?php
                                    $api = Wp_Mailchimp_Api::get_instance();
                                    $audiences = $api->get_audiences();
                                    foreach ( $audiences as $audience ) {
                                        echo '<option value="' . $audience->id . '" ' . selected( $automation->audience_id, $audience->id, false ) . '>' . $audience->name . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php submit_button( 'Update Automation' ); ?>
            </form>
        </div>
        <?php
    }

    public function display_add_automation_page() {
        ?>
        <div class="wrap">
            <h1>Add New Automation</h1>
            <form method="post">
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="name">Name</label></th>
                            <td><input type="text" name="name" id="name" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="trigger">Trigger</label></th>
                            <td>
                                <select name="trigger" id="trigger">
                                    <option value="">Select a trigger</option>
                                    <option value="user_register">User registers</option>
                                    <option value="wp_login">User logs in</option>
                                    <option value="comment_post">Comment is posted</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="action">Action</label></th>
                            <td>
                                <select name="action" id="action">
                                    <option value="">Select an action</option>
                                    <option value="subscribe_user">Subscribe user</option>
                                    <option value="unsubscribe_user">Unsubscribe user</option>
                                </select>
                            </td>
                        </tr>
                        <tr id="audience_row" style="display: none;">
                            <th scope="row"><label for="audience_id">Audience</label></th>
                            <td>
                                <select name="audience_id" id="audience_id">
                                    <option value="">Select an audience</option>
                                    <?php
                                    $api = Wp_Mailchimp_Api::get_instance();
                                    $audiences = $api->get_audiences();
                                    foreach ( $audiences as $audience ) {
                                        echo '<option value="' . $audience->id . '">' . $audience->name . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php submit_button( 'Add Automation' ); ?>
            </form>
        </div>
        <?php
    }

    public function display_events_page() {
        ?>
        <div class="wrap">
            <h1>Events</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Event</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>subscribes</td>
                        <td>When a new subscriber is added to an audience.</td>
                    </tr>
                    <tr>
                        <td>unsubscribes</td>
                        <td>When a subscriber unsubscribes from an audience.</td>
                    </tr>
                    <tr>
                        <td>profile</td>
                        <td>When a subscriber's profile is updated.</td>
                    </tr>
                    <tr>
                        <td>cleaned</td>
                        <td>When a subscriber's email address is cleaned from an audience.</td>
                    </tr>
                    <tr>
                        <td>upemail</td>
                        <td>When a subscriber's email address is updated.</td>
                    </tr>
                    <tr>
                        <td>campaign</td>
                        <td>When a campaign is sent.</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function options_update() {
        register_setting(
            $this->plugin_name,
            $this->option_name,
            array( $this, 'validate_options' )
        );

        add_settings_section(
            'wpmi_api_settings_section',
            'API Settings',
            null,
            $this->plugin_name
        );

        add_settings_field(
            'wpmi_api_key',
            'Mailchimp API Key',
            array( $this, 'render_api_key_field' ),
            $this->plugin_name,
            'wpmi_api_settings_section'
        );

        add_settings_field(
            'wpmi_audience_id',
            'Default Audience ID',
            array( $this, 'render_audience_id_field' ),
            $this->plugin_name,
            'wpmi_api_settings_section'
        );

        add_settings_section(
            'wpmi_user_sync_section',
            'User Sync Settings',
            null,
            $this->plugin_name
        );

        add_settings_field(
            'wpmi_user_sync_enabled',
            'Enable User Sync',
            array( $this, 'render_user_sync_enabled_field' ),
            $this->plugin_name,
            'wpmi_user_sync_section'
        );

        add_settings_field(
            'wpmi_user_sync_audience_id',
            'Audience for User Sync',
            array( $this, 'render_user_sync_audience_id_field' ),
            $this->plugin_name,
            'wpmi_user_sync_section'
        );

        add_settings_field(
            'wpmi_user_sync_role_mapping',
            'Map Roles to Tags',
            array( $this, 'render_user_sync_role_mapping_field' ),
            $this->plugin_name,
            'wpmi_user_sync_section'
        );
    }

    public function render_user_sync_role_mapping_field() {
        $options = get_option( $this->option_name );
        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();

        if ( empty( $audience_id ) ) {
            echo '<p class="description">Please select an audience to map roles to tags.</p>';
            return;
        }

        $api = Wp_Mailchimp_Api::get_instance();
        $tags = $api->get_tags( $audience_id );
        $roles = get_editable_roles();

        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>WordPress Role</th>
                    <th>Mailchimp Tag</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $roles as $role_key => $role ) : ?>
                    <tr>
                        <td><?php echo $role['name']; ?></td>
                        <td>
                            <select name="<?php echo $this->option_name; ?>[user_sync_role_mapping][<?php echo $role_key; ?>]">
                                <option value="">No Tag</option>
                                <?php foreach ( $tags as $tag ) : ?>
                                    <option value="<?php echo $tag->name; ?>" <?php selected( isset( $role_mappings[$role_key] ) ? $role_mappings[$role_key] : '', $tag->name ); ?>><?php echo $tag->name; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p>
            <button id="wpmi_bulk_sync_button" class="button button-primary">Bulk Sync Users</button>
        </p>
        <div id="wpmi_bulk_sync_progress"></div>
        <p>
            <button id="wpmi_enable_two_way_sync" class="button">Enable Two-Way Sync</button>
        </p>
        <div id="wpmi_two_way_sync_status"></div>
        <?php
    }


    public function render_user_sync_audience_id_field() {
        $options = get_option( $this->option_name );
        $api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';

        if ( empty( $api_key ) ) {
            echo '<p class="description">Please save your API key to see the list of audiences.</p>';
            return;
        }

        $api = Wp_Mailchimp_Api::get_instance();
        $audiences = $api->get_audiences();

        echo '<select name="' . $this->option_name . '[user_sync_audience_id]">';
        echo '<option value="">Select an audience</option>';
        foreach ( $audiences as $audience ) {
            echo '<option value="' . $audience->id . '" ' . selected( $audience_id, $audience->id, false ) . '>' . $audience->name . '</option>';
        }
        echo '</select>';
    }


    public function render_user_sync_enabled_field() {
        $options = get_option( $this->option_name );
        $user_sync_enabled = isset( $options['user_sync_enabled'] ) ? $options['user_sync_enabled'] : '';
        echo '<input type="checkbox" id="wpmi_user_sync_enabled" name="' . $this->option_name . '[user_sync_enabled]" value="1" ' . checked( 1, $user_sync_enabled, false ) . '>';
    }

    public function render_api_key_field() {
        $options = get_option( $this->option_name );
        $api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
        echo '<input type="text" id="wpmi_api_key" name="' . $this->option_name . '[api_key]" value="' . esc_attr( $api_key ) . '" class="regular-text">';
    }

    public function render_audience_id_field() {
        $options = get_option( $this->option_name );
        $api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
        $audience_id = isset( $options['audience_id'] ) ? $options['audience_id'] : '';

        if ( empty( $api_key ) ) {
            echo '<input type="text" name="' . $this->option_name . '[audience_id]" value="' . esc_attr( $audience_id ) . '" class="regular-text" disabled>';
            echo '<p class="description">Please save your API key to see the list of audiences.</p>';
            return;
        }

        $api = Wp_Mailchimp_Api::get_instance();
        $audiences = $api->get_audiences();

        echo '<select name="' . $this->option_name . '[audience_id]">';
        echo '<option value="">Select an audience</option>';
        foreach ( $audiences as $audience ) {
            echo '<option value="' . $audience->id . '" ' . selected( $audience_id, $audience->id, false ) . '>' . $audience->name . '</option>';
        }
        echo '</select>';
    }

    public function validate_options( $input ) {
        $output = array();
        if ( isset( $input['api_key'] ) ) {
            $output['api_key'] = sanitize_text_field( $input['api_key'] );
        }
        if ( isset( $input['audience_id'] ) ) {
            $output['audience_id'] = sanitize_text_field( $input['audience_id'] );
        }
        if ( isset( $input['user_sync_audience_id'] ) ) {
            $output['user_sync_audience_id'] = sanitize_text_field( $input['user_sync_audience_id'] );
        }
        if ( isset( $input['user_sync_role_mapping'] ) && is_array( $input['user_sync_role_mapping'] ) ) {
            $role_mapping = array();
            foreach ( $input['user_sync_role_mapping'] as $role => $tag_name ) {
                $role_mapping[ sanitize_key( $role ) ] = sanitize_text_field( $tag_name );
            }
            $output['user_sync_role_mapping'] = $role_mapping;
        }
        $output['user_sync_enabled'] = isset( $input['user_sync_enabled'] ) ? 1 : 0;
        return $output;
    }

    public function test_api_connection() {
        check_ajax_referer( 'wpmi_test_connection', 'nonce' );

        $api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';

        if ( empty( $api_key ) ) {
            wp_send_json_error( 'API Key is required.' );
        }

        $api = Wp_Mailchimp_Api::get_instance();
        $api->set_api_key( $api_key );

        if ( $api->ping() ) {
            wp_send_json_success( 'API key is valid.' );
        } else {
            wp_send_json_error( 'Error: ' . $api->get_error_message() );
        }
    }

    public function enable_two_way_sync() {
        check_ajax_referer( 'wpmi_enable_two_way_sync', 'nonce' );

        $options = get_option( $this->option_name );
        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            wp_send_json_error( 'User sync is not enabled.' );
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            wp_send_json_error( 'Audience for user sync is not set.' );
        }

        $webhook_url = get_rest_url( null, 'wp-mailchimp-integration/v1/webhook' );
        $api = Wp_Mailchimp_Api::get_instance();

        if ( $api->create_webhook( $audience_id, $webhook_url ) ) {
            wp_send_json_success( 'Two-way sync enabled successfully.' );
        } else {
            wp_send_json_error( 'Failed to create webhook.' );
        }
    }

    public function bulk_sync_users() {
        check_ajax_referer( 'wpmi_bulk_sync', 'nonce' );

        $options = get_option( $this->option_name );
        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            wp_send_json_error( 'User sync is not enabled.' );
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            wp_send_json_error( 'Audience for user sync is not set.' );
        }

        $offset = isset( $_POST['offset'] ) ? intval( $_POST['offset'] ) : 0;
        $batch_size = isset( $_POST['batch_size'] ) ? intval( $_POST['batch_size'] ) : 10;

        $users = get_users( array(
            'offset' => $offset,
            'number' => $batch_size,
        ) );

        if ( empty( $users ) ) {
            wp_send_json_success( array( 'message' => 'All users have been processed.', 'finished' => true ) );
        }

        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();
        $api = Wp_Mailchimp_Api::get_instance();
        $subscribed_count = 0;

        foreach ( $users as $user ) {
            $user_roles = $user->roles;
            $tag = '';

            if ( ! empty( $user_roles ) ) {
                $user_role = $user_roles[0];
                if ( isset( $role_mappings[ $user_role ] ) ) {
                    $tag = $role_mappings[ $user_role ];
                }
            }
            
            $tags_to_add = array();
            if( ! empty( $tag ) ) {
                $tags_to_add[] = $tag;
            }

            if ( $api->subscribe_user( $audience_id, $user->user_email, $user->first_name, $user->last_name, $tags_to_add ) ) {
                $subscribed_count++;
            }
        }

        $message = "Subscribed {$subscribed_count} of " . count($users) . " users in this batch.";
        wp_send_json_success( array( 'message' => $message, 'finished' => false ) );
    }
}