<?php
/*
 * Plugin Name:       WP Mailchimp Integration
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       A WordPress plugin for integrating Mailchimp with WordPress.
 * Version:           1.0.11
 * Author:            Darryl Erentzen
 * Author URI:        https://erentzen.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-mailchimp-integration
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Autoload dependencies if composer is used
if ( file_exists( plugin_dir_path( __FILE__ ) . 'vendor/autoload.php' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
}

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-mailchimp-api.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-wp-mailchimp-integration.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wp_mailchimp_integration() {

    $plugin = Wp_Mailchimp_Integration::get_instance( __FILE__ );

}

run_wp_mailchimp_integration();