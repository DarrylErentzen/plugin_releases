<?php

class Wp_Mailchimp_Api {

    private static $instance = null;
    /**
     * @var \MailchimpMarketing\ApiClient
     */
    private $mailchimp;
    private $error_message;

    private function __construct() {
        // Private constructor to prevent direct object creation
    }

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new Wp_Mailchimp_Api();
        }
        return self::$instance;
    }

    public function set_api_key($api_key) {
        $this->mailchimp = new \MailchimpMarketing\ApiClient();
        $server = 'us1';
        if ( strpos( $api_key, '-' ) !== false ) {
            $parts = explode( '-', $api_key );
            $server = end( $parts );
        }
        $this->mailchimp->setConfig([
            'apiKey' => $api_key,
            'server' => $server
        ]);
    }

    public function ping() {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $this->mailchimp->ping->get();
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function get_error_message() {
        return $this->error_message;
    }

    public function subscribe_user( $audience_id, $email, $fname, $lname, $tags = array() ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $this->mailchimp->lists->addListMember($audience_id, [
                "email_address" => $email,
                "status" => "subscribed",
                "merge_fields" => [
                    "FNAME" => $fname,
                    "LNAME" => $lname
                ],
                "tags" => $tags
            ]);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function create_webhook( $audience_id, $webhook_url ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $this->mailchimp->lists->createListWebhook($audience_id, [
                'url' => $webhook_url,
                'events' => [
                    'subscribe' => true,
                    'unsubscribe' => true,
                    'profile' => true,
                ],
                'sources' => [
                    'user' => true,
                    'admin' => true,
                    'api' => true,
                ]
            ]);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function update_member( $audience_id, $email, $data ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        $subscriber_hash = md5(strtolower($email));

        try {
            $this->mailchimp->lists->updateListMember($audience_id, $subscriber_hash, $data);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function get_tags($audience_id) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return [];
        }

        if ( empty($audience_id) ) {
            Wp_Mailchimp_Logger::log( 'error', 'Audience ID is not set.' );
            return [];
        }

        try {
            $response = $this->mailchimp->lists->listSegments($audience_id, null, null, "static");
            return $response->segments;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return [];
        }
    }

    public function get_audiences() {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return [];
        }

        try {
            $response = $this->mailchimp->lists->getAllLists();
            return $response->lists;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return [];
        }
    }

    public function get_campaigns() {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return [];
        }

        try {
            $response = $this->mailchimp->campaigns->list();
            return $response->campaigns;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return [];
        }
    }

    public function get_contacts($audience_id) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return [];
        }

        if ( empty($audience_id) ) {
            Wp_Mailchimp_Logger::log( 'error', 'Audience ID is not set.' );
            return [];
        }

        try {
            $response = $this->mailchimp->lists->getListMembersInfo($audience_id);
            return $response->members;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return [];
        }
    }

    public function create_campaign( $title, $subject, $audience_id ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $campaign = $this->mailchimp->campaigns->create([
                'type' => 'regular',
                'recipients' => [
                    'list_id' => $audience_id,
                ],
                'settings' => [
                    'subject_line' => $subject,
                    'title' => $title,
                    'from_name' => get_bloginfo( 'name' ),
                    'reply_to' => get_bloginfo( 'admin_email' ),
                ],
            ]);
            return $campaign->id;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function set_campaign_content( $campaign_id, $html ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $this->mailchimp->campaigns->setContent($campaign_id, [
                'html' => $html,
            ]);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function send_campaign( $campaign_id ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        try {
            $this->mailchimp->campaigns->send($campaign_id);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function unsubscribe_user( $audience_id, $email ) {
        if ( ! $this->mailchimp ) {
            Wp_Mailchimp_Logger::log( 'error', 'API key is not set.' );
            return false;
        }

        $subscriber_hash = md5(strtolower($email));

        try {
            $this->mailchimp->lists->updateListMember($audience_id, $subscriber_hash, [
                "status" => "unsubscribed",
            ]);
            return true;
        } catch (\Exception $e) {
            Wp_Mailchimp_Logger::log( 'error', $e->getMessage() );
            return false;
        }
    }

    public function send_email( $to, $subject, $message, $headers = [], $attachments = [] ) {
        $options = get_option( 'wp_mailchimp_integration' );
        $delivery_method = isset( $options['delivery_method'] ) ? $options['delivery_method'] : 'wp_mail';

        switch ( $delivery_method ) {
            case 'mailchimp':
                return $this->send_via_mailchimp( $to, $subject, $message );
            case 'aweber':
                return $this->send_via_aweber( $to, $subject, $message );
            case 'gmail':
                return $this->send_via_gmail( $to, $subject, $message );
            case 'smtp':
                return $this->send_via_smtp( $to, $subject, $message, $headers, $attachments );
            case 'wp_mail':
            default:
                return wp_mail( $to, $subject, $message, $headers, $attachments );
        }
    }

    private function send_via_mailchimp( $to, $subject, $message ) {
        // Placeholder for Mailchimp Transactional API
        Wp_Mailchimp_Logger::log( 'info', "Sending email via Mailchimp to $to" );
        return true;
    }

    private function send_via_aweber( $to, $subject, $message ) {
        // Placeholder for Aweber API
        Wp_Mailchimp_Logger::log( 'info', "Sending email via Aweber to $to" );
        return true;
    }

    private function send_via_gmail( $to, $subject, $message ) {
        // Placeholder for Gmail API
        Wp_Mailchimp_Logger::log( 'info', "Sending email via Gmail to $to" );
        return true;
    }

    private function send_via_smtp( $to, $subject, $message, $headers, $attachments ) {
        global $phpmailer;

        // Ensure PHPMailer is available
        if ( ! ( $phpmailer instanceof \PHPMailer\PHPMailer\PHPMailer ) ) {
            require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
            require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
            $phpmailer = new \PHPMailer\PHPMailer\PHPMailer( true );
        }

        $options = get_option( 'wp_mailchimp_integration' );

        try {
            $phpmailer->isSMTP();
            $phpmailer->Host       = isset( $options['smtp_host'] ) ? $options['smtp_host'] : '';
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Username   = isset( $options['smtp_user'] ) ? $options['smtp_user'] : '';
            $phpmailer->Password   = isset( $options['smtp_pass'] ) ? $options['smtp_pass'] : '';
            $phpmailer->SMTPSecure = isset( $options['smtp_secure'] ) ? $options['smtp_secure'] : 'tls';
            $phpmailer->Port       = isset( $options['smtp_port'] ) ? $options['smtp_port'] : 587;

            $phpmailer->setFrom( get_bloginfo( 'admin_email' ), get_bloginfo( 'name' ) );
            $phpmailer->addAddress( $to );
            $phpmailer->Subject = $subject;
            $phpmailer->Body    = $message;
            $phpmailer->isHTML( true );

            $phpmailer->send();
            return true;
        } catch ( \Exception $e ) {
            Wp_Mailchimp_Logger::log( 'error', 'SMTP Error: ' . $phpmailer->ErrorInfo );
            return false;
        }
    }
}
