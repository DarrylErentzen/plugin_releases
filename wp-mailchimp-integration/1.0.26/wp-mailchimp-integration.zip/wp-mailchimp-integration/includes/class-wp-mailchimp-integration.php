<?php

class Wp_Mailchimp_Integration {

    protected static $instance = null;

    protected $plugin_name;

    protected $version;

    protected $api;

    public static function get_instance( $plugin_file ) {
        if ( null === self::$instance ) {
            self::$instance = new self( $plugin_file );
        }
        return self::$instance;
    }

    protected function __construct( $plugin_file ) {
        $this->version = '1.0.0';
        $this->plugin_name = 'wp-mailchimp-integration';

        $this->define_constants( $plugin_file );
        $this->includes();
        $this->init_api();
        $this->init_hooks( $plugin_file );
        $this->initialize_update_checker();
    }
 
    private function define_constants( $plugin_file ) {
        define( 'WPMI_VERSION', $this->version );
        define( 'WPMI_PLUGIN_FILE', $plugin_file );
        define( 'WPMI_PLUGIN_DIR', plugin_dir_path( WPMI_PLUGIN_FILE ) );
        define( 'WPMI_PLUGIN_URL', plugin_dir_url( WPMI_PLUGIN_FILE ) );
    }

    private function includes() {
        require_once WPMI_PLUGIN_DIR . 'admin/class-wp-mailchimp-integration-admin.php';
        require_once WPMI_PLUGIN_DIR . 'public/class-wp-mailchimp-integration-public.php';
        require_once WPMI_PLUGIN_DIR . 'includes/class-wp-mailchimp-integration-automations-runner.php';
        require_once WPMI_PLUGIN_DIR . 'includes/class-wp-mailchimp-logger.php';
    }

    private function init_api() {
        $this->api = Wp_Mailchimp_Api::get_instance();
        $options = get_option( 'wp_mailchimp_integration' );
        if ( isset( $options['api_key'] ) ) {
            $this->api->set_api_key( $options['api_key'] );
        }
    }

    private function init_hooks( $plugin_file ) {
        register_activation_hook( $plugin_file, array( $this, 'activate' ) );
        register_deactivation_hook( $plugin_file, array(
            $this,
            'deactivate'
        ) );

        add_action( 'plugins_loaded', array( $this, 'run' ) );
        add_action( 'init', array( $this, 'register_post_types' ) );
        add_action( 'init', array( $this, 'register_blocks' ) );
        add_filter( 'block_categories_all', array( $this, 'register_block_category' ), 10, 2 );
        add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_block_editor_assets' ) );
        add_action( 'wpmi_send_scheduled_campaign', array( $this, 'send_scheduled_campaign' ), 10, 1 );
        add_action( 'user_register', array( $this, 'sync_new_user_to_mailchimp' ), 10, 1 );
        add_action( 'profile_update', array( $this, 'sync_user_profile_update_to_mailchimp' ), 10, 2 );
        add_action( 'rest_api_init', array( $this, 'register_webhook_endpoint' ) );
    }

    public function sync_user_profile_update_to_mailchimp( $user_id, $old_user_data ) {
        $options = get_option( 'wpmi_options' );

        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            return;
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            return;
        }

        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }

        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();
        $user_roles = $user->roles;
        $tag = '';

        if ( ! empty( $user_roles ) ) {
            $user_role = $user_roles[0];
            if ( isset( $role_mappings[ $user_role ] ) ) {
                $tag = $role_mappings[ $user_role ];
            }
        }
        
        $tags_to_add = array();
        if( ! empty( $tag ) ) {
            $tags_to_add[] = $tag;
        }

        $data = array(
            'email_address' => $user->user_email,
            'merge_fields' => array(
                'FNAME' => $user->first_name,
                'LNAME' => $user->last_name,
            ),
            'tags' => $tags_to_add,
        );

        $this->api->update_member( $audience_id, $old_user_data->user_email, $data );
    }

    public function register_webhook_endpoint() {
        register_rest_route( 'wp-mailchimp-integration/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array( $this, 'handle_mailchimp_webhook' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function handle_mailchimp_webhook( $request ) {
        $data = $request->get_params();

        if ( ! isset( $data['type'] ) ) {
            return new WP_REST_Response( 'Invalid webhook data.', 400 );
        }

        Wp_Mailchimp_Logger::log( 'webhook', 'Received webhook of type: ' . $data['type'] );
        Wp_Mailchimp_Logger::log( 'webhook', print_r( $data, true ) );

        switch ( $data['type'] ) {
            case 'profile':
                $email = $data['data']['email'];
                $user = get_user_by( 'email', $email );
                if ( $user ) {
                    $merges = $data['data']['merges'];
                    wp_update_user( array(
                        'ID'         => $user->ID,
                        'first_name' => $merges['FNAME'],
                        'last_name'  => $merges['LNAME'],
                    ) );
                    Wp_Mailchimp_Logger::log( 'webhook', 'Updated user profile for: ' . $email );
                }
                break;
            case 'unsubscribe':
                Wp_Mailchimp_Logger::log( 'webhook', 'User unsubscribed: ' . $data['data']['email'] );
                break;
            case 'subscribe':
                Wp_Mailchimp_Logger::log( 'webhook', 'User subscribed: ' . $data['data']['email'] );
                break;
        }

        return new WP_REST_Response( 'Webhook processed.', 200 );
    }



    public function sync_new_user_to_mailchimp( $user_id ) {
        $options = get_option( 'wpmi_options' );

        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            return;
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            return;
        }

        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }

        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();
        $user_roles = $user->roles;
        $tag = '';

        if ( ! empty( $user_roles ) ) {
            $user_role = $user_roles[0];
            if ( isset( $role_mappings[ $user_role ] ) ) {
                $tag = $role_mappings[ $user_role ];
            }
        }

        $tags_to_add = array();
        if( ! empty( $tag ) ) {
            $tags_to_add[] = $tag;
        }

        $this->api->subscribe_user( $audience_id, $user->user_email, $user->first_name, $user->last_name, $tags_to_add );
    }


    public function send_scheduled_campaign( $post_id ) {
        $admin = new Wp_Mailchimp_Integration_Admin( $this->get_plugin_name(), $this->get_version() );
        $admin->send_campaign( $post_id );
    }

    public function register_blocks() {
        register_block_type(
            'wp-mailchimp-integration/post-digest',
            array(
                'render_callback' => array( $this, 'render_post_digest_block' ),
            )
        );
        register_block_type( 'wp-mailchimp-integration/welcome-message' );

        if ( class_exists( 'WooCommerce' ) ) {
            register_block_type( 'wp-mailchimp-integration/product-highlight', array(
                'render_callback' => array( $this, 'render_product_highlight_block' ),
            ) );
        }
        
        register_block_type( 'wp-mailchimp-integration/post-tiles', array(
            'render_callback' => array( $this, 'render_post_tiles_block' ),
        ) );
    }

    public function render_post_tiles_block( $attributes ) {
        $args = array(
            'posts_per_page' => $attributes['numberOfPosts'],
        );
        $recent_posts = get_posts( $args );
        $columns = $attributes['columns'];

        $output = '<ul class="columns-' . $columns . '">';
        foreach ( $recent_posts as $post ) {
            $output .= '<li>';
            $output .= '<a href="' . get_permalink( $post ) . '">';
            $output .= get_the_post_thumbnail( $post, 'thumbnail' );
            $output .= '<h5>' . get_the_title( $post ) . '</h5>';
            $output .= '</a>';
            $output .= '<div>' . get_the_excerpt( $post ) . '</div>';
            $output .= '</li>';
        }
        $output .= '</ul>';

        return $output;
    }

    public function render_product_highlight_block( $attributes ) {
        $product_id = $attributes['productId'];
        $product = wc_get_product( $product_id );

        if ( ! $product ) {
            return '';
        }

        $output = '<div>';
        $output .= '<a href="' . get_permalink( $product_id ) . '">';
        $output .= $product->get_image();
        $output .= '<h5>' . $product->get_name() . '</h5>';
        $output .= '</a>';
        $output .= '<div>' . $product->get_price_html() . '</div>';
        $output .= '<a href="' . $product->add_to_cart_url() . '">Add to cart</a>';
        $output .= '</div>';

        return $output;
    }

    public function enqueue_block_editor_assets() {
        wp_enqueue_script(
            'wp-mailchimp-integration-post-digest-block',
            WPMI_PLUGIN_URL . 'admin/blocks/post-digest/editor.js',
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/post-digest/editor.js' )
        );

        wp_enqueue_script(
            'wp-mailchimp-integration-welcome-message-block',
            WPMI_PLUGIN_URL . 'admin/blocks/welcome-message/editor.js',
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/welcome-message/editor.js' )
        );
        
        if ( class_exists( 'WooCommerce' ) ) {
            wp_enqueue_script(
                'wp-mailchimp-integration-product-highlight-block',
                WPMI_PLUGIN_URL . 'admin/blocks/product-highlight/editor.js',
                array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
                filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/product-highlight/editor.js' )
            );
        }

        wp_enqueue_script(
            'wp-mailchimp-integration-post-tiles-block',
            WPMI_PLUGIN_URL . 'admin/blocks/post-tiles/editor.js',
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/post-tiles/editor.js' )
        );
    }

    public function render_post_digest_block( $attributes ) {
        $args = array(
            'posts_per_page' => $attributes['numberOfPosts'],
        );
        $recent_posts = get_posts( $args );
        $columns = $attributes['columns'];

        $output = '<ul class="columns-' . $columns . '">';
        foreach ( $recent_posts as $post ) {
            $output .= '<li>';
            $output .= '<a href="' . get_permalink( $post ) . '">';
            $output .= '<h5>' . get_the_title( $post ) . '</h5>';
            $output .= '</a>';
            $output .= '<div>' . get_the_excerpt( $post ) . '</div>';
            $output .= '</li>';
        }
        $output .= '</ul>';

        return $output;
    }

    public function register_block_category( $categories, $post ) {
        if ( $post->post_type !== 'mailchimp-template' ) {
            return $categories;
        }
        return array_merge(
            $categories,
            array(
                array(
                    'slug' => 'wp-mailchimp-integration',
                    'title' => __( 'Mailchimp', 'wp-mailchimp-integration' ),
                ),
            )
        );
    }

    public function run() {
        $plugin_admin = new Wp_Mailchimp_Integration_Admin( $this->get_plugin_name(), $this->get_version() );
        $plugin_public = new Wp_Mailchimp_Integration_Public( $this->get_plugin_name(), $this->get_version() );

        $automations_runner = Wp_Mailchimp_Integration_Automations_Runner::get_instance();
        $automations_runner->run();
    }

    public function register_post_types() {
        $labels = array(
            'name'                  => _x( 'Mailchimp Templates', 'Post type general name', 'wp-mailchimp-integration' ),
            'singular_name'         => _x( 'Mailchimp Template', 'Post type singular name', 'wp-mailchimp-integration' ),
            'menu_name'             => _x( 'Templates', 'Admin Menu text', 'wp-mailchimp-integration' ),
            'name_admin_bar'        => _x( 'Mailchimp Template', 'Add New on Toolbar', 'wp-mailchimp-integration' ),
            'add_new'               => __( 'Add New', 'wp-mailchimp-integration' ),
            'add_new_item'          => __( 'Add New Mailchimp Template', 'wp-mailchimp-integration' ),
            'new_item'              => __( 'New Mailchimp Template', 'wp-mailchimp-integration' ),
            'edit_item'             => __( 'Edit Mailchimp Template', 'wp-mailchimp-integration' ),
            'view_item'             => __( 'View Mailchimp Template', 'wp-mailchimp-integration' ),
            'all_items'             => __( 'All Mailchimp Templates', 'wp-mailchimp-integration' ),
            'search_items'          => __( 'Search Mailchimp Templates', 'wp-mailchimp-integration' ),
            'parent_item_colon'     => __( 'Parent Mailchimp Templates:', 'wp-mailchimp-integration' ),
            'not_found'             => __( 'No Mailchimp Templates found.', 'wp-mailchimp-integration' ),
            'not_found_in_trash'    => __( 'No Mailchimp Templates found in Trash.', 'wp-mailchimp-integration' ),
            'featured_image'        => _x( 'Mailchimp Template Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'archives'              => _x( 'Mailchimp Template archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'wp-mailchimp-integration' ),
            'insert_into_item'      => _x( 'Insert into Mailchimp Template', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'wp-mailchimp-integration' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Mailchimp Template', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'wp-mailchimp-integration' ),
            'filter_items_list'     => _x( 'Filter Mailchimp Templates list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'wp-mailchimp-integration' ),
            'items_list_navigation' => _x( 'Mailchimp Templates list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'wp-mailchimp-integration' ),
            'items_list'            => _x( 'Mailchimp Templates list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'wp-mailchimp-integration' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => 'wp-mailchimp-integration',
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'mailchimp-template' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array( 'title', 'editor' ),
            'show_in_rest'       => true,
        );

        register_post_type( 'mailchimp-template', $args );
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_automations';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name tinytext NOT NULL,
            trigger_name tinytext NOT NULL,
            action_name tinytext NOT NULL,
            audience_id tinytext,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        $table_name = $wpdb->prefix . 'mailchimp_logs';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            type tinytext NOT NULL,
            message text NOT NULL,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta( $sql );
    }

    public function deactivate() {
        // Deactivation code
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }

    public function get_api() {
        return $this->api;
    }

    public function initialize_update_checker() {
        if ( file_exists( WPMI_PLUGIN_DIR . 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php' ) ) {
            require_once WPMI_PLUGIN_DIR . 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';
            $myUpdateChecker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
                'https://raw.githubusercontent.com/DarrylErentzen/plugin_releases/refs/heads/master/wp-mailchimp-integration/info.json',
                WPMI_PLUGIN_FILE,
                'wp-mailchimp-integration'
            );
        }
    }
}
