<?php return array('dependencies' => array('wp-element'), 'version' => 'cba463967792f9477d56');
