<?php return array('dependencies' => array('wp-element'), 'version' => '04737f75c8d0a381a43d');
