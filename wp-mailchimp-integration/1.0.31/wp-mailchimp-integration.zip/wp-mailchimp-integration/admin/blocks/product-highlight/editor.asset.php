<?php return array('dependencies' => array('wp-element'), 'version' => '04d3da2eedf5b8eaf2c3');
