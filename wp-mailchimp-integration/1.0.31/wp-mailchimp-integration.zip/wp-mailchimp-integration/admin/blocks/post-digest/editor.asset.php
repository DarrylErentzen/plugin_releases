<?php return array('dependencies' => array('wp-element'), 'version' => '72498f56bfbd1b82f1be');
