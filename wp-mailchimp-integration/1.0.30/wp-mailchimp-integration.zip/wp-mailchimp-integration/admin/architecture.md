# Architecture of the `admin` Directory

This document provides a breakdown of each file and subdirectory within the `admin` directory, explaining their roles and how they contribute to the plugin's administration interface.

## Root Directory Files

These are the main PHP classes that manage the core administrative functionality.

### `class-wp-mailchimp-integration-admin.php`

This is the central class for the entire admin area. It orchestrates all administrative features and settings.

- **Menu Creation:** Adds the main "MailChimp Integration" menu and all its sub-pages (Audiences, Contacts, Automations, Events, Debug) to the WordPress admin panel.
- **Hook Registration:** Connects numerous methods to WordPress action and filter hooks, such as `admin_menu`, `admin_init`, `admin_enqueue_scripts`, and `save_post`.
- **Settings & Options:** Manages the registration, validation, and rendering of all plugin options via the WordPress Settings API.
- **AJAX Handling:** Defines all AJAX endpoints for asynchronous operations like testing the API connection (`wp_ajax_wpmi_test_connection`), bulk-syncing users (`wp_ajax_wpmi_bulk_sync`), and enabling two-way sync.
- **Post Type Integration:** Adds custom meta boxes to the `mailchimp-template` post type for scheduling campaigns and selecting a target audience.
- **CRUD Operations:** Contains the logic for handling the creation, updating, and deletion of automations.
- **Page Display:** Renders the content for each of the admin sub-pages by including partials or instantiating the appropriate `WP_List_Table` classes.

### `WP_List_Table` Classes

The following files extend the built-in WordPress `WP_List_Table` class to create sortable, paginated tables for displaying data.

- **`class-wp-mailchimp-integration-audiences-table.php`:** Displays a table of Mailchimp audiences fetched from the API.
- **`class-wp-mailchimp-integration-contacts-table.php`:** Displays a table of contacts (members) for a specific, selected Mailchimp audience.
- **`class-wp-mailchimp-integration-automations-table.php`:** Displays a table of the automation rules stored in the custom database table (`wp_mailchimp_automations`).
- **`class-wp-mailchimp-integration-logs-table.php`:** Displays a table of log entries from the custom database table (`wp_mailchimp_logs`) for debugging purposes.

## Subdirectories

### `partials/`

This directory contains template files used for rendering parts of the admin pages.

- **`wp-mailchimp-integration-admin-display.php`:** The main view file for the primary settings page. It includes the HTML for the settings form, the "Test Connection" button, and the "Launch Setup Wizard" button.

### `js/`

This directory holds the JavaScript files for the main admin pages.

- **`wp-mailchimp-integration-admin.js`:** Contains the jQuery/AJAX logic for the main settings page. It handles:
    - The "Test Connection" button click.
    - The multi-step bulk user synchronization process.
    - The "Enable Two-Way Sync" feature, which creates a webhook.
    - Dynamically showing/hiding the audience selector in the automations form.

### `blocks/`

This directory contains the source code for custom Gutenberg editor blocks. Each subdirectory represents a single block.

- **`block.json`:** A metadata file in each folder that defines the block's name, title, category, attributes, and script dependencies, following the WordPress block standards.
- **`editor.js`:** The JavaScript file (using React/JSX) that defines the block's appearance and behavior within the block editor (`edit` function) and, for some, what gets saved to the database (`save` function).
- **Blocks include:** `post-digest`, `post-tiles`, `product-highlight`, `signup-form`, and `welcome-message`.

### `wizard/`

This directory encapsulates all functionality for the interactive setup wizard.

- **`class-wp-mailchimp-integration-wizard.php`:** The PHP class that powers the wizard. It defines the wizard steps (titles, content, target elements) and provides them via an AJAX endpoint. It also handles enqueueing the wizard's specific CSS and JS assets.
- **`wizard.css` & `wizard.js` (root):** These appear to be older or alternative versions of the wizard's assets.
- **`css/wizard.css`:** Contains the primary styling for the wizard's modal window, including layout, positioning, and responsive design.
- **`js/wizard.js`:** Contains the core JavaScript logic that drives the wizard's interactivity. It fetches the steps via AJAX, builds the modal and table of contents, highlights target elements on the page, and controls the "Next" and "Previous" step navigation.
- **`views/wizard-modal-view.php`:** The PHP template file that defines the HTML structure of the wizard's modal dialog, which is then populated dynamically by the JavaScript.
