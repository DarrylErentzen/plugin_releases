<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Contacts_Table extends WP_List_Table {

    private $audience_id;

    public function __construct( $audience_id ) {
        parent::__construct( [
            'singular' => 'Contact',
            'plural'   => 'Contacts',
            'ajax'     => false
        ] );
        $this->audience_id = $audience_id;
    }

    public function get_columns() {
        $columns = [
            'email_address' => 'Email',
            'first_name'    => 'First Name',
            'last_name'     => 'Last Name',
            'status'        => 'Status',
            'address'       => 'Address',
            'phone'         => 'Phone',
            'birthday'      => 'Birthday',
            'company'       => 'Company',
            'format'        => 'Preferred Format',
            'licenses'      => 'Licenses',
            'timestamp_opt' => 'Subscribed',
            'last_changed'  => 'Last Changed',
        ];
        return $columns;
    }

    protected function get_hidden_columns() {
        return [
            'address',
            'phone',
            'birthday',
            'company',
            'format',
            'licenses',
            'timestamp_opt',
            'last_changed',
        ];
    }

    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = [];
        $this->_column_headers = [$columns, $hidden, $sortable];

        $per_page = $this->get_items_per_page( 'contacts_per_page', 20 );
        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;

        $filters = [
            'status' => isset( $_REQUEST['status'] ) ? sanitize_text_field( $_REQUEST['status'] ) : '',
            'tag'    => isset( $_REQUEST['tag'] ) ? sanitize_text_field( $_REQUEST['tag'] ) : '',
        ];

        $api = Wp_Mailchimp_Api::get_instance();
        $response = $api->get_contacts( $this->audience_id, $per_page, $offset, array_filter( $filters ) );

        if ( $response && isset( $response->members ) ) {
            $this->items = $response->members;
            $total_items = $response->total_items;
        } else {
            $this->items = [];
            $total_items = 0;
        }

        $this->set_pagination_args( [
            'total_items' => $total_items,
            'per_page'    => $per_page
        ] );
    }

    public function column_email_address( $item ) {
        $edit_url = sprintf(
            '?page=%s&action=edit&audience_id=%s&contact_id=%s',
            $_REQUEST['page'],
            $this->audience_id,
            $item->id
        );

        $delete_url = sprintf(
            '?page=%s&action=delete&audience_id=%s&contact=%s&_wpnonce=%s',
            $_REQUEST['page'],
            $this->audience_id,
            $item->id,
            wp_create_nonce( 'wpmi_delete_contact' )
        );

        $actions = [
            'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), __( 'Edit', 'wp-mailchimp-integration' ) ),
            'delete' => sprintf( '<a href="%s" onclick="return confirm(\'Are you sure you want to delete this contact?\');">%s</a>', esc_url( $delete_url ), __( 'Delete', 'wp-mailchimp-integration' ) ),
        ];

        return sprintf( '%1$s %2$s', $item->email_address, $this->row_actions( $actions ) );
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'first_name':
                return isset( $item->merge_fields->FNAME ) ? $item->merge_fields->FNAME : '';
            case 'last_name':
                return isset( $item->merge_fields->LNAME ) ? $item->merge_fields->LNAME : '';
            case 'address':
                $address = (array) ( isset( $item->merge_fields->ADDRESS ) ? $item->merge_fields->ADDRESS : [] );
                return implode( ', ', array_filter( $address ) );
            case 'phone':
                return isset( $item->merge_fields->PHONE ) ? $item->merge_fields->PHONE : '';
            case 'birthday':
                return isset( $item->merge_fields->BIRTHDAY ) ? $item->merge_fields->BIRTHDAY : '';
            case 'company':
                return isset( $item->merge_fields->COMPANY ) ? $item->merge_fields->COMPANY : '';
            case 'format':
                return isset( $item->merge_fields->FORMAT ) ? $item->merge_fields->FORMAT : '';
            case 'licenses':
                return isset( $item->merge_fields->LICENSES ) ? $item->merge_fields->LICENSES : '';
            case 'status':
                return $item->status;
            case 'timestamp_opt':
                return ! empty( $item->timestamp_opt ) ? date( 'Y-m-d H:i:s', strtotime( $item->timestamp_opt ) ) : 'N/A';
            case 'last_changed':
                return ! empty( $item->last_changed ) ? date( 'Y-m-d H:i:s', strtotime( $item->last_changed ) ) : 'N/A';
            default:
                return print_r( $item, true );
        }
    }
}
