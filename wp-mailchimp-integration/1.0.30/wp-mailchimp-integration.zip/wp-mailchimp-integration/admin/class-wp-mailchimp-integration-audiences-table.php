<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Audiences_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => 'Audience',
            'plural'   => 'Audiences',
            'ajax'     => false
        ] );
    }

    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $api = Wp_Mailchimp_Api::get_instance();
        $audiences = $api->get_audiences();
        $this->items = $audiences;

        $this->set_pagination_args( array(
            'total_items' => count( $this->items ),
            'per_page'    => count( $this->items ),
            'total_pages' => 1
        ) );
    }

    public function get_columns() {
        return [
            'name' => 'Name',
            'member_count' => 'Members',
            'unsubscribe_count' => 'Unsubscribed',
            'cleaned_count' => 'Cleaned',
        ];
    }

    public function column_name( $item ) {
        $actions = array(
            'contacts' => sprintf( '<a href="?page=%s&audience_id=%s">%s</a>', 'wp-mailchimp-integration-contacts', $item->id, __( 'View Contacts', 'wp-mailchimp-integration' ) ),
        );
        return sprintf( '%1$s %2$s', $item->name, $this->row_actions( $actions ) );
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'member_count':
                return $item->stats->member_count;
            case 'unsubscribe_count':
                return $item->stats->unsubscribe_count;
            case 'cleaned_count':
                return $item->stats->cleaned_count;
            default:
                return print_r( $item, true );
        }
    }
}
