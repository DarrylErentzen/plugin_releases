(function($) {
    'use strict';

    var Wizard = {
        steps: [],
        currentStep: 0,
        overlay: null,
        popover: null,

        init: function() {
            var self = this;
            
            // Only run on the settings page
            if ($('form[action="options.php"]').length === 0) {
                return;
            }

            // Create Start Button if not exists
            if ($('#wpmi-start-wizard').length === 0) {
                $('.wrap h1').first().after('<button type="button" id="wpmi-start-wizard" class="button button-secondary" style="margin-left: 10px; vertical-align: middle;">Setup Wizard</button>');
            }

            $('#wpmi-start-wizard').on('click', function(e) {
                e.preventDefault();
                self.loadSteps();
            });
        },

        loadSteps: function() {
            var self = this;
            $.ajax({
                url: wizard_ajax.ajax_url,
                data: {
                    action: 'get_wizard_steps'
                },
                success: function(response) {
                    if (response.success) {
                        self.steps = Object.values(response.data);
                        self.start();
                    } else {
                        alert('Could not load wizard steps.');
                    }
                }
            });
        },

        start: function() {
            this.currentStep = 0;
            this.createOverlay();
            this.showStep();
        },

        createOverlay: function() {
            if (!this.overlay) {
                this.overlay = $('<div class="wpmi-wizard-overlay"></div>').appendTo('body');
            }
            this.overlay.show();
        },

        createPopover: function() {
            if (this.popover) {
                this.popover.remove();
            }
            this.popover = $('<div class="wpmi-wizard-popover">' +
                '<div class="wpmi-wizard-content">' +
                    '<h3 class="wpmi-wizard-title"></h3>' +
                    '<p class="wpmi-wizard-text"></p>' +
                    '<div class="wpmi-wizard-controls">' +
                        '<button type="button" class="button wpmi-prev-step">Previous</button>' +
                        '<button type="button" class="button button-primary wpmi-next-step">Next</button>' +
                        '<button type="button" class="button wpmi-close-wizard">Close</button>' +
                    '</div>' +
                '</div>' +
                '<div class="wpmi-wizard-arrow"></div>' +
            '</div>').appendTo('body');

            var self = this;
            this.popover.find('.wpmi-next-step').on('click', function() {
                self.nextStep();
            });
            this.popover.find('.wpmi-prev-step').on('click', function() {
                self.prevStep();
            });
            this.popover.find('.wpmi-close-wizard').on('click', function() {
                self.close();
            });
        },

        showStep: function() {
            var step = this.steps[this.currentStep];
            var $target = $(step.target_element);

            // Remove previous highlights
            $('.wpmi-wizard-highlight').removeClass('wpmi-wizard-highlight');

            if ($target.length === 0) {
                if (this.currentStep > 0) {
                    console.warn('Target not found for step: ' + step.title);
                }
            }

            // Scroll to target
            if ($target.length) {
                $('html, body').animate({
                    scrollTop: $target.offset().top - 100
                }, 300);
                $target.addClass('wpmi-wizard-highlight');
            }

            this.createPopover();
            this.popover.find('.wpmi-wizard-title').text(step.title);
            this.popover.find('.wpmi-wizard-text').text(step.content_desktop);

            // Update buttons
            if (this.currentStep === 0) {
                this.popover.find('.wpmi-prev-step').hide();
            } else {
                this.popover.find('.wpmi-prev-step').show();
            }

            if (this.currentStep === this.steps.length - 1) {
                this.popover.find('.wpmi-next-step').text('Finish');
            } else {
                this.popover.find('.wpmi-next-step').text('Next');
            }

            this.positionPopover($target);
        },

        positionPopover: function($target) {
            if (!$target || $target.length === 0) {
                // Center if no target
                this.popover.css({
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    position: 'fixed'
                });
                return;
            }

            var offset = $target.offset();
            var width = $target.outerWidth();
            var height = $target.outerHeight();
            var popoverWidth = this.popover.outerWidth();
            var popoverHeight = this.popover.outerHeight();
            var windowWidth = $(window).width();

            // Default: Right
            var top = offset.top;
            var left = offset.left + width + 15;
            var placement = 'right';

            // Check if fits on right
            if (left + popoverWidth > windowWidth - 20) {
                // Try bottom
                top = offset.top + height + 15;
                left = offset.left;
                placement = 'bottom';
            }

            this.popover.css({
                top: top,
                left: left,
                transform: 'none',
                position: 'absolute'
            });
            
            this.popover.attr('data-placement', placement);
        },

        nextStep: function() {
            if (this.currentStep < this.steps.length - 1) {
                this.currentStep++;
                this.showStep();
            } else {
                this.close();
            }
        },

        prevStep: function() {
            if (this.currentStep > 0) {
                this.currentStep--;
                this.showStep();
            }
        },

        close: function() {
            if (this.popover) this.popover.remove();
            if (this.overlay) this.overlay.hide();
            $('.wpmi-wizard-highlight').removeClass('wpmi-wizard-highlight');
        }
    };

    $(document).ready(function() {
        Wizard.init();
    });

})(jQuery);