# WP MailChimp Integration

A powerful WordPress plugin to integrate your MailChimp account with your WordPress site.

## Description

This plugin provides deep integration with MailChimp. It allows you to connect your MailChimp account to your WordPress site to synchronize users, view audiences, and manage contacts directly from the WordPress admin dashboard. The plugin also provides several Gutenberg blocks to display MailChimp-related content on your website, and a robust automation system to trigger actions based on user behavior.

## Features

*   **Settings:** A dedicated settings page to configure your MailChimp API key and other plugin settings.
*   **Audience Management:** View your MailChimp audiences and their stats from the WordPress admin panel.
*   **Contact Management:** View your contacts for each audience, with pagination to handle large lists.
*   **User Sync:** Automatically synchronize your WordPress users with a MailChimp audience.
*   **Role-to-Tag Mapping:** Map WordPress user roles to MailChimp tags for better segmentation.
*   **Automations:** Create automations to subscribe or unsubscribe users from an audience based on triggers like user registration or login.
*   **Gutenberg Blocks:** A suite of Gutenberg blocks to enhance your content:
    *   **Post Digest:** Create a digest of your latest posts.
    *   **Post Tiles:** Display posts in a stylish tiled layout.
    *   **Product Highlight:** (WooCommerce required) Showcase a product.
    *   **Welcome Message:** A simple welcome message block.
*   **Debugging:** Includes a logging system to help debug API calls and webhook events.

## Installation

1.  From your WordPress dashboard, navigate to **Plugins > Add New**.
2.  Click the **Upload Plugin** button at the top of the page.
3.  Upload the `wp-mailchimp-integration.zip` file.
4.  Activate the plugin through the 'Plugins' menu in WordPress.
5.  Navigate to the **WP MailChimp > Settings** page in the WordPress admin menu to configure the plugin with your MailChimp API key.

## Screenshots

### Settings
![Settings Page](assets/screenshots/Settings.png)

### Audiences
![Audiences Page](assets/screenshots/Audiences.png)

### Contacts
![Contacts Page](assets/screenshots/Contacts.png)

### Automations
![Automations Page](assets/screenshots/Automations.png)

## Changelog

For a detailed list of changes, please refer to the `changelog.md` file.

---
*This README was last updated by Gemini.*
