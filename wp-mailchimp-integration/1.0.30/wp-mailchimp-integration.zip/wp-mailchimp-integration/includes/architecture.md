# Architecture of the `includes` Directory

This document provides a breakdown of each file in the `includes` directory.

### `class-wp-mailchimp-integration.php`

This is the main orchestrator of the plugin. It's a singleton class that:

*   **Initializes the plugin:** Sets the plugin name and version.
*   **Defines constants:** Sets up constants for the plugin version, file path, directory, and URL.
*   **Includes dependencies:** It requires the `admin` and `public` classes, as well as the `automations-runner` and `logger` classes.
*   **Initializes the API:** It gets an instance of the `Wp_Mailchimp_Api` class and sets the API key from the saved options.
*   **Sets up hooks:** It registers a large number of WordPress action and filter hooks. This is where most of the plugin's functionality is wired into WordPress. This includes:
    *   Plugin activation and deactivation.
    *   Registering a `mailchimp-template` custom post type.
    *   Registering custom Gutenberg blocks.
    *   Syncing users to Mailchimp when they register or update their profile.
    *   Creating a REST API endpoint to handle webhooks from Mailchimp.
    *   Adding the plugin's settings pages to the WordPress admin menu.
    *   Registering the settings that can be configured on the settings pages.
*   **Renders settings fields:** Contains the HTML output for the fields on the settings page.
*   **Initializes an update checker:** It uses the `yahnis-elsts/plugin-update-checker` library to check for new versions of the plugin from a GitHub repository.

### `class-wp-mailchimp-api.php`

This is a singleton class that handles all communication with the Mailchimp API.

*   **API Client:** It uses the `mailchimp/marketing` client library.
*   **API Key:** The `set_api_key()` method configures the client with the user's API key.
*   **Core Mailchimp Functions:** It has methods that correspond to Mailchimp API endpoints, such as:
    *   `ping()`: To test the API key.
    *   `get_audiences()`, `get_campaigns()`, `get_contacts()`, `get_tags()`: To retrieve information from Mailchimp.
    *   `subscribe_user()`, `unsubscribe_user()`, `update_member()`: To manage audience members.
    *   `create_campaign()`, `set_campaign_content()`, `send_campaign()`: To create and send email campaigns.
    *   `create_webhook()`: To set up webhooks in Mailchimp.
*   **Email Sending:** Interestingly, it also includes a generic `send_email()` method that can route emails through different services (wp_mail, Mailchimp, Aweber, Gmail, or SMTP), not just Mailchimp.

### `class-wp-mailchimp-logger.php`

This is a simple static utility class for logging.

*   **`log()` method:** It has a single static method `log()` that takes a `$type` and a `$message`.
*   **Database logging:** It inserts log messages into a custom database table named `wp_mailchimp_logs`.

### `class-wp-mailchimp-integration-automations-runner.php`

This is a singleton class responsible for executing automated tasks.

*   **`run()` method:** It fetches a list of automations from a custom database table named `wp_mailchimp_automations`.
*   **Dynamic Hooks:** For each automation, it dynamically attaches a WordPress action. For example, it might subscribe a user to an audience when they register (`user_register` trigger).
*   **`execute_action()` method:** This method is called when the trigger action occurs. It determines what action to take (e.g., `subscribe_user`) and uses the `Wp_Mailchimp_Api` class to perform it.

### Summary

In summary, the `includes` directory contains the core logic. `Wp_Mailchimp_Integration` is the central hub, `Wp_Mailchimp_Api` handles external communication with Mailchimp, `Wp_Mailchimp_Logger` provides a simple logging service, and `Wp_Mailchimp_Integration_Automations_Runner` manages the automation features.
