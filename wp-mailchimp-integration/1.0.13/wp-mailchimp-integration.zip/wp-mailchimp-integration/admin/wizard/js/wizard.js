(function( $ ) {
    'use strict';

    let stepsData = {};
    let currentStep = 0;
    let stepKeys = [];

    // DOM elements
    let $modal;
    let $toc;
    let $stepContent;
    let $stepTitle;
    let $prevButton;
    let $nextButton;

    function init() {
        // This button will trigger the wizard. We will add it to the admin page later.
        $('body').on('click', '#launch-wizard-btn', fetchStepsAndLaunch);
    }

    function fetchStepsAndLaunch() {
        // Always fetch fresh data and rebuild the modal.
        // If a previous modal exists for some reason, remove it.
        $('#wizard-modal').remove();

        $.ajax({
            url: wizard_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'get_wizard_steps'
            },
            success: function(response) {
                if (response.success) {
                    stepsData = response.data;
                    stepKeys = Object.keys(stepsData);
                    currentStep = 0; // Reset step
                    buildModal();
                    attachEventListeners();
                    updateStepContent();
                    $modal.show(); // Show the newly built modal
                }
            }
        });
    }

    function buildModal() {
        // The modal HTML will be loaded via a template file, for now, let's use a string
        const modalHtml = `
            <div id="wizard-modal" class="wizard-modal" style="display: none;">
                <div class="wizard-modal-content">
                    <button class="wizard-close-btn">&times;</button>
                    <div class="wizard-sidebar">
                        <h3>Table of Contents</h3>
                        <ul class="wizard-toc"></ul>
                    </div>
                    <div class="wizard-main">
                        <h2 class="wizard-step-title"></h2>
                        <div class="wizard-step-body"></div>
                        <div class="wizard-navigation">
                            <button class="wizard-prev-btn">Previous</button>
                            <button class="wizard-next-btn">Next</button>
                        </div>
                        <div class="wizard-learn-more">
                            <a href="#" target="_blank">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        `;
        $('body').append(modalHtml);

        // Assign DOM elements
        $modal = $('#wizard-modal');
        $toc = $modal.find('.wizard-toc');
        $stepContent = $modal.find('.wizard-step-body');
        $stepTitle = $modal.find('.wizard-step-title');
        $prevButton = $modal.find('.wizard-prev-btn');
        $nextButton = $modal.find('.wizard-next-btn');

        buildToc();
    }
    
    function buildToc() {
        stepKeys.forEach((key, index) => {
            const step = stepsData[key];
            $toc.append(`<li data-step-index="${index}">${step.title}</li>`);
        });
    }


    function attachEventListeners() {
        $modal.on('click', '.wizard-close-btn', () => {
            $('.wizard-highlight').removeClass('wizard-highlight');
            $modal.remove();
        });
        $modal.on('click', '.wizard-prev-btn', showPreviousStep);
        $modal.on('click', '.wizard-next-btn', showNextStep);
        $toc.on('click', 'li', function() {
            currentStep = $(this).data('step-index');
            updateStepContent();
        });
    }

    function showPreviousStep() {
        if (currentStep > 0) {
            currentStep--;
            updateStepContent();
        }
    }

    function showNextStep() {
        if (currentStep < stepKeys.length - 1) {
            currentStep++;
            updateStepContent();
        }
    }

    function updateStepContent() {
        const stepKey = stepKeys[currentStep];
        const step = stepsData[stepKey];
        const isMobile = window.innerWidth < 768;

        // Update content
        $stepTitle.text(step.title);
        $stepContent.html(isMobile ? step.content_shorthand : step.content_desktop);
        $modal.find('.wizard-learn-more a').attr('href', step.learn_more_url);

        // Update navigation buttons
        $prevButton.toggle(currentStep > 0);
        $nextButton.text(currentStep === stepKeys.length - 1 ? 'Finish' : 'Next');

        // Update TOC highlighting
        $toc.find('li').removeClass('active');
        $toc.find(`li[data-step-index="${currentStep}"]`).addClass('active');

        // Highlight target element
        $('.wizard-highlight').removeClass('wizard-highlight');
        if (step.target_element && $(step.target_element).length) {
            $(step.target_element).addClass('wizard-highlight');
        }
    }

    $(document).ready(init);

})( jQuery );
