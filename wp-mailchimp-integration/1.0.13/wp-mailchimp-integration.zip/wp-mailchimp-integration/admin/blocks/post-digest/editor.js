const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.blockEditor;
const { PanelBody, SelectControl, TextControl } = wp.components;
const { withSelect } = wp.data;

registerBlockType( 'wp-mailchimp-integration/post-digest', {
    title: 'Post Digest',
    category: 'wp-mailchimp-integration',
    icon: 'email-alt',
    description: 'A block to display a digest of posts.',
    keywords: [ 'post', 'digest', 'mailchimp' ],
    attributes: {
        numberOfPosts: {
            type: 'number',
            default: 5,
        },
        columns: {
            type: 'number',
            default: 1,
        },
    },
    edit: withSelect( ( select, props ) => {
        const { attributes: { numberOfPosts } } = props;
        const query = {
            per_page: numberOfPosts,
        };
        return {
            posts: select( 'core' ).getEntityRecords( 'postType', 'post', query ),
        };
    } )( ( { posts, className, attributes, setAttributes } ) => {

        if ( ! posts ) {
            return 'Loading...';
        }

        if ( posts && posts.length === 0 ) {
            return 'No posts found.';
        }

        const { numberOfPosts, columns } = attributes;

        return (
            <div className={ className }>
                <InspectorControls>
                    <PanelBody title="Post Digest Settings">
                        <TextControl
                            label="Number of posts"
                            type="number"
                            value={ numberOfPosts }
                            onChange={ ( value ) => setAttributes( { numberOfPosts: parseInt( value, 10 ) } ) }
                        />
                        <SelectControl
                            label="Columns"
                            value={ columns }
                            options={ [
                                { label: '1', value: 1 },
                                { label: '2', value: 2 },
                                { label: '3', value: 3 },
                            ] }
                            onChange={ ( value ) => setAttributes( { columns: parseInt( value, 10 ) } ) }
                        />
                    </PanelBody>
                </InspectorControls>
                <ul className={ `columns-${ columns }` }>
                    { posts.map( post => (
                        <li key={ post.id }>
                            <a href={ post.link }>
                                <h5>{ post.title.rendered }</h5>
                            </a>
                            <div dangerouslySetInnerHTML={ { __html: post.excerpt.rendered } } />
                        </li>
                    ) ) }
                </ul>
            </div>
        );
    } ),
    save: ( { attributes } ) => {
        const { numberOfPosts, columns } = attributes;
        return (
            <div>
                <p>Post Digest with {numberOfPosts} posts and {columns} columns.</p>
            </div>
        );
    },
} );
