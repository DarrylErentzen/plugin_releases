/**
 * WordPress dependencies
 */
import { __ } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';

/**
 * Internal dependencies
 */
import metadata from './block.json';

const { name } = metadata;

registerBlockType( name, {
	/**
	 * @see ./edit.js
	 */
	edit: ( { attributes, setAttributes } ) => (
		<div>
			<InspectorControls>
				<PanelBody title={ __( 'Form Settings' ) }>
					<TextControl
						label={ __( 'Audience ID' ) }
						value={ attributes.audienceId }
						onChange={ ( audienceId ) => setAttributes( { audienceId } ) }
						help={ __( 'Enter the Mailchimp Audience ID to subscribe users to.' ) }
					/>
				</PanelBody>
			</InspectorControls>
			<p>{ __( 'Mailchimp Signup Form - Configure the Audience ID in the block settings sidebar.' ) }</p>
		</div>
	),

	/**
	 * @see ./save.js
	 */
	save: () => {
		return null;
	},
} );
