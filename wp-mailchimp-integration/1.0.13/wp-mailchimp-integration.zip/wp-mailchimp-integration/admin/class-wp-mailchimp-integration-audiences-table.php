<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Audiences_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => 'Audience',
            'plural'   => 'Audiences',
            'ajax'     => false
        ] );
    }

    public function get_columns() {
        return [
            'cb'   => '<input type="checkbox" />',
            'name' => 'Name',
            'member_count' => 'Members',
            'unsubscribe_count' => 'Unsubscribed',
            'cleaned_count' => 'Cleaned',
        ];
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'name':
                return $item->name;
            case 'member_count':
                return $item->stats->member_count;
            case 'unsubscribe_count':
                return $item->stats->unsubscribe_count;
            case 'cleaned_count':
                return $item->stats->cleaned_count;
            default:
                return print_r( $item, true );
        }
    }

    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="audience[]" value="%s" />', $item->id
        );
    }
}
