<form action="" method="post">
    <?php wp_nonce_field( 'wpmi_signup_form', 'wpmi_nonce' ); ?>
    <p>
        <label for="wpmi_email">Email Address:</label><br>
        <input type="email" id="wpmi_email" name="wpmi_email" required>
    </p>
    <p>
        <label for="wpmi_fname">First Name:</label><br>
        <input type="text" id="wpmi_fname" name="wpmi_fname">
    </p>
    <p>
        <label for="wpmi_lname">Last Name:</label><br>
        <input type="text" id="wpmi_lname" name="wpmi_lname">
    </p>
    <p>
        <input type="submit" name="wpmi_submit" value="Subscribe">
    </p>
</form>
