const { registerBlockType } = wp.blocks;
const { InspectorControls, useBlockProps } = wp.blockEditor;
const { PanelBody, SelectControl } = wp.components;
const { useSelect } = wp.data;

registerBlockType( 'wp-mailchimp-integration/product-highlight', {
    title: 'Product Highlight',
    category: 'wp-mailchimp-integration',
    icon: 'products',
    description: 'A block to display a WooCommerce product.',
    keywords: [ 'product', 'woocommerce', 'mailchimp' ],
    attributes: {
        productId: {
            type: 'number',
        },
    },
    edit: ( { attributes, setAttributes, className } ) => {
        const blockProps = useBlockProps( { className: className } );
        const { productId } = attributes;

        const products = useSelect( ( select ) => {
            return select( 'core' ).getEntityRecords( 'postType', 'product', { per_page: -1 } );
        }, [] );

        const options = ( products || [] ).map( product => ( {
            label: product.title.rendered,
            value: product.id,
        } ) );

        const product = useSelect( ( select ) => {
            if ( ! productId ) {
                return null;
            }
            return select( 'core' ).getEntityRecord( 'postType', 'product', productId );
        }, [ productId ] );
        
        const productImage = useSelect( ( select ) => {
            if ( ! product || ! product.featured_media ) {
                return null;
            }
            return select( 'core' ).getMedia( product.featured_media );
        }, [ product ] );


        return (
            <div { ...blockProps }>
                <InspectorControls>
                    <PanelBody title="Product Highlight Settings">
                        <SelectControl
                            label="Product"
                            value={ productId }
                            options={ [ { label: 'Select a product', value: 0 }, ...options ] }
                            onChange={ ( value ) => setAttributes( { productId: parseInt( value, 10 ) } ) }
                        />
                    </PanelBody>
                </InspectorControls>
                { product &&
                    <div>
                        { productImage &&
                            <img src={ productImage.source_url } alt={ product.title.rendered } />
                        }
                        <h5>{ product.title.rendered }</h5>
                        <div dangerouslySetInnerHTML={ { __html: product.price_html } } />
                        <a href={ product.permalink }>View Product</a>
                    </div>
                }
            </div>
        );
    },
    save: ( { attributes } ) => {
        return null; // This block is rendered dynamically.
    },
} );
