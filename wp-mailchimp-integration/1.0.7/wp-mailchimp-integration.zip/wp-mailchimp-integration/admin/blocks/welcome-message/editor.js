const { registerBlockType } = wp.blocks;
const { RichText } = wp.blockEditor;

registerBlockType( 'wp-mailchimp-integration/welcome-message', {
    title: 'Welcome Message',
    category: 'wp-mailchimp-integration',
    icon: 'email-alt',
    description: 'A block to display a welcome message.',
    keywords: [ 'welcome', 'message', 'mailchimp' ],
    attributes: {
        title: {
            type: 'string',
            source: 'html',
            selector: 'h2',
        },
        content: {
            type: 'string',
            source: 'html',
            selector: 'p',
        },
    },
    edit: ( { attributes, setAttributes, className } ) => {
        const { title, content } = attributes;
        return (
            <div className={ className }>
                <RichText
                    tagName="h2"
                    placeholder="Enter title here"
                    value={ title }
                    onChange={ ( value ) => setAttributes( { title: value } ) }
                />
                <RichText
                    tagName="p"
                    placeholder="Enter content here"
                    value={ content }
                    onChange={ ( value ) => setAttributes( { content: value } ) }
                />
            </div>
        );
    },
    save: ( { attributes } ) => {
        const { title, content } = attributes;
        return (
            <div>
                <h2>{ title }</h2>
                <p>{ content }</p>
            </div>
        );
    },
} );
