<?php

class Wp_Mailchimp_Integration_Automations_Runner {

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new Wp_Mailchimp_Integration_Automations_Runner();
        }
        return self::$instance;
    }

    public function run() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_automations';
        $automations = $wpdb->get_results( "SELECT * FROM $table_name" );

        foreach ( $automations as $automation ) {
            add_action( $automation->trigger_name, function( ...$args ) use ( $automation ) {
                $this->execute_action( $automation, $args );
            }, 10, 10 );
        }
    }

    private function execute_action( $automation, $args ) {
        Wp_Mailchimp_Logger::log( 'automation', 'Executing automation: ' . $automation->name );
        $api = Wp_Mailchimp_Api::get_instance();

        switch ( $automation->action_name ) {
            case 'subscribe_user':
                $email = '';
                $fname = '';
                $lname = '';

                if ( $automation->trigger_name === 'user_register' ) {
                    $user_id = $args[0];
                    $user = get_user_by( 'id', $user_id );
                    $email = $user->user_email;
                    $fname = $user->first_name;
                    $lname = $user->last_name;
                } elseif ( $automation->trigger_name === 'comment_post' ) {
                    $comment_id = $args[0];
                    $comment = get_comment( $comment_id );
                    $email = $comment->comment_author_email;
                    $fname = $comment->comment_author;
                } elseif ( $automation->trigger_name === 'wp_login' ) {
                    $user_login = $args[0];
                    $user = get_user_by( 'login', $user_login );
                    $email = $user->user_email;
                    $fname = $user->first_name;
                    $lname = $user->last_name;
                }
                
                if ( !empty($email) ) {
                    $api->subscribe_user( $automation->audience_id, $email, $fname, $lname );
                }
                break;
            case 'unsubscribe_user':
                $email = '';

                if ( $automation->trigger_name === 'user_register' ) {
                    $user_id = $args[0];
                    $user = get_user_by( 'id', $user_id );
                    $email = $user->user_email;
                } elseif ( $automation->trigger_name === 'comment_post' ) {
                    $comment_id = $args[0];
                    $comment = get_comment( $comment_id );
                    $email = $comment->comment_author_email;
                } elseif ( $automation->trigger_name === 'wp_login' ) {
                    $user_login = $args[0];
                    $user = get_user_by( 'login', $user_login );
                    $email = $user->user_email;
                }

                if ( !empty($email) ) {
                    $api->unsubscribe_user( $automation->audience_id, $email );
                }
                break;
        }
    }
}
