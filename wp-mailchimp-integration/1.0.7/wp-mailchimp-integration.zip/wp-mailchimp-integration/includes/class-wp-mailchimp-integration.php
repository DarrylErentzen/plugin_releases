<?php

class Wp_Mailchimp_Integration {

    protected static $instance = null;

    protected $plugin_name;

    protected $version;

    protected $api;

    public static function get_instance( $plugin_file ) {
        if ( null === self::$instance ) {
            self::$instance = new self( $plugin_file );
        }
        return self::$instance;
    }

    protected function __construct( $plugin_file ) {
        $this->version = '1.0.0';
        $this->plugin_name = 'wp-mailchimp-integration';

        $this->define_constants( $plugin_file );
        $this->includes();
        $this->init_api();
        $this->init_hooks( $plugin_file );
    }
 
    private function define_constants( $plugin_file ) {
        define( 'WPMI_VERSION', $this->version );
        define( 'WPMI_PLUGIN_FILE', $plugin_file );
        define( 'WPMI_PLUGIN_DIR', plugin_dir_path( WPMI_PLUGIN_FILE ) );
        define( 'WPMI_PLUGIN_URL', plugin_dir_url( WPMI_PLUGIN_FILE ) );
    }

    private function includes() {
        require_once WPMI_PLUGIN_DIR . 'admin/class-wp-mailchimp-integration-admin.php';
        require_once WPMI_PLUGIN_DIR . 'public/class-wp-mailchimp-integration-public.php';
        require_once WPMI_PLUGIN_DIR . 'includes/class-wp-mailchimp-integration-automations-runner.php';
        require_once WPMI_PLUGIN_DIR . 'includes/class-wp-mailchimp-logger.php';
    }

    private function init_api() {
        $this->api = Wp_Mailchimp_Api::get_instance();
        $options = get_option( 'wp_mailchimp_integration' );
        if ( isset( $options['api_key'] ) ) {
            $this->api->set_api_key( $options['api_key'] );
        }
    }

    private function init_hooks( $plugin_file ) {
        register_activation_hook( $plugin_file, array( $this, 'activate' ) );
        register_deactivation_hook( $plugin_file, array(
            $this,
            'deactivate'
        ) );

        add_action( 'plugins_loaded', array( $this, 'run' ) );
        add_action( 'init', array( $this, 'register_post_types' ) );
        add_action( 'init', array( $this, 'register_blocks' ) );
        add_filter( 'block_categories_all', array( $this, 'register_block_category' ), 10, 2 );
        add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_block_editor_assets' ) );
        add_action( 'wpmi_send_scheduled_campaign', array( $this, 'send_scheduled_campaign' ), 10, 1 );
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'user_register', array( $this, 'sync_new_user_to_mailchimp' ), 10, 1 );
        add_action( 'profile_update', array( $this, 'sync_user_profile_update_to_mailchimp' ), 10, 2 );
        add_action( 'rest_api_init', array( $this, 'register_webhook_endpoint' ) );
    }

    public function sync_user_profile_update_to_mailchimp( $user_id, $old_user_data ) {
        $options = get_option( 'wpmi_options' );

        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            return;
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            return;
        }

        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }

        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();
        $user_roles = $user->roles;
        $tag = '';

        if ( ! empty( $user_roles ) ) {
            $user_role = $user_roles[0];
            if ( isset( $role_mappings[ $user_role ] ) ) {
                $tag = $role_mappings[ $user_role ];
            }
        }
        
        $tags_to_add = array();
        if( ! empty( $tag ) ) {
            $tags_to_add[] = $tag;
        }

        $data = array(
            'email_address' => $user->user_email,
            'merge_fields' => array(
                'FNAME' => $user->first_name,
                'LNAME' => $user->last_name,
            ),
            'tags' => $tags_to_add,
        );

        $this->api->update_member( $audience_id, $old_user_data->user_email, $data );
    }

    public function register_webhook_endpoint() {
        register_rest_route( 'wp-mailchimp-integration/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array( $this, 'handle_mailchimp_webhook' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function handle_mailchimp_webhook( $request ) {
        $data = $request->get_params();

        if ( ! isset( $data['type'] ) ) {
            return new WP_REST_Response( 'Invalid webhook data.', 400 );
        }

        Wp_Mailchimp_Logger::log( 'webhook', 'Received webhook of type: ' . $data['type'] );
        Wp_Mailchimp_Logger::log( 'webhook', print_r( $data, true ) );

        switch ( $data['type'] ) {
            case 'profile':
                $email = $data['data']['email'];
                $user = get_user_by( 'email', $email );
                if ( $user ) {
                    $merges = $data['data']['merges'];
                    wp_update_user( array(
                        'ID'         => $user->ID,
                        'first_name' => $merges['FNAME'],
                        'last_name'  => $merges['LNAME'],
                    ) );
                    Wp_Mailchimp_Logger::log( 'webhook', 'Updated user profile for: ' . $email );
                }
                break;
            case 'unsubscribe':
                Wp_Mailchimp_Logger::log( 'webhook', 'User unsubscribed: ' . $data['data']['email'] );
                break;
            case 'subscribe':
                Wp_Mailchimp_Logger::log( 'webhook', 'User subscribed: ' . $data['data']['email'] );
                break;
        }

        return new WP_REST_Response( 'Webhook processed.', 200 );
    }



    public function sync_new_user_to_mailchimp( $user_id ) {
        $options = get_option( 'wpmi_options' );

        if ( ! isset( $options['user_sync_enabled'] ) || ! $options['user_sync_enabled'] ) {
            return;
        }

        $audience_id = isset( $options['user_sync_audience_id'] ) ? $options['user_sync_audience_id'] : '';
        if ( empty( $audience_id ) ) {
            return;
        }

        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }

        $role_mappings = isset( $options['user_sync_role_mapping'] ) ? $options['user_sync_role_mapping'] : array();
        $user_roles = $user->roles;
        $tag = '';

        if ( ! empty( $user_roles ) ) {
            $user_role = $user_roles[0];
            if ( isset( $role_mappings[ $user_role ] ) ) {
                $tag = $role_mappings[ $user_role ];
            }
        }

        $tags_to_add = array();
        if( ! empty( $tag ) ) {
            $tags_to_add[] = $tag;
        }

        $this->api->subscribe_user( $audience_id, $user->user_email, $user->first_name, $user->last_name, $tags_to_add );
    }


    public function send_scheduled_campaign( $post_id ) {
        $admin = new Wp_Mailchimp_Integration_Admin( $this->get_plugin_name(), $this->get_version() );
        $admin->send_campaign( $post_id );
    }

    public function register_blocks() {
        register_block_type(
            'wp-mailchimp-integration/post-digest',
            array(
                'render_callback' => array( $this, 'render_post_digest_block' ),
            )
        );
        register_block_type( 'wp-mailchimp-integration/welcome-message' );

        if ( class_exists( 'WooCommerce' ) ) {
            register_block_type( 'wp-mailchimp-integration/product-highlight', array(
                'render_callback' => array( $this, 'render_product_highlight_block' ),
            ) );
        }
        
        register_block_type( 'wp-mailchimp-integration/post-tiles', array(
            'render_callback' => array( $this, 'render_post_tiles_block' ),
        ) );
    }

    public function render_post_tiles_block( $attributes ) {
        $args = array(
            'posts_per_page' => $attributes['numberOfPosts'],
        );
        $recent_posts = get_posts( $args );
        $columns = $attributes['columns'];

        $output = '<ul class="columns-' . $columns . '">';
        foreach ( $recent_posts as $post ) {
            $output .= '<li>';
            $output .= '<a href="' . get_permalink( $post ) . '">';
            $output .= get_the_post_thumbnail( $post, 'thumbnail' );
            $output .= '<h5>' . get_the_title( $post ) . '</h5>';
            $output .= '</a>';
            $output .= '<div>' . get_the_excerpt( $post ) . '</div>';
            $output .= '</li>';
        }
        $output .= '</ul>';

        return $output;
    }

    public function render_product_highlight_block( $attributes ) {
        $product_id = $attributes['productId'];
        $product = wc_get_product( $product_id );

        if ( ! $product ) {
            return '';
        }

        $output = '<div>';
        $output .= '<a href="' . get_permalink( $product_id ) . '">';
        $output .= $product->get_image();
        $output .= '<h5>' . $product->get_name() . '</h5>';
        $output .= '</a>';
        $output .= '<div>' . $product->get_price_html() . '</div>';
        $output .= '<a href="' . $product->add_to_cart_url() . '">Add to cart</a>';
        $output .= '</div>';

        return $output;
    }

    public function enqueue_block_editor_assets() {
        wp_enqueue_script(
            'wp-mailchimp-integration-post-digest-block',
            plugins_url( 'admin/blocks/post-digest/editor.js', dirname( __FILE__ ) ),
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/post-digest/editor.js' )
        );

        wp_enqueue_script(
            'wp-mailchimp-integration-welcome-message-block',
            plugins_url( 'admin/blocks/welcome-message/editor.js', dirname( __FILE__ ) ),
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/welcome-message/editor.js' )
        );
        
        if ( class_exists( 'WooCommerce' ) ) {
            wp_enqueue_script(
                'wp-mailchimp-integration-product-highlight-block',
                plugins_url( 'admin/blocks/product-highlight/editor.js', dirname( __FILE__ ) ),
                array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
                filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/product-highlight/editor.js' )
            );
        }

        wp_enqueue_script(
            'wp-mailchimp-integration-post-tiles-block',
            plugins_url( 'admin/blocks/post-tiles/editor.js', dirname( __FILE__ ) ),
            array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-data' ),
            filemtime( plugin_dir_path( __FILE__ ) . '../admin/blocks/post-tiles/editor.js' )
        );
    }

    public function render_post_digest_block( $attributes ) {
        $args = array(
            'posts_per_page' => $attributes['numberOfPosts'],
        );
        $recent_posts = get_posts( $args );
        $columns = $attributes['columns'];

        $output = '<ul class="columns-' . $columns . '">';
        foreach ( $recent_posts as $post ) {
            $output .= '<li>';
            $output .= '<a href="' . get_permalink( $post ) . '">';
            $output .= '<h5>' . get_the_title( $post ) . '</h5>';
            $output .= '</a>';
            $output .= '<div>' . get_the_excerpt( $post ) . '</div>';
            $output .= '</li>';
        }
        $output .= '</ul>';

        return $output;
    }

    public function register_block_category( $categories, $post ) {
        if ( $post->post_type !== 'mailchimp-template' ) {
            return $categories;
        }
        return array_merge(
            $categories,
            array(
                array(
                    'slug' => 'wp-mailchimp-integration',
                    'title' => __( 'Mailchimp', 'wp-mailchimp-integration' ),
                ),
            )
        );
    }

    public function run() {
        $plugin_admin = new Wp_Mailchimp_Integration_Admin( $this->get_plugin_name(), $this->get_version() );
        $plugin_public = new Wp_Mailchimp_Integration_Public( $this->get_plugin_name(), $this->get_version() );

        $automations_runner = Wp_Mailchimp_Integration_Automations_Runner::get_instance();
        $automations_runner->run();
    }

    public function register_post_types() {
        $labels = array(
            'name'                  => _x( 'Mailchimp Templates', 'Post type general name', 'wp-mailchimp-integration' ),
            'singular_name'         => _x( 'Mailchimp Template', 'Post type singular name', 'wp-mailchimp-integration' ),
            'menu_name'             => _x( 'Templates', 'Admin Menu text', 'wp-mailchimp-integration' ),
            'name_admin_bar'        => _x( 'Mailchimp Template', 'Add New on Toolbar', 'wp-mailchimp-integration' ),
            'add_new'               => __( 'Add New', 'wp-mailchimp-integration' ),
            'add_new_item'          => __( 'Add New Mailchimp Template', 'wp-mailchimp-integration' ),
            'new_item'              => __( 'New Mailchimp Template', 'wp-mailchimp-integration' ),
            'edit_item'             => __( 'Edit Mailchimp Template', 'wp-mailchimp-integration' ),
            'view_item'             => __( 'View Mailchimp Template', 'wp-mailchimp-integration' ),
            'all_items'             => __( 'All Mailchimp Templates', 'wp-mailchimp-integration' ),
            'search_items'          => __( 'Search Mailchimp Templates', 'wp-mailchimp-integration' ),
            'parent_item_colon'     => __( 'Parent Mailchimp Templates:', 'wp-mailchimp-integration' ),
            'not_found'             => __( 'No Mailchimp Templates found.', 'wp-mailchimp-integration' ),
            'not_found_in_trash'    => __( 'No Mailchimp Templates found in Trash.', 'wp-mailchimp-integration' ),
            'featured_image'        => _x( 'Mailchimp Template Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'wp-mailchimp-integration' ),
            'archives'              => _x( 'Mailchimp Template archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'wp-mailchimp-integration' ),
            'insert_into_item'      => _x( 'Insert into Mailchimp Template', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'wp-mailchimp-integration' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Mailchimp Template', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'wp-mailchimp-integration' ),
            'filter_items_list'     => _x( 'Filter Mailchimp Templates list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'wp-mailchimp-integration' ),
            'items_list_navigation' => _x( 'Mailchimp Templates list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'wp-mailchimp-integration' ),
            'items_list'            => _x( 'Mailchimp Templates list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'wp-mailchimp-integration' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => 'wp-mailchimp-integration',
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'mailchimp-template' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array( 'title', 'editor' ),
            'show_in_rest'       => true,
        );

        register_post_type( 'mailchimp-template', $args );
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_automations';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name tinytext NOT NULL,
            trigger_name tinytext NOT NULL,
            action_name tinytext NOT NULL,
            audience_id tinytext,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        $table_name = $wpdb->prefix . 'mailchimp_logs';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            type tinytext NOT NULL,
            message text NOT NULL,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta( $sql );
    }

    public function deactivate() {
        // Deactivation code
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_version() {
        return $this->version;
    }

    public function get_api() {
        return $this->api;
    }

    public function add_settings_page() {
        add_options_page(
            __( 'WP Mailchimp Integration', 'wp-mailchimp-integration' ),
            __( 'WP Mailchimp Integration', 'wp-mailchimp-integration' ),
            'manage_options',
            'wp-mailchimp-integration',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'wp_mailchimp_integration_settings', 'wp_mailchimp_integration' );

        add_settings_section(
            'wp_mailchimp_integration_general',
            __( 'General Settings', 'wp-mailchimp-integration' ),
            '__return_null',
            'wp-mailchimp-integration'
        );

        add_settings_field(
            'api_key',
            __( 'Mailchimp API Key', 'wp-mailchimp-integration' ),
            array( $this, 'render_api_key_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'delivery_method',
            __( 'Delivery Method', 'wp-mailchimp-integration' ),
            array( $this, 'render_delivery_method_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'smtp_host',
            __( 'SMTP Host', 'wp-mailchimp-integration' ),
            array( $this, 'render_smtp_host_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'smtp_port',
            __( 'SMTP Port', 'wp-mailchimp-integration' ),
            array( $this, 'render_smtp_port_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'smtp_user',
            __( 'SMTP Username', 'wp-mailchimp-integration' ),
            array( $this, 'render_smtp_user_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'smtp_pass',
            __( 'SMTP Password', 'wp-mailchimp-integration' ),
            array( $this, 'render_smtp_pass_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );

        add_settings_field(
            'smtp_secure',
            __( 'SMTP Encryption', 'wp-mailchimp-integration' ),
            array( $this, 'render_smtp_secure_field' ),
            'wp-mailchimp-integration',
            'wp_mailchimp_integration_general'
        );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields( 'wp_mailchimp_integration_settings' );
                do_settings_sections( 'wp-mailchimp-integration' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function render_api_key_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['api_key'] ) ? $options['api_key'] : '';
        ?>
        <input type="text" name="wp_mailchimp_integration[api_key]" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
        <?php
    }

    public function render_delivery_method_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['delivery_method'] ) ? $options['delivery_method'] : 'wp_mail';
        ?>
        <select name="wp_mailchimp_integration[delivery_method]">
            <option value="wp_mail" <?php selected( $value, 'wp_mail' ); ?>>wp_mail (Default)</option>
            <option value="mailchimp" <?php selected( $value, 'mailchimp' ); ?>>MailChimp</option>
            <option value="aweber" <?php selected( $value, 'aweber' ); ?>>Aweber</option>
            <option value="gmail" <?php selected( $value, 'gmail' ); ?>>Gmail</option>
            <option value="smtp" <?php selected( $value, 'smtp' ); ?>>Generic SMTP/POP/IMAP</option>
        </select>
        <p class="description">
            <strong><?php _e( 'DNS Records for Deliverability:', 'wp-mailchimp-integration' ); ?></strong><br>
            <?php _e( 'To ensure your emails land in the inbox, you should configure the following DNS records for your domain:', 'wp-mailchimp-integration' ); ?><br>
            - <strong>SPF (Sender Policy Framework):</strong> <?php _e( 'Add a TXT record to your DNS settings. Example: <code>v=spf1 include:servers.mcsv.net ~all</code> (for MailChimp) or include your SMTP provider\'s SPF include.', 'wp-mailchimp-integration' ); ?><br>
            - <strong>DKIM (DomainKeys Identified Mail):</strong> <?php _e( 'Generate a DKIM key pair from your email provider settings and add the public key as a CNAME or TXT record in your DNS.', 'wp-mailchimp-integration' ); ?><br>
            - <strong>DMARC:</strong> <?php _e( 'Add a TXT record for <code>_dmarc.yourdomain.com</code>. Example: <code>v=DMARC1; p=none; rua=mailto:dmarc-reports@yourdomain.com</code>.', 'wp-mailchimp-integration' ); ?>
        </p>
        <?php
    }

    public function render_smtp_host_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['smtp_host'] ) ? $options['smtp_host'] : '';
        ?>
        <input type="text" name="wp_mailchimp_integration[smtp_host]" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
        <?php
    }

    public function render_smtp_port_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['smtp_port'] ) ? $options['smtp_port'] : '';
        ?>
        <input type="text" name="wp_mailchimp_integration[smtp_port]" value="<?php echo esc_attr( $value ); ?>" class="small-text">
        <?php
    }

    public function render_smtp_user_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['smtp_user'] ) ? $options['smtp_user'] : '';
        ?>
        <input type="text" name="wp_mailchimp_integration[smtp_user]" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
        <?php
    }

    public function render_smtp_pass_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['smtp_pass'] ) ? $options['smtp_pass'] : '';
        ?>
        <input type="password" name="wp_mailchimp_integration[smtp_pass]" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
        <?php
    }

    public function render_smtp_secure_field() {
        $options = get_option( 'wp_mailchimp_integration' );
        $value = isset( $options['smtp_secure'] ) ? $options['smtp_secure'] : 'tls';
        ?>
        <input type="text" name="wp_mailchimp_integration[smtp_secure]" value="<?php echo esc_attr( $value ); ?>" class="small-text" placeholder="tls">
        <?php
    }
}
