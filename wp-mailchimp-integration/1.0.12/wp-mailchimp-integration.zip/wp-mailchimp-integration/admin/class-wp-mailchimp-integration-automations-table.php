<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Wp_Mailchimp_Integration_Automations_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => 'Automation',
            'plural'   => 'Automations',
            'ajax'     => false
        ] );
    }

    public function get_columns() {
        return [
            'cb'   => '<input type="checkbox" />',
            'name' => 'Name',
            'trigger_name' => 'Trigger',
            'action_name' => 'Action',
        ];
    }

    public function prepare_items() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mailchimp_automations';

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->items = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );
    }

    function column_name($item) {
        $actions = array(
            'edit'      => sprintf('<a href="?page=%s&action=%s&automation=%s">Edit</a>', $_REQUEST['page'],'edit',$item['id']),
            'delete'    => sprintf('<a href="?page=%s&action=%s&automation=%s">Delete</a>',$_REQUEST['page'],'delete',$item['id']),
        );

        return sprintf('%1$s %2$s', $item['name'], $this->row_actions($actions) );
    }

    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'trigger_name':
                return $item['trigger_name'];
            case 'action_name':
                return $item['action_name'];
            default:
                return print_r( $item, true );
        }
    }

    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="automation[]" value="%s" />', $item['id']
        );
    }
}
