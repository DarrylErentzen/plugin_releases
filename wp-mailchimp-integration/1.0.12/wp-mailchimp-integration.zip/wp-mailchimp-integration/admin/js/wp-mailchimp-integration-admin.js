(function( $ ) {
    'use strict';

    $(function() {
        $('#test-connection-button').on('click', function() {
            var resultDiv = $('#test-connection-result');
            resultDiv.html('<p>Testing...</p>');

            var data = {
                'action': 'wpmi_test_connection',
                'nonce': wpmi_ajax.nonce,
                'api_key': $('#wpmi_api_key').val()
            };

            $.post(wpmi_ajax.ajax_url, data, function(response) {
                if (response.success) {
                    resultDiv.html('<p style="color: green;">' + response.data + '</p>');
                } else {
                    resultDiv.html('<p style="color: red;">' + response.data + '</p>');
                }
            });
        });

        $('#action').on('change', function() {
            if ( $(this).val() === 'subscribe_user' || $(this).val() === 'unsubscribe_user' ) {
                $('#audience_row').show();
            } else {
                $('#audience_row').hide();
            }
        }).trigger('change');

        $('#wpmi_bulk_sync_button').on('click', function() {
            var progressDiv = $('#wpmi_bulk_sync_progress');
            progressDiv.html('<p>Starting bulk sync...</p>');
            $(this).prop('disabled', true);

            var offset = 0;
            var batch_size = 10;

            function syncBatch() {
                var data = {
                    'action': 'wpmi_bulk_sync',
                    'nonce': wpmi_ajax.bulk_sync_nonce,
                    'offset': offset,
                    'batch_size': batch_size
                };

                $.post(wpmi_ajax.ajax_url, data, function(response) {
                    if (response.success) {
                        progressDiv.append('<p>' + response.data.message + '</p>');
                        if (response.data.finished) {
                            progressDiv.append('<p>Bulk sync finished!</p>');
                            $('#wpmi_bulk_sync_button').prop('disabled', false);
                        } else {
                            offset += batch_size;
                            syncBatch();
                        }
                    } else {
                        progressDiv.append('<p style="color: red;">' + response.data + '</p>');
                        $('#wpmi_bulk_sync_button').prop('disabled', false);
                    }
                });
            }

            syncBatch();
        });

        $('#wpmi_enable_two_way_sync').on('click', function() {
            var statusDiv = $('#wpmi_two_way_sync_status');
            statusDiv.html('<p>Enabling two-way sync...</p>');
            $(this).prop('disabled', true);

            var data = {
                'action': 'wpmi_enable_two_way_sync',
                'nonce': wpmi_ajax.two_way_sync_nonce
            };

            $.post(wpmi_ajax.ajax_url, data, function(response) {
                if (response.success) {
                    statusDiv.html('<p style="color: green;">' + response.data + '</p>');
                } else {
                    statusDiv.html('<p style="color: red;">' + response.data + '</p>');
                    $('#wpmi_enable_two_way_sync').prop('disabled', false);
                }
            });
        });
    });

})( jQuery );
