<?php
/**
 * The modal view for the setup wizard.
 *
 * @link       https://www.your-website.com
 * @since      1.0.0
 *
 * @package    Wp_Mailchimp_Integration
 * @subpackage Wp_Mailchimp_Integration/admin/wizard/views
 */
?>

<div id="wizard-modal" class="wizard-modal">
    <div class="wizard-modal-content">
        <button class="wizard-close-btn" title="Close">&times;</button>
        
        <!-- Sidebar for Table of Contents (Desktop) -->
        <div class="wizard-sidebar">
            <h3>Setup Topics</h3>
            <ul class="wizard-toc">
                <!-- TOC items will be dynamically inserted here by JavaScript -->
            </ul>
        </div>
        
        <!-- Main content area -->
        <div class="wizard-main">
            <h2 class="wizard-step-title">
                <!-- Title will be dynamically inserted here -->
            </h2>
            
            <div class="wizard-step-body">
                <!-- Step content will be dynamically inserted here -->
            </div>
            
            <div class="wizard-navigation">
                <button class="wizard-prev-btn">Previous</button>
                <button class="wizard-next-btn">Next</button>
            </div>
            
            <div class="wizard-learn-more">
                <a href="#" target="_blank" rel="noopener noreferrer">Learn More</a>
            </div>
        </div>
    </div>
</div>
