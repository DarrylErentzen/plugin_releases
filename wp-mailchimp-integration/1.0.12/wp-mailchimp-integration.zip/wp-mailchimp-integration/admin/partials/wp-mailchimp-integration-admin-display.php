<div class="wrap">
    <div class="wpmi-wizard-launch-wrapper" style="margin-bottom: 20px; padding: 15px; background-color: #f0f6fc; border: 1px solid #c9e0f5;">
        <h2>Welcome to Mailchimp Integration!</h2>
        <p>Need help getting started? Launch our setup wizard for a guided tour.</p>
        <button id="launch-wizard-btn" class="button button-primary">Launch Setup Wizard</button>
    </div>

    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <form action="options.php" method="post">
        <?php
        settings_fields( $this->plugin_name );
        do_settings_sections( $this->plugin_name );
        submit_button( 'Save Settings' );
        ?>
    </form>
    <hr>
    <h2>Test API Connection</h2>
    <p>
        <button id="test-connection-button" class="button">Test Connection</button>
    </p>
    <div id="test-connection-result"></div>
</div>

