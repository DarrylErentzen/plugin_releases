<?php

/**
 * The admin-facing functionality of the plugin.
 *
 * @link       https://www.your-website.com
 * @since      1.0.0
 *
 * @package    Wp_Mailchimp_Integration
 * @subpackage Wp_Mailchimp_Integration/admin 
 */

/**
 * The admin-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Mailchimp_Integration
 * @subpackage Wp_Mailchimp_Integration/admin
 * @author     Your Name <email@example.com>
 */
class Wp_Mailchimp_Integration_Wizard {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The steps for the wizard.
     *
     * @since    1.0.0
     * @access   private
     * @var      array    $steps    The steps for the wizard.
     */
    private $steps;


    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->steps = array();

        add_action('wp_ajax_get_wizard_steps', array($this, 'get_wizard_steps_ajax'));


    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        wp_enqueue_style( $this->plugin_name . '-wizard', plugin_dir_url( __FILE__ ) . 'css/wizard.css', array(), $this->version, 'all' );

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script( $this->plugin_name . '-wizard', plugin_dir_url( __FILE__ ) . 'js/wizard.js', array( 'jquery' ), $this->version, false );
        wp_localize_script( $this->plugin_name . '-wizard', 'wizard_ajax', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }

    /**
     * Define the steps for the wizard.
     *
     * @since    1.0.0
     */
    public function define_steps() {
        $this->steps = array(
            'step_1' => array(
                'title' => 'Welcome!',
                'content_shorthand' => 'Welcome!',
                'content_desktop' => 'This wizard will guide you through the initial setup of the Mailchimp Integration plugin.',
                'target_element' => 'h1',
                'learn_more_url' => '#'
            ),
            'step_2' => array(
                'title' => 'Connect Your Account',
                'content_shorthand' => 'API Key',
                'content_desktop' => 'First, paste your Mailchimp API key into this field. This is required to connect your WordPress site to your Mailchimp account.',
                'target_element' => '#api_key',
                'learn_more_url' => '#'
            ),
            'step_3' => array(
                'title' => 'Delivery Method',
                'content_shorthand' => 'Delivery',
                'content_desktop' => 'Choose how you want your emails to be sent. You can use standard WP Mail, or connect directly to Mailchimp or other providers.',
                'target_element' => '#delivery_method',
                'learn_more_url' => '#'
            ),
            'step_4' => array(
                'title' => 'Enable User Sync',
                'content_shorthand' => 'Sync',
                'content_desktop' => 'Check this box if you want new WordPress users to be automatically subscribed to your Mailchimp list.',
                'target_element' => '#user_sync_enabled',
                'learn_more_url' => '#'
            ),
            'step_5' => array(
                'title' => 'Select a Default Audience',
                'content_shorthand' => 'Audience',
                'content_desktop' => 'Once you save a valid API key, this field will populate with your Mailchimp audiences. Select one to be your default for new subscribers and forms.',
                'target_element' => '#user_sync_audience_id',
                'learn_more_url' => '#'
            ),
            'step_6' => array(
                'title' => 'Save Your Settings',
                'content_shorthand' => 'Save',
                'content_desktop' => 'Don\'t forget to click "Save Settings" to store your configuration.',
                'target_element' => '#submit',
                'learn_more_url' => '#'
            ),
        );

        // Allow developers to filter and extend the steps
        $this->steps = apply_filters( 'wp_mailchimp_integration_wizard_steps', $this->steps );
    }


    /**
     * Get the wizard steps via AJAX.
     *
     * @since    1.0.0
     */
    public function get_wizard_steps_ajax() {
        $this->define_steps();
        wp_send_json_success($this->steps);
    }


    /**
     * Render the wizard modal.
     *
     * @since    1.0.0
     */
    public function render_wizard() {
        $this->define_steps();
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'wizard/views/wizard-modal-view.php';
    }
}
